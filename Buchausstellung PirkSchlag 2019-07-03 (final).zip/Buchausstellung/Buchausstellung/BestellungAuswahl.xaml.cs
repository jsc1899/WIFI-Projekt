﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für BestellungAuswahl.xaml
    /// </summary>
    public partial class BestellungAuswahl : UserControl
    {
        public BestellungAuswahl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Event, das bei jedem Tastendruck ausgelöst wird.
        /// Filtert die Liste der Bestellungen nach dem Suchbegriff.
        /// </summary>
        private void Bestellungfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BestellungOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Bestellungen.ItemsSource);

            BestellungOriginal.Filter = (bestellung) =>
            {
                if (String.IsNullOrEmpty(Bestellungfilter.Text) && String.IsNullOrEmpty(Kundenfilter.Text))
                {
                    return true;
                }
                else
                {
                    if (((Daten.Bestellung)bestellung).Buch.NrUndTitel.ToLower().Contains(Bestellungfilter.Text.ToLower())
                        && ((Daten.Bestellung)bestellung).Kunde.KompletterName.ToLower().Contains(Kundenfilter.Text.ToLower())
                    )
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            };

            BestellungOriginal.Refresh();

        }

        /// <summary>
        /// Event, das bei Fokussierung des Suchfeldes ausgelöst wird.
        /// Setzt das Suchfeld zurück.
        /// </summary>
        private void Bestellungfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Bestellungfilter.Text = "Damit es keinen Treffer gibt und AktuelleBestellung zurückgesetzt wird";
            Bestellungfilter_KeyUp(Bestellungfilter, null);
            Bestellungfilter.Text = string.Empty;
            Bestellungfilter_KeyUp(Bestellungfilter, null);
        }

        /// <summary>
        /// Event, das bei Fokussierung des Suchfeldes ausgelöst wird.
        /// Setzt das Suchfeld zurück.
        /// </summary>
        private void Kundenfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Kundenfilter.Text = "Damit es keinen Treffer gibt und AktuelleBestellung zurückgesetzt wird";
            Bestellungfilter_KeyUp(Bestellungfilter, null);
            Kundenfilter.Text = string.Empty;
            Bestellungfilter_KeyUp(Bestellungfilter, null);
        }

    }
}
