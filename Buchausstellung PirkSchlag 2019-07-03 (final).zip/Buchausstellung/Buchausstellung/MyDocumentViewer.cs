﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Xps;
using System.Printing;
using System.Windows.Documents;
using System.Windows;

namespace Buchausstellung
{
    /// <summary>
    /// Stellt einen Dienst zum Anzeigen einer Druckansicht dar.
    /// </summary>
    public class MyDocumentViewer : DocumentViewer
    {

        /// <summary>
        /// Löst den Druckbefehl des Documentviewers aus.
        /// </summary>
        protected override void OnPrintCommand()
        {

            //get a print dialog, defaulted to default printer and default printer's preferences.
            PrintDialog printDialog = new PrintDialog();
            printDialog.PrintQueue = LocalPrintServer.GetDefaultPrintQueue();
            printDialog.PrintTicket = printDialog.PrintQueue.DefaultPrintTicket;
            printDialog.PageRangeSelection = PageRangeSelection.AllPages;
            printDialog.UserPageRangeEnabled = true;
            printDialog.CurrentPageEnabled = false;
            printDialog.SelectedPagesEnabled = false;


            //get a reference to the FixedDocumentSequence for the viewer.
            FixedDocument Dokument = this.Document as FixedDocument;
            if (Dokument.Name == "Buchbestellungen")
            {
                printDialog.PrintTicket.PageOrientation = System.Printing.PageOrientation.Landscape;
            }
            if (Dokument.Name == "Bestellerinnerungen")
            {
                printDialog.PrintTicket.PagesPerSheet = 2;
            }

            // Allow the user to select a PageRange
            if (printDialog.ShowDialog() == true)
            {
                DocumentPaginator paginator =
                  this.Document.DocumentPaginator;

                if (printDialog.PageRangeSelection == PageRangeSelection.UserPages)
                {
                    paginator = new PageRangeDocumentPaginator(
                                     this.Document.DocumentPaginator,
                                     printDialog.PageRange);
                }

                printDialog.PrintDocument(paginator, "Druck");
            }

        }
    }

    /// <summary>
    /// Stellt einen Dienst für die Seitengenerierung bereit.
    /// </summary>
    public class PageRangeDocumentPaginator : DocumentPaginator
    {
        private int _startIndex;
        private int _endIndex;
        private DocumentPaginator _paginator;

        /// <summary>
        /// Konstruktor des Paginators.
        /// </summary>
        public PageRangeDocumentPaginator(DocumentPaginator paginator, PageRange pageRange)
        {
            _startIndex = pageRange.PageFrom - 1;
            _endIndex = pageRange.PageTo - 1;
            _paginator = paginator;

            // Adjust the _endIndex
            _endIndex = Math.Min(_endIndex, _paginator.PageCount - 1);
        }


        /// <summary>
        /// Gibt eine Seite zurück.
        /// </summary>
        public override DocumentPage GetPage(int pageNumber)
        {
            var page = _paginator.GetPage(pageNumber + _startIndex);

            // Create a new ContainerVisual as a new parent for page children
            var cv = new System.Windows.Media.ContainerVisual();
            if (page.Visual is FixedPage)
            {
                foreach (var child in ((FixedPage)page.Visual).Children)
                {
                    // Make a shallow clone of the child using reflection
                    var childClone = (UIElement)child.GetType().GetMethod("MemberwiseClone", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(child, null);

                    // Setting the parent of the cloned child to the created ContainerVisual by using Reflection.
                    // WARNING: If we use Add and Remove methods on the FixedPage.Children, for some reason it will
                    //          throw an exception concerning event handlers after the printing job has finished.
                    var parentField = childClone.GetType().GetField("_parent",
                                                                    System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                    if (parentField != null)
                    {
                        parentField.SetValue(childClone, null);
                        cv.Children.Add(childClone);
                    }
                }

                return new DocumentPage(cv, page.Size, page.BleedBox, page.ContentBox);
            }

            return page;
        }

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Gesamtseitenanzahl ermittelt wurde.
        /// </summary>
        public override bool IsPageCountValid
        {
            get { return true; }
        }

        /// <summary>
        /// Ruft die Anzahl der Seiten ab.
        /// </summary>
        public override int PageCount
        {
            get
            {
                if (_startIndex > _paginator.PageCount - 1)
                    return 0;
                if (_startIndex > _endIndex)
                    return 0;

                return _endIndex - _startIndex + 1;
            }
        }

        /// <summary>
        /// Ruft die PageSize ab oder legt sie fest.
        /// </summary>
        public override Size PageSize
        {
            get { return _paginator.PageSize; }
            set { _paginator.PageSize = value; }
        }

        /// <summary>
        /// Ruft die Quelle von IDocumentPaginatorSource ab.
        /// </summary>
        public override IDocumentPaginatorSource Source
        {
            get { return _paginator.Source; }
        }

    }

}

