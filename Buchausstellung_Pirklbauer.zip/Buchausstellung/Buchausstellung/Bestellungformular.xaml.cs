﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für Bestellungformular.xaml
    /// </summary>
    public partial class Bestellungformular : UserControl
    {
        public Bestellungformular()
        {
            InitializeComponent();
        }


        private void Buchfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BücherOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Buch.ItemsSource);

            BücherOriginal.Filter = (buch) =>
            {
                if (String.IsNullOrEmpty(Buch.Text))
                {
                    Buch.IsDropDownOpen = true;
                    Buch.SelectedItem = null;
                    Buch.SelectedValue = null;
                    return true;
                }
                else
                {
                    if (((Daten.Buch)buch).Suchstring.ToLower().Contains(Buch.Text.ToLower()))
                    {
                        Buch.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            BücherOriginal.Refresh();

        }

        private void Buchfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Buch.IsDropDownOpen = true;
        }

        private void Kundenfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView KundenOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Kunde.ItemsSource);

            KundenOriginal.Filter = (kunde) =>
            {
                if (String.IsNullOrEmpty(Kunde.Text))
                {
                    Kunde.IsDropDownOpen = true;
                    Kunde.SelectedItem = null;
                    Kunde.SelectedValue = null;
                    return true;
                }
                else
                {
                    if (((Daten.Kunde)kunde).KompletterName.ToLower().Contains(Kunde.Text.ToLower()))
                    {
                        Kunde.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            KundenOriginal.Refresh();

        }

        private void Kundenfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Kunde.IsDropDownOpen = true;
        }
    }
}
