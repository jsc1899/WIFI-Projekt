﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Daten.Lotto
{
    /// <summary>
    /// Stellt einen Dienst zum Lesen und Schreiben
    /// der Lottodaten aus einer Sql Server Datenbank bereit.
    /// </summary>
    internal class LottoSqlController : WIFI.Anwendung.Daten.DatenbankObjekt
    {

        /// <summary>
        /// Gibt die gespeicherten Lottoländer zurück.
        /// </summary>
        /// <param name="sprachCode">Die für die Namen der
        /// Länder zu benutztende Oberflächensprache.</param>
        public Länder HoleLänder(string sprachCode)
        {

            var Ergebnis = new Länder();

            //IMMER das erste Objekt bei Datenbankzugriffen
            //Alle Datenbankobjekte besitzen ein Dispose()
            //Nie vergessen!
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {

                //IMMER das zweite Objekt bei Datenbankzugriffen
                using (var Befehl = new System.Data.SqlClient.SqlCommand("HoleLänder", Verbindung))
                {
                    //Wir arbeiten mit gespeicherten Prozeduren...
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    //Die Parameter beschicken...
                    //=============== IMMER SO ==============================
                    Befehl.Parameters.AddWithValue("@sprachcode", sprachCode);
                    //=============== NIE ANDERS !!! ========================
                    //Warum?
                    //  - Wegen der Hacker
                    //  - Ein Einfallstor ist SQL-INJECTION
                    //  - .Net verhindert über die Parameter
                    //    diese SQL-INJECTION

                    //Den Datenbank-Server bitten, die
                    //Prozedure zu cachen...
                    Befehl.Prepare();

                    //Zum Schluss noch...
                    Verbindung.Open();

                    //Jetzt ist man fertig, falls...
                    //  - Daten eingefügt werden: INSERT
                    //  - Daten geändert werden: UPDATE
                    //  - Daten gelöscht werden: DELETE

                    //In diesen drei Fällen
                    //Befehl.ExecuteNonQuery();

                    //Nur wenn Daten geholt werden: SELECT
                    //Ein drittes Objekt...
                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            //Folgende "Kurzform" arbeitet nur,
                            //weil die gespeicherte Prozedur sicherstellt,
                            //dass keine NULL (System.DBNull.Value) Werte 
                            //geliefert werden...
                            Ergebnis.Add(new Land {
                                ISO = Leser["ISO"].ToString()
                                , Name = Leser["Name"].ToString()
                                , Beschreibung = Leser["Beschreibung"].ToString()
                                , AnzahlZahlen = (int)Leser["AnzahlZahlen"]
                                , HöchsteZahl = (int)Leser["HöchsteZahl"]
                            });
                        }
                    }
                }

            }

            this.AppKontext.Protokoll.Eintragen(
                    $"HoleLänder(\"{sprachCode}\") liefert {Ergebnis.Count} Länder..."
                );

            return Ergebnis;
        }

        /// <summary>
        /// Gibt die Tage zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">ISO Code des Landes, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        public System.DateTime[] HoleZiehungen(string land)
        {
            var Ergebnis = new System.Collections.Generic.List<DateTime>();
            //                 |-------------------------- Hier vertretbar, weil PRIVAT
            //                  So etwas nicht als Typ einer Rückgabe öffentlich benutzen
            //                  In diesen Fällen, wie z. B. bei Fenster und FensterListe in
            //                  einer eigenen Klasse kapseln

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("HoleZiehungen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Parameters.AddWithValue("@land", land);

                    Befehl.Prepare();

                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add((DateTime)Leser["Datum"]);
                        }
                    }
                }
            }

            this.AppKontext.Protokoll.Eintragen(
                    $"HoleZiehungen(\"{land}\") liefert {Ergebnis.Count} Ziehungen..."
                );

            return Ergebnis.ToArray();
        }

        /// <summary>
        /// Gibt die Zahlen einer Lottoziehung
        /// eines Tages für ein Land zurück.
        /// </summary>
        /// <param name="land">ISO Code des Landes, von dem 
        /// die gespeicherte Ziehung benötigt wird.</param>
        /// <param name="vonTag">Datum, an dem die Ziehung stattfand.</param>
        /// <returns>Ein Ziehung-Objekt, wo Land und Datum aber
        /// nicht initialisiert werden.</returns>
        public Ziehung HoleZiehung(string land, DateTime vonTag)
        {

            var Ergebnis = new Ziehung();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("HoleZiehung", Verbindung))
                {

                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@land", land);
                    Befehl.Parameters.AddWithValue("@datum", vonTag);

                    Befehl.Prepare();

                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        //Weil Land und Datum Schlüssel ist,
                        //kommt entweder genau ein Datensatz oder keiner
                        if (Leser.Read())
                        {
                            Ergebnis.Zahl1 = (int)Leser["Zahl1"];
                            Ergebnis.Zahl2 = (int)Leser["Zahl2"];
                            Ergebnis.Zahl3 = (int)Leser["Zahl3"];
                            Ergebnis.Zahl4 = (int)Leser["Zahl4"];
                            Ergebnis.Zahl5 = (int)Leser["Zahl5"];
                            Ergebnis.Zahl6 = (int)Leser["Zahl6"];
                            Ergebnis.Zusatzzahl = (int)Leser["Zusatzzahl"];
                        }
                    }
                }
            }

            return Ergebnis;
        }


        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        public virtual void SpeichereLottoschein(Lottoschein lottoschein)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("SpeichereLottoschein", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@id", lottoschein.Seriennummer);
                    Befehl.Parameters.AddWithValue("@land", lottoschein.Land.ISO);
                    Befehl.Parameters.AddWithValue("@ausstellDatum", lottoschein.Ausstelldatum);
                    Befehl.Parameters.AddWithValue("@gültigBis", lottoschein.GültigBis);

                    Befehl.Prepare();

                    Verbindung.Open();

                    //Um sicherzustellen, dass nur dann alle Änderungen 
                    //gespeichert werden, wenn alle Statements (Anweisungen) 
                    //erfolgreich sind, "Database Transactions" benutzen.
                    Befehl.Transaction = Verbindung.BeginTransaction();

                    Befehl.ExecuteNonQuery();

                    //Schleife für die Tipps
                    Befehl.Parameters.Clear();

                    Befehl.CommandText = "SpeichereTipp";

                    Befehl.Parameters.AddWithValue("@lottoschein", lottoschein.Seriennummer);

                    Befehl.Parameters.Add("@nummer", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl1", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl2", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl3", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl4", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl5", System.Data.SqlDbType.Int);
                    Befehl.Parameters.Add("@zahl6", System.Data.SqlDbType.Int);

                    Befehl.Prepare();

                    for (int i = 0; i < lottoschein.Reihen.Count; i++)
                    {
                        Befehl.Parameters["@nummer"].Value = i + 1;

                        Befehl.Parameters["@zahl1"].Value = lottoschein.Reihen[i].Zahl1;
                        Befehl.Parameters["@zahl2"].Value = lottoschein.Reihen[i].Zahl2;
                        Befehl.Parameters["@zahl3"].Value = lottoschein.Reihen[i].Zahl3;
                        Befehl.Parameters["@zahl4"].Value = lottoschein.Reihen[i].Zahl4;
                        Befehl.Parameters["@zahl5"].Value = lottoschein.Reihen[i].Zahl5;
                        Befehl.Parameters["@zahl6"].Value = lottoschein.Reihen[i].Zahl6;

                        Befehl.ExecuteNonQuery();

                    }

                    //Wenn der Code diese Zeile erreicht,
                    //war jedes Statement erfolgreich und 
                    //kann in der Datenbank gespeichert werden.
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Gibt ein Objekt mit der Verteilung der gespeicherten 
        /// Lottozahlen für das ausgewählte Land zurück.
        /// </summary>
        /// <param name="land">Land, für das die Verteilung geholt werden soll.</param>
        public LottozahlInfoListe HoleVerteilung(Land land)
        {
            var Ergebnis = new LottozahlInfoListe();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("HoleVerteilung", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@land", land.ISO);

                    Befehl.Prepare();

                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(
                                new LottozahlInfo
                                {
                                    Lottozahl = (int)Leser["Lottozahl"],
                                    Anzahl = (int)Leser["Anzahl"]
                                });
                        }
                    }
                }
            }

            return Ergebnis;
        }

    }
}
