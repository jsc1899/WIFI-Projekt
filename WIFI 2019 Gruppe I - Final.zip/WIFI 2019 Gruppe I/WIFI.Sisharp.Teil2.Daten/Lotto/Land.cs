﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Daten.Lotto
{

    /// <summary>
    /// Stellt eine Auflistung von unterstützen
    /// Lottoländern bereit.
    /// </summary>
    public class Länder: System.Collections.ObjectModel.ObservableCollection<Land>
    {

    }

    /// <summary>
    /// Stellt Information über ein Lottoland bereit.
    /// </summary>
    /// <remarks>Hier handelt es sich um ein Datentransferobjekt.</remarks>
    public class Land
    {
        /// <summary>
        /// Ruft das Länderkürzel ab oder legt dieses fest.
        /// </summary>
        /// <remarks>z. B. AT für Österreich</remarks>
        public string ISO { get; set; }

        /// <summary>
        /// Ruft den lesbaren Namen des Landes
        /// ab oder legt diesen fest.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Ruft den Titel des Spiel für das
        /// Land ab oder legt diesen fest.
        /// </summary>
        public string Beschreibung { get; set; }

        /// <summary>
        /// Ruft die größte Lottozahl im
        /// Land ab oder legt diese fest.
        /// </summary>
        public int HöchsteZahl { get; set; }

        /// <summary>
        /// Ruft die Anzahl der Lottozahlen
        /// eines Tipps für das Land ab
        /// oder legt diese fest.
        /// </summary>
        public int AnzahlZahlen { get; set; }
    }
}
