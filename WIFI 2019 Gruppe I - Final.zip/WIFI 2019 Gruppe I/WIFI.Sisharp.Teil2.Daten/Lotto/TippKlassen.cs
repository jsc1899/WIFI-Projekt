﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Daten.Lotto
{
    /// <summary>
    /// Stellt die Daten für einen Lottoschein bereit.
    /// </summary>
    public class Lottoschein
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private System.Guid _Seriennummer = System.Guid.Empty;

        /// <summary>
        /// Ruft die Seriennummer für den Lottoschein ab oder legt sie fest.
        /// </summary>
        /// <remarks>Nicht-sequentielle Technick wird benutzt.
        /// Damit ist die Ermittlung der letzten Nummer nicht notwendig.</remarks>
        public System.Guid Seriennummer
        {
            get
            {
                if (this._Seriennummer == System.Guid.Empty)
                {
                    this._Seriennummer = System.Guid.NewGuid();
                }

                return this._Seriennummer;
            }
            set
            {
                this._Seriennummer = value;
            }
        }

        /// <summary>
        /// Ruft das Land, in dem gespielt wird,
        /// ab oder legt dieses fest.
        /// </summary>
        public Land Land { get; set; }

        /// <summary>
        /// Ruft das Datum ab, an dem der Schein
        /// ausgestellt wurde, oder legt dieses fest.
        /// </summary>
        public System.DateTime Ausstelldatum { get; set; }

        /// <summary>
        /// Ruft das Datum ab, bis zu dem der
        /// Schein gültig ist, oder legt dieses fest.
        /// </summary>
        public System.DateTime GültigBis { get; set; }

        //Todo: Jocker, ...

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private TippListe _Reihen = null;

        /// <summary>
        /// Ruft die getippten Reihen ab oder legt diese fest.
        /// </summary>
        public TippListe Reihen
        {
            get
            {
                if (this._Reihen == null)
                {
                    this._Reihen = new TippListe();
                }

                return this._Reihen;
            }
            set
            {
                this._Reihen = value;
            }
        }

    }

    /// <summary>
    /// Stellt eine Auflistung von Tipps bereit.
    /// </summary>
    public class TippListe : System.Collections.ObjectModel.ObservableCollection<Tipp>
    {

    }

    /// <summary>
    /// Stellt die Zahlen für eine Reihe bereit.
    /// </summary>
    public class Tipp
    {
        /// <summary>
        /// Ruft die erste Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl1 { get; set; }

        /// <summary>
        /// Ruft die zweite Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl2 { get; set; }

        /// <summary>
        /// Ruft die dritte Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl3 { get; set; }

        /// <summary>
        /// Ruft die vierte Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl4 { get; set; }

        /// <summary>
        /// Ruft die fünfte Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl5 { get; set; }

        /// <summary>
        /// Ruft die sechste Zahl ab oder legt diese fest
        /// </summary>
        public int Zahl6 { get; set; }
    }

    /// <summary>
    /// Stellt die Zahlen inkl. der Zusatzzahl
    /// einer Lottoziehung bereit.
    /// </summary>
    public class Ziehung : Tipp
    {

        /// <summary>
        /// Ruft das Land, in dem die Ziehung stattfand,
        /// ab, oder legt dieses fest-
        /// </summary>
        public Land Land { get; set; }

        /// <summary>
        /// Ruft das Datum der Ziehung ab
        /// oder legt dieses fest.
        /// </summary>
        public System.DateTime Datum { get; set; }

        //Die Zahlen sind geerbt

        /// <summary>
        /// Ruft die Zusatzzahl der Ziehung ab,
        /// oder legt diese fest.
        /// </summary>
        public int Zusatzzahl { get; set; }
    }

    /// <summary>
    /// Stellt eine Auflistung von Lottoscheinen bereit.
    /// </summary>
    public class Lottoscheine : System.Collections.ObjectModel.ObservableCollection<Lottoschein>
    {

    }

    /// <summary>
    /// Stellt eine Auflistung von Lottoziehungen bereit.
    /// </summary>
    public class Ziehungen : System.Collections.ObjectModel.ObservableCollection<Ziehung>
    {

    }
}
