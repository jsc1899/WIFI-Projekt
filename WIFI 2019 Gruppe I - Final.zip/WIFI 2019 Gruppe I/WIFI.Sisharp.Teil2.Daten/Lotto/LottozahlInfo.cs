﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Daten.Lotto
{

    /// <summary>
    /// Stellt Informationen über die Verteilung 
    /// der Lottozahlen eines Landes bereit.
    /// </summary>
    public class Information
    {
        /// <summary>
        /// Ruft das Lottoland ab oder legt es fest.
        /// </summary>
        public Land Land { get; set; }

        /// <summary>
        /// Ruft die Liste mit Lottozahlen ab oder legt sie fest.
        /// </summary>
        public LottozahlInfoListe Lottozahlen { get; set; }
    }

    /// <summary>
    /// Stellt eine Liste mit LottozahlInfo-Objekten bereit.
    /// </summary>
    public class LottozahlInfoListe : System.Collections.ObjectModel.ObservableCollection<LottozahlInfo>
    {

    }

    /// <summary>
    /// Beschreibt eine Lottozahl.
    /// </summary>
    public class LottozahlInfo
    {
        /// <summary>
        /// Ruft die Lottozahl ab oder legt sie fest.
        /// </summary>
        public int Lottozahl { get; set; }

        /// <summary>
        /// Ruft die Anzahl, wie oft die Lottozahl 
        /// gespeichert ist, ab, oder legt sie fest.
        /// </summary>
        public int Anzahl { get; set; }
    }
}
