﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Daten.Lotto
{
    /// <summary>
    /// Stellt einen Dienst zum Arbeiten
    /// mit Lottodaten für diverse Länder bereit.
    /// </summary>
    public class LottoManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        /// <remarks>Nur das sollte bei einer anderen
        /// Datenbank ausgetauscht werden müssen.</remarks>
        private LottoSqlController _Controller = null;

        /// <summary>
        /// Ruft den Dienst zum Lesen und Schreiben
        /// der Lottodaten ab.
        /// </summary>
        private LottoSqlController Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<LottoSqlController>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Gibt die unterstützten Lottoländer zurück.
        /// </summary>
        /// <param name="sprache">Die Anwendungsprache,
        /// in der die Namen der Länder geliefert werden sollen.</param>
        public Länder HoleLänder(WIFI.Anwendung.Daten.Sprache sprache)
        {
            try
            {
                return this.Controller.HoleLänder(sprache.Code);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}", 
                    Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Länder();
            }
        }

        /// <summary>
        /// Gibt die Tage zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        public DateTime[] HoleZiehungen(Land land)
        {
            try
            {
                return this.Controller.HoleZiehungen(land.ISO);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new DateTime[0];
            }
        }

        /// <summary>
        /// Gibt die Zahlen einer Ziehung eines Tages in einem Land zurück.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        /// <param name="vonTag">Datum, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        public Ziehung HoleZiehung(Land land, DateTime vonTag)
        {
            try
            {
                var Ergebnis = this.Controller.HoleZiehung(land.ISO, vonTag);

                Ergebnis.Land = land;
                Ergebnis.Datum = vonTag;

                return Ergebnis;
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Ziehung();
            }
        }

        /// <summary>
        /// Gibt einen Lottoschein mit der gewünschten Anzahl an Tipps zurück.
        /// </summary>
        /// <param name="land">Land, für das der Lottoschein erstellt werden soll.</param>
        /// <param name="anzahlTipps">Anzahl der zu berechnenden Tipps.</param>
        public virtual Lottoschein BerechneLottoschein(Land land, int anzahlTipps)
        {
            var NeuerLottoschein = new Lottoschein
            {
                Land = land,
                Ausstelldatum = DateTime.Now
            };

            for (var j = 0; j < anzahlTipps; j++)
            {
                var Zahlen = new int[land.AnzahlZahlen];

                var AktuelleAnzahl = 0;
                var NeueZahl = 0;
                var i = 0;
                var Gefunden = false;

                var N = land.HöchsteZahl + 1;

                do
                {
                    NeueZahl = this.AppKontext.Zufallsgenerator.Next(1, N);
                    i = 0;
                    Gefunden = false;

                    while (i < AktuelleAnzahl && !Gefunden)
                    {
                        if (Zahlen[i] == NeueZahl)
                        {
                            Gefunden = true;
                        }
                        else
                        {
                            i++;
                        }
                    }

                    if (!Gefunden)
                    {
                        //...in einem Array speichern.
                        Zahlen[AktuelleAnzahl] = NeueZahl;
                        AktuelleAnzahl++;
                    }

                } while (AktuelleAnzahl < land.AnzahlZahlen);

                System.Array.Sort(Zahlen);

                var NeuerTipp = new Tipp();
                //Lottozahlen im Tipp speichern
                for (int k = 0; k < land.AnzahlZahlen; k++)
                {
                    NeuerTipp.GetType().GetProperty("Zahl" + (k + 1)).SetValue(NeuerTipp, Zahlen[k]);
                }
                NeuerLottoschein.Reihen.Add(NeuerTipp);
            }

            return NeuerLottoschein;
        }

        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        public void SpeichereLottoschein(Lottoschein lottoschein)
        {
            try
            {
                this.Controller.SpeichereLottoschein(lottoschein);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Gibt die Lottozahlen-Verteilung für 
        /// das ausgewählte Land zurück.
        /// </summary>
        /// <param name="land">Land, für das die 
        /// Lottozahlen-Verteilung abgerufen werden soll.</param>
        public virtual Information HoleVerteilung(Land land)
        {
            var Ergebnis = new Information { Land = land };

            try
            {
                Ergebnis.Lottozahlen = this.Controller.HoleVerteilung(land);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Information();
            }

            return Ergebnis;
        }

    }
}
