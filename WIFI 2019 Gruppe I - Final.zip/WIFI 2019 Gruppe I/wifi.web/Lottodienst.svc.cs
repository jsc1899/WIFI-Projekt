﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WIFI.Anwendung.Daten;
using WIFI.Sisharp.Teil2.Daten.Lotto;

namespace wifi.web
{

    /// <summary>
    /// Stellt einen Dienst zum Arbeiten mit Lottodaten bereit.
    /// </summary>
    public class Lottodienst : System.Web.Services.WebService, ILottodienst
    //                                                  ^-> notwendig, damit wir
    //                                                      Zugriff auf die Webanwendung, den
    //                                                      Server und die Sitzung bekommen
    {

        /// <summary>
        /// Ruft den Dienst zum Arbeiten mit den Lottodaten ab.
        /// </summary>
        /// <remarks>Dieses Objekt wird im Cache der
        /// ASPX Anwendung am Internet Information Server (IIS) hinterlegt.</remarks>
        private WIFI.Sisharp.Teil2.Daten.Lotto.LottoManager Manager
        {
            get
            {
                const string ManagerName = "WIFI.LottoManager";

                var Manager = this.Application[ManagerName] as WIFI.Sisharp.Teil2.Daten.Lotto.LottoManager;

                if (Manager == null)
                {

                    var AppKontext = new WIFI.Anwendung.Daten.DatenAnwendungskontext();
                    //AppKontext.DatenbankPfad = "~/App_Data";
                    //                            ^-> Das Stammverzeichnis der Web Anwendung, z. B. HTTPS://...

                    #region Web.Config mappen...

                    AppKontext.DatenbankPfad = System.Web.Configuration.WebConfigurationManager
                        .AppSettings["DatenbankPfad"];

                    AppKontext.DatenbankPfad =  this.Server.MapPath(AppKontext.DatenbankPfad);
                    //                                          ^-> übersetzt die Web Adresse in
                    //                                              einen physikalischen Pfad
                    AppKontext.SqlServerDatenbank = System.Web.Configuration.WebConfigurationManager
                        .AppSettings["Datenbank"];
                    AppKontext.SqlServer = System.Web.Configuration.WebConfigurationManager
                        .AppSettings["SqlServer"];

                    AppKontext.Protokoll.Pfad = System.Web.Configuration.WebConfigurationManager
                        .AppSettings["ProtokollPfad"];

                    if (AppKontext.Protokoll.Pfad != string.Empty)
                    {
                        AppKontext.Protokoll.Pfad = this.Server.MapPath(AppKontext.Protokoll.Pfad);
                        AppKontext.Protokoll.Pfad = System.IO.Path.Combine(AppKontext.Protokoll.Pfad, "Protokoll.log");
                        //Damit der Server nicht überläuft...
                        AppKontext.Protokoll.Zusammenräumen(5);
                    }

                    #endregion Web.Config mappen

                    Manager = AppKontext.Erzeuge<WIFI.Sisharp.Teil2.Daten.Lotto.LottoManager>();

                    this.Application[ManagerName] = Manager;

                    AppKontext.Protokoll.Eintragen($"{this} hochgefahren und gecachet...");

                }

                return Manager;
            }
        }


        /// <summary>
        /// Gibt die unterstützten Lottoländer zurück.
        /// </summary>
        /// <param name="sprache">Die Anwendungssprache,
        /// die für die Namen der Lottoländer benutzt werden soll.</param>
        public Länder HoleLänder(Sprache sprache)
        {
            this.ErzeugeProtokolleintrag();
            return this.Manager.HoleLänder(sprache);
        }

        /// <summary>
        /// Gibt die Tage zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        public DateTime[] HoleZiehungen(Land land)
        {
            this.ErzeugeProtokolleintrag();
            return this.Manager.HoleZiehungen(land);
        }

        /// <summary>
        /// Gibt die Zahlen einer Ziehung eines Tages in einem Land zurück.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        /// <param name="vonTag">Datum, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        public WIFI.Sisharp.Teil2.Daten.Lotto.Ziehung HoleZiehung(Land land,DateTime vonTag)
        {
            this.ErzeugeProtokolleintrag();
            return this.Manager.HoleZiehung(land, vonTag);
        }

        /// <summary>
        /// Erstellt im Anwendungsprotkoll einen Eintrag,
        /// dass der Webdienst benutzt wurde.
        /// </summary>
        /// <param name="für">Name der Methode, die aufgerufen wurde.</param>
        private void ErzeugeProtokolleintrag([System.Runtime.CompilerServices.CallerMemberName]string für = "")
        {
            this.Manager.AppKontext.Protokoll.Eintragen(
                    $"{für} wird von der IP-Adresse {this.Context.Request.UserHostAddress} benutzt..."
                );
        }

        /// <summary>
        /// Gibt einen Lottoschein mit der gewünschten Anzahl an Tipps zurück.
        /// </summary>
        /// <param name="land">Land, für das der Lottoschein erstellt werden soll.</param>
        /// <param name="anzahlTipps">Anzahl der zu berechnenden Tipps.</param>
        public Lottoschein BerechneLottoschein(Land land, int anzahlTipps)
        {
            this.ErzeugeProtokolleintrag();
            return this.Manager.BerechneLottoschein(land, anzahlTipps);
        }

        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        public void SpeichereLottoschein(Lottoschein lottoschein)
        {
            this.ErzeugeProtokolleintrag();
            this.Manager.SpeichereLottoschein(lottoschein);
        }

        /// <summary>
        /// Gibt die Lottozahlen-Verteilung für 
        /// das ausgewählte Land zurück.
        /// </summary>
        /// <param name="land">Land, für das die 
        /// Lottozahlen-Verteilung abgerufen werden soll.</param>
        public Information HoleVerteilung(Land land)
        {
            this.ErzeugeProtokolleintrag();
            return this.Manager.HoleVerteilung(land);
        }
    }
}
