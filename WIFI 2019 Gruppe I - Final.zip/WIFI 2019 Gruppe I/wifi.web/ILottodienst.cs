﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace wifi.web
{
    /// <summary>
    /// Stellt Methoden zum Arbeiten mit Lottodaten bereit.
    /// </summary>
    [System.ServiceModel.ServiceContract]
    public interface ILottodienst
    {
        /// <summary>
        /// Gibt die unterstützten Lottoländer zurück.
        /// </summary>
        /// <param name="sprache">Die Anwendungssprache,
        /// die für die Namen der Lottoländer benutzt werden soll.</param>
        [System.ServiceModel.OperationContract]
        WIFI.Sisharp.Teil2.Daten.Lotto.Länder HoleLänder(WIFI.Anwendung.Daten.Sprache sprache);

        /// <summary>
        /// Gibt die Tage zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        [System.ServiceModel.OperationContract]
        System.DateTime[] HoleZiehungen(WIFI.Sisharp.Teil2.Daten.Lotto.Land land);

        /// <summary>
        /// Gibt die Zahlen einer Ziehung eines Tages in einem Land zurück.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        /// <param name="vonTag">Datum, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        [System.ServiceModel.OperationContract]
        WIFI.Sisharp.Teil2.Daten.Lotto.Ziehung HoleZiehung(WIFI.Sisharp.Teil2.Daten.Lotto.Land land, DateTime vonTag);

        /// <summary>
        /// Gibt einen Lottoschein mit der gewünschten Anzahl an Tipps zurück.
        /// </summary>
        /// <param name="land">Land, für das der Lottoschein erstellt werden soll.</param>
        /// <param name="anzahlTipps">Anzahl der zu berechnenden Tipps.</param>
        [System.ServiceModel.OperationContract]
        WIFI.Sisharp.Teil2.Daten.Lotto.Lottoschein BerechneLottoschein(WIFI.Sisharp.Teil2.Daten.Lotto.Land land, int anzahlTipps);

        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        [System.ServiceModel.OperationContract]
        void SpeichereLottoschein(WIFI.Sisharp.Teil2.Daten.Lotto.Lottoschein lottoschein);

        /// <summary>
        /// Gibt die Lottozahlen-Verteilung für 
        /// das ausgewählte Land zurück.
        /// </summary>
        /// <param name="land">Land, für das die 
        /// Lottozahlen-Verteilung abgerufen werden soll.</param>
        [System.ServiceModel.OperationContract]
        WIFI.Sisharp.Teil2.Daten.Lotto.Information HoleVerteilung(WIFI.Sisharp.Teil2.Daten.Lotto.Land land);
    }

}
