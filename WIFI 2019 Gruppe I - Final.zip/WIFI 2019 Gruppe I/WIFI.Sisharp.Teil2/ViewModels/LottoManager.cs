﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.ViewModels
{
    /// <summary>
    /// Stellt einen Dienst zum Verwalten
    /// der Lotto-Oberfläche bereit.
    /// </summary>
    public class LottoManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /*
        private Model.LottoController _Controller = null;
        private Model.LottodienstClient _Controller = null;
        */

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.ILottodienst _Controller = null;

        /// <summary>
        /// Ruft den Dienst ab, mit dem die
        /// Lottozahlen verwaltet werden.
        /// </summary>
        /// <remarks>Über die Anwendungskonfiguration
        /// kann gesteuert, ob eine lokale Assembly oder
        /// der Webdienst benutzt wird.</remarks>
        private Model.ILottodienst Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    if (WIFI.Sisharp.Teil2.Properties.Settings.Default.Online)
                    {
                        this._Controller = new Model.LottodienstClient();
                    }
                    else
                    {
                        this._Controller = this.AppKontext.Erzeuge<Model.LottoController>();
                    }
                }
                return this._Controller;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private static Model.Land[] _Länder = null;
        //                    ^-> Ist eine Klasse WIFI.Sisharp.Teil2.Model.Land vom Webdienst
        //                       (In Wirklichkeitkeit WIFI.Sisharp.Teil2.Daten.Lotto.Land)
        //                         ===> Das sind ZWEI VERSCHIEDENE OBJEKTE (Klassen) !!!

        /// <summary>
        /// Ruft die Liste mit den unterstützen Lottoländern ab.
        /// </summary>
        public Model.Land[] Länder
        {
            get
            {
                //Die C# Schlüsselwörter async und await funktionieren
                //nur mit Methoden!!!
                this.InitialisiereLänderAsync();

                if (this._AktuellesLand == null 
                    && LottoManager._Länder != null 
                    && LottoManager._Länder.Length > 0)
                {

                    var StandardLand = (from l in LottoManager._Länder
                                        where string.Compare(
                                            l.ISO, WIFI.Sisharp.Teil2.Properties
                                            .Settings.Default.AktuellesLand,
                                            ignoreCase: true) == 0
                                        select l).FirstOrDefault();

                    if (StandardLand == null)
                    {
                        this.AktuellesLand = LottoManager._Länder[0];
                        this.AppKontext.Protokoll.Eintragen(
                            $"Das Standardland mit ISO=\"{WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuellesLand}\" wurde nicht gefunden!",
                            Anwendung.Daten.ProtokollEintragTyp.Fehler);
                    }
                    else
                    {
                        this.AktuellesLand = StandardLand;
                    }
                }

                return LottoManager._Länder;
            }
        }

        /// <summary>
        /// Internes Hilfsfeld
        /// </summary>
        private bool _InitialisiereLänderLäuft = false;

        /// <summary>
        /// Initialisiert die Lottoländer ohne
        /// den Rest der Anwendung zu blockieren.
        /// </summary>
        protected virtual async void InitialisiereLänderAsync()
        {
            //Hr. Panholzer: Damit InitialisiereLänderAsync() nicht wiederholt
            //               im Protokoll eingetragen wird...
            //this.Besitzer.AktiviereBeschäftigt();
            //=> in die if-Anweisung...

            if (!this._InitialisiereLänderLäuft && LottoManager._Länder == null)
            {
                this._InitialisiereLänderLäuft = true;
                this.Besitzer.AktiviereBeschäftigt();

                try
                {
                    LottoManager._Länder = await this.Controller.HoleLänderAsync(this.AppKontext.Sprachen.AktuelleSprache);
                    this.OnPropertyChanged("Länder");
                }
                catch (System.Exception ex)
                {
                    //Damit wir im Fehlerfall nicht wiederholt
                    //versuchen, die Daten zu holen
                    LottoManager._Länder = new Model.Land[0];
                    this.AppKontext.Protokoll.Eintragen(ex.Message, Anwendung.Daten.ProtokollEintragTyp.Fehler);
                }

                this._InitialisiereLänderLäuft = false;
                this.Besitzer.DeaktiviereBeschäftigt();

            }

        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Land _AktuellesLand = null;

        /// <summary>
        /// Ruft das aktuelle Land ab,
        /// oder legt dieses fest
        /// </summary>
        public Model.Land AktuellesLand
        {
            get
            {
                return this._AktuellesLand;
            }
            set
            {
                if (this._AktuellesLand != value)
                {
                    this._AktuellesLand = value;
                    this.OnPropertyChanged();
                    this.OnPropertyChanged("Beschreibung");
                    this._TageMitZiehung = null;
                    this.OnPropertyChanged("TageMitZiehung");
                }
                this._Verteilung = null;
                this.OnPropertyChanged("Verteilung");

            }
        }

        /// <summary>
        /// Ruft den Titel des Lottospiels
        /// im eingestellten Land ab.
        /// </summary>
        public string Beschreibung
        {
            get
            {
                if (this._AktuellesLand != null)
                {
                    return this._AktuellesLand.Beschreibung;
                }
                
                return string.Empty;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Lottomanager initialisiert hat,
        /// ab oder legt diesen 
        /// </summary>
        public FensterManager Besitzer { get; set; }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _LandAlsStandardFestlegen = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem ein
        /// Land als Standard festgelegt werden kann.
        /// </summary>
        public WIFI.Windows.Befehl LandAlsStandardFestlegen
        {
            get
            {
                if (this._LandAlsStandardFestlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._LandAlsStandardFestlegen = new Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuellesLand = this.AktuellesLand.ISO;

                            this.AppKontext.Protokoll.Eintragen(
                                $"Die Anwendung hat das Land \"{this.AktuellesLand.Name}\" (ISO = {WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuellesLand}) als Standard festgelegt...");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        //CanExecute Methode...
                        daten => this.AktuellesLand != null
                        );

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._LandAlsStandardFestlegen;
            }
        }


        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _LänderAktualisieren = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem die
        /// Länder neu abgerufen werden können.
        /// </summary>
        public WIFI.Windows.Befehl LänderAktualisieren
        {
            get
            {
                if (this._LänderAktualisieren == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._LänderAktualisieren = new Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.AppKontext.Protokoll.Eintragen("Die Liste mit den Ländern wird aktualisiert...");

                            //Zum Aktualisieren der Länder 
                            //einfach den Cache entfernen
                            LottoManager._Länder = null;
                            //Damit diese erneut abgerufen werden...
                            this.OnPropertyChanged("Länder");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                    );
                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._LänderAktualisieren;
            }
        }

        /// <summary>
        /// Internes Hilfsfeld zum asynchronen
        /// Abrufen der Liste mit Tagen, an denen
        /// eine Lottoziehung gespeichert ist.
        /// </summary>
        private bool _InitialisiereTageMitZiehungLäuft = false;

        /// <summary>
        /// Ruft die Tage mit einer gespeicherten
        /// Lottoziehung asynchron ab.
        /// </summary>
        protected virtual async void InitialisiereTageMitZiehungAsync()
        {
            if (!this._InitialisiereTageMitZiehungLäuft
                && this._TageMitZiehung == null
                && this.AktuellesLand != null)
            {
                this._InitialisiereTageMitZiehungLäuft = true;
                this.Besitzer.AktiviereBeschäftigt();

                this._TageMitZiehung = await this.Controller.HoleZiehungenAsync(this.AktuellesLand);

                this.OnPropertyChanged("TageMitZiehung");
                this.OnPropertyChanged("ZiehungVon");

                this._InitialisiereTageMitZiehungLäuft = false;
                this.Besitzer.DeaktiviereBeschäftigt();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private DateTime[] _TageMitZiehung = null;

        /// <summary>
        /// Ruft für das aktuelle Land die Tage
        /// mit einer gespeicherten Lottoziehung ab.
        /// </summary>
        public DateTime[] TageMitZiehung
        {
            get
            {
                this.InitialisiereTageMitZiehungAsync();

                return this._TageMitZiehung;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        /// <remarks>Statisch, weil zur Laufzeit
        /// der Betriebsmodus nicht gewechselt werden kann.</remarks>
        private static string _Modus = null;

        /// <summary>
        /// Ruft den Betriebsmodus der Anwendung ab.
        /// </summary>
        /// <remarks>"offline", falls kein Webdienst 
        /// benutzt wird, sonst die URL des Webdienstes.</remarks>
        public string Modus
        {
            get
            {
                if (LottoManager._Modus == null)
                {
                    if (WIFI.Sisharp.Teil2.Properties.Settings.Default.Online)
                    {
                        //Die URL vom Webdienst ermitteln...
                        var Konfiguration = System.Configuration.ConfigurationManager.GetSection("system.serviceModel/client")
                            as System.ServiceModel.Configuration.ClientSection;

                        if (Konfiguration != null && Konfiguration.Endpoints.Count > 0)
                        {
                            LottoManager._Modus = Konfiguration.Endpoints[0].Address.ToString();
                        }
                        else
                        {
                            LottoManager._Modus = "online";
                        }
                    }
                    else
                    {
                        LottoManager._Modus = "offline";
                    }
                }

                return LottoManager._Modus;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private DateTime? _ZiehungVon = null;

        /// <summary>
        /// Ruft das Datum der benötigten Ziehung ab
        /// oder legt dieses fest.
        /// </summary>
        public DateTime? ZiehungVon
        {
            get
            {
                if (this._ZiehungVon == null 
                    && this._TageMitZiehung != null 
                    && this._TageMitZiehung.Length > 0)
                {
                    this._ZiehungVon = this._TageMitZiehung[0];
                    //Damit der WPF Eingabemanager
                    //die Gültigkeit der Befehle neu prüft...
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
                }

                return this._ZiehungVon;
            }
            set
            {
                if (this._ZiehungVon != value)
                {

                    this._AktuelleZiehung = null;
                    this.OnPropertyChanged("AktuelleZiehung");

                    this._ZiehungVon = value;
                    this.OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _HoleZiehung = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem die
        /// Zahlen einer Lottoziehung abgerufen werden können.
        /// </summary>
        public WIFI.Windows.Befehl HoleZiehung
        {
            get
            {
                if (this._HoleZiehung == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._HoleZiehung = new Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._AktuelleZiehung
                                    = this.Controller.HoleZiehung(
                                                    this.AktuellesLand,
                                                    this.ZiehungVon.Value);

                            this.OnPropertyChanged("AktuelleZiehung");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        //Aktuell erlaubt?
                        daten => this.ZiehungVon != null && this._AktuelleZiehung == null
                    );
                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._HoleZiehung;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Ziehung _AktuelleZiehung = null;

        /// <summary>
        /// Ruft die Zahlen einer Ziehung ab.
        /// </summary>
        public Model.Ziehung AktuelleZiehung
        {
            get
            {
                return this._AktuelleZiehung;
            }
        }






        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private int _AnzahlTipps = 1;

        /// <summary>
        /// Ruft die Anzahl der Tipps für einen 
        /// Lottoschein ab oder legt sie fest.
        /// </summary>
        public int AnzahlTipps
        {
            get
            {
                return this._AnzahlTipps;
            }
            set
            {
                this._AnzahlTipps = value;
                this.OnPropertyChanged();

                this.AktuellerLottoschein = null;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private DateTime? _GültigBis = null;

        /// <summary>
        /// Ruft das Datum ab bis zu dem der Lottoschein 
        /// gültig ist, oder legt es fest.
        /// </summary>
        public DateTime? GültigBis
        {
            get
            {
                return this._GültigBis;
            }
            set
            {
                this._GültigBis = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Windows.Befehl _BerechneLottoschein = null;

        /// <summary>
        /// Ruft den Befehl zum Berechnen einen Lottoscheins ab.
        /// </summary>
        public Windows.Befehl BerechneLottoschein
        {
            get
            {
                if (this._BerechneLottoschein == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BerechneLottoschein = new Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.AktuellerLottoschein = this.Controller.BerechneLottoschein(this.AktuellesLand, this.AnzahlTipps);
                            this.AktuellerLottoschein.GültigBis = this.GültigBis.Value;

                            this.SpeichereLottoscheinLäuft = false;

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.GültigBis.HasValue);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BerechneLottoschein;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Lottoschein _AktuellerLottoschein = null;

        /// <summary>
        /// Ruft den aktuellen Lottoschein ab oder legt ihn fest.
        /// </summary>
        public Model.Lottoschein AktuellerLottoschein
        {
            get
            {
                return this._AktuellerLottoschein;
            }
            set
            {
                this._AktuellerLottoschein = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _SpeichereLottoscheinLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob der Lottoschein 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool SpeichereLottoscheinLäuft
        {
            get
            {
                return this._SpeichereLottoscheinLäuft;
            }
            set
            {
                this._SpeichereLottoscheinLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Windows.Befehl _SpeichereLottoschein = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Lottoscheins ab.
        /// </summary>
        public Windows.Befehl SpeichereLottoschein
        {
            get
            {
                if (this._SpeichereLottoschein == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._SpeichereLottoschein = new Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.SpeichereLottoscheinLäuft = true;

                            this.Controller.SpeichereLottoschein(this.AktuellerLottoschein);

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellerLottoschein != null && !this.SpeichereLottoscheinLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._SpeichereLottoschein;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Information _Verteilung = null;

        /// <summary>
        /// Ruft die Lottozahlen-Verteilung für das ausgewählte Land ab.
        /// </summary>
        public Model.Information Verteilung
        {
            get
            {
                if (this._Verteilung == null && this.AktuellesLand != null)
                {
                    this.Besitzer.AktiviereBeschäftigt();
                    this._Verteilung = this.Controller.HoleVerteilung(this.AktuellesLand);
                    this.Besitzer.DeaktiviereBeschäftigt();
                }
                return this._Verteilung;
            }
        }
        
    }
}
