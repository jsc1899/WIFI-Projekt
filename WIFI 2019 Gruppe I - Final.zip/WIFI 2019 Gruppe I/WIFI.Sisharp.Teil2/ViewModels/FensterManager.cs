﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.ViewModels
{
    /// <summary>
    /// Steuert die Hauptoberfläche der Anwendung.
    /// </summary>
    /// <remarks>Im Rahmen von MVVM handelt es sich um
    /// ein VM (ViewModel) Objekt.</remarks>
    public class FensterManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Wird vom Starten initialisiert und
        /// beim Anzeigen eines neuens Fensters benötigt.
        /// </summary>
        private static Type _FensterTyp = null;

        /// <summary>
        /// Zeigt ein Fenster des gewünschten Typs an
        /// und macht es zum Hauptfenster der WPF Anwendung.
        /// </summary>
        /// <typeparam name="T">Der Typ der anzuzeigenden View.</typeparam>
        public void Starten<T>() where T : System.Windows.Window, new()
        {

            this.AktiviereBeschäftigt("ViewModel");

            FensterManager._FensterTyp = typeof(T);

            //var Fenster = new T();
            //var Fenster = System.Activator.CreateInstance<T>();
            //damit trotzdem new funktioniert, eine Typeinschränkung...

            var Fenster = new T();

            this.InitialisiereFenster(Fenster);

            //Das ViewModel und die View "verknüpfen"...
            Fenster.DataContext = this;

            this.DeaktiviereBeschäftigt("ViewModel");

            System.Windows.Application.Current.Run(Fenster);
        }

        /// <summary>
        /// Bereitet ein Fenster für die Anzeige vor.
        /// </summary>
        /// <param name="fenster">Das Fenster-Objekt,
        /// das vorbereitet werden soll.</param>
        protected virtual void InitialisiereFenster(System.Windows.Window fenster)
        {
            this.AktiviereBeschäftigt();

            //Damit xml keine Probleme beim Formatieren
            //von Datumsangaben und anderen Zahlen hat...
            fenster.Language 
                = System.Windows.Markup.XmlLanguage.GetLanguage(
                    System.Threading.Thread.CurrentThread.CurrentCulture.IetfLanguageTag);

            //Dazu dem Fenster einen Namen verpassen
            fenster.Name = fenster.GetType().Name;

            //Zum Unterscheiden der Fenster 
            //eine Nummer so anhängen, dass
            //die erste freie Nummer wiederbenutzt wird.

            //Gut, aber aus... LINQ nicht implementiert
            //var OffeneFenster = (from f in System.Windows.Application.Current.Windows select f).ToArray();
            
            //Also, eine eigene Liste mit den aktuellen Fensternamen aufbauen
            var OffeneFenster = new System.Collections.ArrayList(System.Windows.Application.Current.Windows.Count);
            foreach (System.Windows.Window w in System.Windows.Application.Current.Windows)
            {
                OffeneFenster.Add(w.Name);
            }

            var FreieNummer = 1;
            while (OffeneFenster.Contains(fenster.Name + FreieNummer))
            {
                FreieNummer++;
            }

            fenster.Name += FreieNummer;

            //Eine alte Fensterposition wiederherstellen...
            var AltePosition = this.AppKontext.Fenster.Abrufen(fenster.Name);

            if (AltePosition != null)
            {
                fenster.Left = AltePosition.Links ?? fenster.Left;
                fenster.Top = AltePosition.Oben ?? fenster.Top;
                fenster.Width = AltePosition.Breite ?? fenster.Width;
                fenster.Height = AltePosition.Höhe ?? fenster.Height;

                //Nur Maximiert wiederherstellen, sonst normal,
                //weil minimierte Fenster von den Benutzern übersehen werden
                fenster.WindowState =
                    (System.Windows.WindowState)AltePosition.Zustand == System.Windows.WindowState.Maximized ?
                    System.Windows.WindowState.Maximized : System.Windows.WindowState.Normal;

            }

            //Dafür sorgen, dass beim Schließen
            //die Fensterposition gespeichert wird
            //(dazu ein anonymer Ereignisbehandler)
            fenster.Closing += (sender, e) =>
            {
                //Hr. Grabner; 20190214
                //-> Den CallerMemberName wegen der
                //   anonymen Methode überschreiben
                //this.AktiviereBeschäftigt();
                this.AktiviereBeschäftigt("FensterPositionSpeichern");

                var Position = new WIFI.Anwendung.Daten.Fenster { Name = fenster.Name };

                //Position initialisieren:

                //Auf alle Fälle den Zustand
                Position.Zustand = (int)fenster.WindowState;

                //Die Größenangaben nur, falls ein normales Fenster
                if (fenster.WindowState == System.Windows.WindowState.Normal)
                {
                    Position.Links = (int)fenster.Left;
                    Position.Oben = (int)fenster.Top;
                    Position.Breite = (int)fenster.Width;
                    Position.Höhe = (int)fenster.Height;
                }

                this.AppKontext.Fenster.Hinterlegen(Position);

                //Hr. Grabner; 20190214
                //-> Den CallerMemberName wegen der
                //   anonymen Methode überschreiben
                //this.DeaktiviereBeschäftigt();
                this.DeaktiviereBeschäftigt("FensterPositionSpeichern");

                //Damit die Garbage Collection das
                //WPF Fenster entfernt (nirgendwo ein Dispose)
                //den DataContext freigeben, weil sonst
                //Speicherloch auftritt...
                fenster.DataContext = null;
            };

            this.DeaktiviereBeschäftigt();
        }

        /// <summary>
        /// Ruft die aktuelle Anwendungssprache
        /// ab oder legt diese fest.
        /// </summary>
        public WIFI.Anwendung.Daten.Sprache AktuelleSprache
        {
            get
            {
                return this.AppKontext.Sprachen.AktuelleSprache;
            }
            set
            {

                //Weil mehrere Instanzen von dem Fenster offen sein
                //können, nur ein Hinweis, dass zum Wechseln der
                //Sprache neu gestartet werden muss...
                if (this.AppKontext.Sprachen.AktuelleSprache.Code != value.Code)
                {
                    System.Windows.MessageBox.Show(
                        Properties.Texte.Sprachwechsel, 
                        Properties.Texte.Anwendungstitel, 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Information);

                    this.AppKontext.Protokoll.Eintragen(
                        Properties.Texte.Sprachwechsel, 
                        Anwendung.Daten.ProtokollEintragTyp.Fehler);
                }

                this.AppKontext.Sprachen.AktuelleSprache = value;
                //Wichtig:
                //-> Damit WPF eine Änderung mitbekommt,
                //   muss ein Ereignis PropertyChanged ausgelöst werden
                //this.OnPropertyChanged("AktuelleSprache");
                //                          ^-> fad
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _AndereSchließen = null;

        /// <summary>
        /// Ruft den Befehl zum Schließen aller
        /// anderen Fenster ab.
        /// </summary>
        /// <remarks>Befehl ist nur erlaubt, wenn
        /// mehr als ein Fenster offen ist. Das Fenster,
        /// welches offen bleiben muss, über die CommandParameter
        /// Eigenschaft übergeben.</remarks>
        public WIFI.Windows.Befehl AndereSchließen
        {
            get
            {

                if (this._AndereSchließen == null)
                {
                    this.AktiviereBeschäftigt();

                    this._AndereSchließen = new Windows.Befehl(
                        //Execute...
                        daten =>
                        {
                            //20190305 Fr. Bauer
                            //  Ohne CommandParameter könnte vom Fenster
                            //  die IsActivate - Mehtode benutzt werden
                            //  Kann allerdings sein, dass, wenn eine
                            //  Anwendung "ferngesteuert" wird, diese
                            //  nicht aktiv ist und die Lösung nicht arbeitet.
                            this.AktiviereBeschäftigt();

                            var AktuellesFenster = daten as System.Windows.Window;

                            foreach (System.Windows.Window w in System.Windows.Application.Current.Windows)
                            {
                                if (w != AktuellesFenster)
                                {
                                    w.Close();
                                }
                            }


                            this.DeaktiviereBeschäftigt();
                        },
                        //CanExecute...
                        daten => System.Windows.Application.Current.Windows.Count > 1
                        );

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");
                    this.DeaktiviereBeschäftigt();
                }

                return this._AndereSchließen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _AllesSchließen = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem alle offenen
        /// Fenster geschlossen werden.
        /// </summary>
        /// <remarks>Nur zulässig, wenn mehr als ein Fenster offen sind.</remarks>
        public WIFI.Windows.Befehl AllesSchließen
        {

            //Änderungen:
            //  20190312    Der Benutzer wird gefragt, ob
            //              wirklich alle Fenster geschlossen
            //              werden sollen

            get
            {
                if (this._AllesSchließen == null)
                {

                    this.AktiviereBeschäftigt();

                    this._AllesSchließen = new Windows.Befehl(
                        daten =>
                        {
                            var Antwort = System.Windows.MessageBox.Show(
                                Properties.Texte.AllesSchließenFrage, 
                                Properties.Texte.Anwendungstitel, 
                                System.Windows.MessageBoxButton.YesNo, 
                                System.Windows.MessageBoxImage.Question);

                            if (Antwort == System.Windows.MessageBoxResult.Yes)
                            {
                                this.AktiviereBeschäftigt();
                                foreach (System.Windows.Window f in System.Windows.Application.Current.Windows)
                                {
                                    f.Close();
                                }
                                this.DeaktiviereBeschäftigt();
                            }
                        },
                        daten => System.Windows.Application.Current.Windows.Count > 1
                        );

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._AllesSchließen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _NeuesFenster = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem
        /// ein neues Anwendungsfenster geöffnet wird.
        /// </summary>
        public WIFI.Windows.Befehl NeuesFenster
        {
            get
            {
                if (this._NeuesFenster == null)
                {

                    this.AktiviereBeschäftigt();

                    this._NeuesFenster = new Windows.Befehl(daten =>
                    {

                        this.AktiviereBeschäftigt();

                        var f = System.Activator.CreateInstance(FensterManager._FensterTyp) as System.Windows.Window;

                        this.InitialisiereFenster(f);

                        //Die "View" mit dem "ViewModel" verknüpfen
                        //Dazu eine neues Instanz des ViewModels
                        //erstellen, damit die Fenster unabhängig arbeiten...
                        var vm = this.AppKontext.Erzeuge<FensterManager>();
                        f.DataContext = vm;

                        f.Show();

                        this.DeaktiviereBeschäftigt();
                    });

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._NeuesFenster;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgaben _Aufgaben = null;

        /// <summary>
        /// Ruft die Anwendungspunkte ab.
        /// </summary>
        public Model.Aufgaben Aufgaben
        {
            get
            {
                if (this._Aufgaben == null)
                {
                    this.AktiviereBeschäftigt();

                    var AufgabenManager = this.AppKontext.Erzeuge<Model.AufgabenManager>();
                    this._Aufgaben = AufgabenManager.Liste;

                    this.AppKontext.Protokoll.Eintragen("Das Fenster hat die Aufgaben gecachet...");

                    //Die Standardaufgabe aktivieren...
                    var i = WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuelleAufgabe;
                    if (this._Aufgaben != null && i < this._Aufgaben.Count)
                    {
                        this.AktuelleAufgabe = this._Aufgaben[i];
                        this.AppKontext.Protokoll.Eintragen($"Die Aufgabe \"{this.AktuelleAufgabe.Name}\" wurde aktiviert...");
                    }

                    this.DeaktiviereBeschäftigt();
                }

                return this._Aufgaben;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Model.Aufgabe _AktuelleAufgabe = null;

        /// <summary>
        /// Ruft den aktuellen Anwendungspunkt
        /// ab oder legt diesen fest.
        /// </summary>
        public Model.Aufgabe AktuelleAufgabe
        {
            get
            {
                return this._AktuelleAufgabe;
            }
            set
            {
                this._AktuelleAufgabe = value;

                if (this._AktuelleAufgabe.Arbeitsbereich == null 
                    && this._AktuelleAufgabe.ArbeitsbereichTyp != null)
                {
                    this._AktuelleAufgabe.Arbeitsbereich
                        = System.Activator.CreateInstance(this._AktuelleAufgabe.ArbeitsbereichTyp)
                        as System.Windows.Controls.UserControl;
                }

                //Falls das Protkoll geöffnet wird,
                //unbestätigte Fehler zurücksetzen
                if (this._AktuelleAufgabe.Arbeitsbereich is ProtokollViewer)
                {
                    this.AppKontext.Protokoll.FehlerVorhanden = false;
                }

                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _AufgabeAlsStandardFestlegen = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem eine
        /// Aufgabe als Standard festgelegt werden kann.
        /// </summary>
        public WIFI.Windows.Befehl AufgabeAlsStandardFestlegen
        {
            get
            {
                if (this._AufgabeAlsStandardFestlegen == null)
                {
                    this.AktiviereBeschäftigt();

                    this._AufgabeAlsStandardFestlegen = new Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.AktiviereBeschäftigt();

                            WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuelleAufgabe
                                = this.Aufgaben.IndexOf(this.AktuelleAufgabe);

                            this.AppKontext.Protokoll.Eintragen(
                                $"Die Anwendung hat die Aufgabe \"{this.AktuelleAufgabe.Name}\" (Index = {WIFI.Sisharp.Teil2.Properties.Settings.Default.AktuelleAufgabe}) als Standard festgelegt...");

                            this.DeaktiviereBeschäftigt();
                        },
                        //CanExecute Methode...
                        daten => this.AktuelleAufgabe != null
                        );

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._AufgabeAlsStandardFestlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private ViewModels.LottoManager _LottoManager = null;

        /// <summary>
        /// Ruft das ViewModel zum Steuern
        /// der Lottooberfläche ab.
        /// </summary>
        public ViewModels.LottoManager LottoManager
        {
            get
            {
                if (this._LottoManager == null)
                {
                    this.AktiviereBeschäftigt();

                    this._LottoManager = this.AppKontext.Erzeuge<ViewModels.LottoManager>();
                    this._LottoManager.Besitzer = this;

                    this.DeaktiviereBeschäftigt();
                }

                return this._LottoManager;
            }
        }

    }
}