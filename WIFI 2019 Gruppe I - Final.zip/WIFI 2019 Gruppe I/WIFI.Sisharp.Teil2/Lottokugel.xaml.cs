﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WIFI.Sisharp.Teil2
{
    /// <summary>
    /// Visualisiert eine Lottozahl
    /// </summary>
    public partial class Lottokugel : UserControl
    {
        /// <summary>
        /// Initialisiert eine neue Lottokugel.
        /// </summary>
        public Lottokugel()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Registriert die Zahl Eigenschaft für die Datenbindung
        /// </summary>
        /// <remarks>Funktioniert bei Klassen, die DependencyObject erweitern.</remarks>
        public static System.Windows.DependencyProperty ZahlProperty
        //                                                  |--- muss, damit der Designer das erkennt, auf
        //                                                       "Property" enden
            = System.Windows.DependencyProperty.Register("Zahl", typeof(int?), typeof(Lottokugel));

        /// <summary>
        /// Ruft den Wert dieser Kugel ab
        /// oder legt diesen fest.
        /// </summary>
        /// <remarks>Damit die Eigenschaft für
        /// die Datenbindung benutzt werden kann,
        /// darf kein eigenes Feld verwendet werden.
        /// Es muss ein Dependency-Property sein.</remarks>
        public int? Zahl
        {
            get
            {
                return this.GetValue(Lottokugel.ZahlProperty) as int?;
            }
            set
            {
                this.SetValue(Lottokugel.ZahlProperty, value);
            }
        }
    }
}
