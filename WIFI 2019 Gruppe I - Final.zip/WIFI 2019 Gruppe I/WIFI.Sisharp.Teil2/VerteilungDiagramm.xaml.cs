﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WIFI.Sisharp.Teil2
{
    /// <summary>
    /// Zeigt ein Diagramm mit der Lottozahlen-Verteilung an.
    /// </summary>
    public partial class VerteilungDiagramm : UserControl
    {
        /// <summary>
        /// Initialisiert ein neues Verteilungsdiagramm-Objekt.
        /// </summary>
        public VerteilungDiagramm()
        {
            InitializeComponent();

            //Weil es hier keine PropertyChanged Ereignisse gibt...
            var Daten = System.ComponentModel.DependencyPropertyDescriptor
                .FromName("Daten", typeof(VerteilungDiagramm), typeof(VerteilungDiagramm));

            if (Daten != null)
            {
                Daten.AddValueChanged(this, (sender, e) => this.InvalidateVisual());
            }
        }

        /// <summary>
        /// Registriert die Daten-Eigenschaft für die Datenbindung.
        /// </summary>
        public static DependencyProperty DatenProperty
            = DependencyProperty.Register("Daten", typeof(Model.Information), typeof(VerteilungDiagramm));

        /// <summary>
        /// Ruft die Lottozahlen-Informationen ab oder legt sie fest.
        /// </summary>
        public Model.Information Daten
        {
            get
            {
                return this.GetValue(VerteilungDiagramm.DatenProperty) as Model.Information;
            }
            set
            {
                this.SetValue(VerteilungDiagramm.DatenProperty, value);

                //Hier gibt es kein OnPropertyChanged.
            }
        }

        /// <summary>
        /// Löst das Zeichnen-Ereignis aus.
        /// </summary>
        /// <param name="drawingContext">The WPF object to draw some stuff.</param>
        /// <remarks>Extended to draw the chart.</remarks>
        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);

            if (this.Daten != null && this.Daten.Land != null && this.Daten.Land.ISO != null)
            {
                const int RasterStufen = 12;

                double dX = this.ActualWidth / RasterStufen;  //Breite einer Rasterstufe
                double dY = this.ActualHeight / RasterStufen; //Höhe einer Rasterstufe

                double StufeX = (RasterStufen - 2) * dX / (this.Daten.Land.HöchsteZahl - 1);

                int MaximaleAnzahl = (from zahl in this.Daten.Lottozahlen select zahl.Anzahl).Max();
                double MaximaleHöhe = (RasterStufen - 2) * dY;

                var TopZahlen = (from zahl in this.Daten.Lottozahlen
                                 orderby zahl.Anzahl descending
                                 select zahl).Take(this.Daten.Land.AnzahlZahlen);

                var Stift = new System.Windows.Media.Pen(System.Windows.Media.Brushes.Black, 1);
                var Schrift = new Typeface(this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch);
                var Schriftfarbe = System.Windows.Media.Brushes.Black;

                foreach (var zahl in this.Daten.Lottozahlen)
                {
                    if (TopZahlen.Contains(zahl))
                    {
                        Stift = new System.Windows.Media.Pen(System.Windows.Media.Brushes.Red, 2);
                        Schrift = new Typeface(this.FontFamily, this.FontStyle, FontWeights.Bold, this.FontStretch);
                        Schriftfarbe = System.Windows.Media.Brushes.Red;
                    }
                    else
                    {
                        Stift = new System.Windows.Media.Pen(System.Windows.Media.Brushes.Black, 1);
                        Schrift = new Typeface(this.FontFamily, this.FontStyle, this.FontWeight, this.FontStretch);
                        Schriftfarbe = System.Windows.Media.Brushes.Black;
                    }

                    //Linie
                    var Höhe = MaximaleHöhe * zahl.Anzahl / MaximaleAnzahl;

                    drawingContext.DrawLine(
                        Stift,
                        new Point(dX + StufeX * (zahl.Lottozahl - 1), (RasterStufen - 1) * dY),
                        new Point(dX + StufeX * (zahl.Lottozahl - 1), (RasterStufen - 1) * dY - Höhe));

                    //Beschriftung
                    var Text = new System.Windows.Media.FormattedText(
                        zahl.Lottozahl.ToString(),
                        System.Threading.Thread.CurrentThread.CurrentCulture,
                        FlowDirection.LeftToRight,
                        Schrift,
                        this.FontSize,
                        Schriftfarbe);

                    drawingContext.DrawText(
                        Text,
                        new Point(
                            dX + StufeX * (zahl.Lottozahl - 1) - Text.Width / 2,
                            (RasterStufen - 1) * dY - Höhe - Text.Height));
                }

                //Achsen
                Stift = new System.Windows.Media.Pen(System.Windows.Media.Brushes.LightGray, 2);

                //X-Achse
                drawingContext.DrawLine(
                    Stift,
                    new Point(dX / 2, (RasterStufen - 1) * dY),
                    new Point((RasterStufen - 1) * dX + (dX / 2), (RasterStufen - 1) * dY));

                //Y-Achse
                drawingContext.DrawLine(
                    Stift,
                    new Point(dX / 2, dY),
                    new Point(dX / 2, (RasterStufen - 1) * dY));

                //Hilfslinien
                Stift = new System.Windows.Media.Pen(System.Windows.Media.Brushes.LightGray, 0.5);
                int HilfslinienEinschub = 10;
                double HilfslinienStufe = ((RasterStufen - 2) * dY) / MaximaleAnzahl;

                int Schrittgröße = 1;
                if (MaximaleAnzahl >= 5000) Schrittgröße = MaximaleAnzahl / 5 - (MaximaleAnzahl / 5) % 1000;
                else if (MaximaleAnzahl >= 500) Schrittgröße = MaximaleAnzahl / 5 - (MaximaleAnzahl / 5) % 100;
                else if (MaximaleAnzahl >= 50) Schrittgröße = MaximaleAnzahl / 5 - (MaximaleAnzahl / 5) % 10;
                else if (MaximaleAnzahl >= 25) Schrittgröße = 5;
                else if (MaximaleAnzahl >= 5) Schrittgröße = 2;
                else Schrittgröße = 1;

                for (int i = 0; i <= MaximaleAnzahl; i = i + Schrittgröße)
                {
                    if (i != 0)
                    {
                        drawingContext.DrawLine(
                            Stift,
                            new Point(dX / 2 - HilfslinienEinschub, ((RasterStufen - 1) * dY) - i * HilfslinienStufe),
                            new Point((RasterStufen - 1) * dX + (dX / 2), ((RasterStufen - 1) * dY) - i * HilfslinienStufe));

                        //Beschriftung
                        var Text = new System.Windows.Media.FormattedText(
                            i.ToString(),
                            System.Threading.Thread.CurrentThread.CurrentCulture,
                            FlowDirection.LeftToRight,
                            Schrift,
                            this.FontSize,
                            System.Windows.Media.Brushes.LightGray);

                        drawingContext.DrawText(
                            Text,
                            new Point(
                                dX / 2 - HilfslinienEinschub - Text.Width,
                                ((RasterStufen - 1) * dY) - i * HilfslinienStufe - Text.Height / 2));

                    }
                }
            }
        }
    }
}
