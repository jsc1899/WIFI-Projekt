﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WIFI.Sisharp.Teil2
{
    /// <summary>
    /// Interaktionslogik für ProtokollViewer.xaml
    /// </summary>
    public partial class ProtokollViewer : UserControl
    {
        /// <summary>
        /// Erstellt ein neues Objekt.
        /// </summary>
        public ProtokollViewer()
        {
            InitializeComponent();

            ViewModels.FensterManager  DataContext = null;
            System.Action Rückruf = null;
            WIFI.Anwendung.Daten.ProtokollManager Protokoll = null;

            this.Loaded += (sender, e) =>
            {
                DataContext = this.DataContext as ViewModels.FensterManager;
                if (DataContext != null)
                {
                    Protokoll = DataContext.AppKontext.Protokoll;
                    Rückruf = new System.Action(
                        () => this.Liste.ScrollIntoView(Protokoll.Liste[Protokoll.Liste.Count - 1])
                        );
                    Protokoll.AbonniereRückruf(Rückruf);
                }
            };

            this.Unloaded += (sender, e) =>
            {
                if (Protokoll != null && Rückruf != null)
                {
                    Protokoll.StorniereRückruf(Rückruf);
                }
            };
        }
    }
}
