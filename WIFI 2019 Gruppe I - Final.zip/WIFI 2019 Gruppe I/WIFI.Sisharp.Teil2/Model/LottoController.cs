﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIFI.Anwendung.Daten;

//Für WechselnZu...
using WIFI.Anwendung.Daten.Erweiterungen;

namespace WIFI.Sisharp.Teil2.Model
{
    /// <summary>
    /// Stellt einen Dienst zum Nachladen
    /// der WIFI.Sisharp.Teil2.Daten Assembly bereit.
    /// </summary>
    /// <remarks>Wird gerne als "Wrapper" bezeichnet.
    /// Wir haben bewusst keinen Verweis auf Assembly,
    /// damit diese aus dem Kundenordner gelöscht werden,
    /// wenn nur online gearbeitet werden soll.</remarks>
    internal class LottoController : WIFI.Anwendung.Daten.DatenAnwendungsobjekt,  WIFI.Sisharp.Teil2.Model.ILottodienst
    {
        /// <summary>
        /// Die Bezeichnung der dynamisch geladenen Assembly.
        /// </summary>
        /// <remarks>Muss sich in demselben Ordner befinden,
        /// wie die Anwendung.</remarks>
        private const string AssemblyName = "WIFI.Sisharp.Teil2.Daten";

        /// <summary>
        /// Der Name der Klasse, die die benötigten Dienste bereitstellt.
        /// </summary>
        private const string ManagerName = "WIFI.Sisharp.Teil2.Daten.Lotto.LottoManager";

        /// <summary>
        /// Der Name der Klasse, die ein Lottoland beschreibt.
        /// </summary>
        private const string LandKlasse = "WIFI.Sisharp.Teil2.Daten.Lotto.Land";

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private System.Reflection.Assembly _Assembly = null;

        /// <summary>
        /// Ruft die Assembly ab, die die Logik bereitstellt.
        /// </summary>
        private System.Reflection.Assembly Assembly
        {
            get
            {
                if (this._Assembly == null)
                {
                    this._Assembly = System.Reflection.Assembly.Load(LottoController.AssemblyName);
                    this.AppKontext.Protokoll.Eintragen($"{this} hat die {this._Assembly} geladen...");
                }

                return this._Assembly;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Type _ManagerType = null;

        /// <summary>
        /// Ruft den Typ - die Klasse - ab, die
        /// die benötigten Dienste bereitstellt.
        /// </summary>
        protected Type ManagerType
        {
            get
            {
                if (this._ManagerType == null)
                {
                    this._ManagerType = this.Assembly.GetType(LottoController.ManagerName);
                    this.AppKontext.Protokoll.Eintragen($"{this} hat den Lottomanager Type ermittelt und gecachet...");
                }

                return this._ManagerType;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Type _LandType = null;

        /// <summary>
        /// Ruft den Typ - die Klasse - ab, die
        /// ein Lottoland bereitstellt.
        /// </summary>
        protected Type LandType
        {
            get
            {
                if (this._LandType == null)
                {
                    this._LandType = this.Assembly.GetType(LottoController.LandKlasse);
                    this.AppKontext.Protokoll.Eintragen($"{this} hat den Lottoland Type ermittelt und gecachet...");
                }

                return this._LandType;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Type _LottoscheinType = null;

        /// <summary>
        /// Ruft den Typ ab, den ein Lottoschein bereitstellt.
        /// </summary>
        protected Type LottoscheinType
        {
            get
            {
                if (this._LottoscheinType == null)
                {
                    this._LottoscheinType = this.Assembly.GetType("WIFI.Sisharp.Teil2.Daten.Lotto.Lottoschein");
                }

                return this._LottoscheinType;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private object _Manager = null;

        /// <summary>
        /// Ruft den  Dienst zum Arbeiten mit Lottodaten für diverse Länder ab.
        /// </summary>
        protected object Manager
        {
            get
            {
                if (this._Manager == null)
                {
                    //im Normalfall
                    //this._Manager = this.AppKontext.Erzeuge<WIFI.Sisharp.Teil2.Daten.Lotto.LottoManager>();

                    //Geht mit der bisherigen Variante von Erzeuge<> nicht...
                    //this._Manager = this.AppKontext.Erzeuge < this.ManagerType > ();

                    this._Manager = this.AppKontext.Erzeuge(this.ManagerType);
                }

                return this._Manager;
            }
        }

        /// <summary>
        /// Gibt die unterstützten Lottoländer zurück.
        /// </summary>
        /// <param name="sprache">Die Anwendungssprache,
        /// die für die Namen der Lottoländer benutzt werden soll.</param>
        public Land[] HoleLänder(Sprache sprache)
        {
            var Ergebnis = this.ManagerType.GetMethod("HoleLänder")
                .Invoke(this.Manager, new object[] { sprache });

            return Ergebnis.WechselnZu<Model.Land[]>();
        }

        /// <summary>
        /// Gibt die unterstützten Lottoländer asynchron zurück.
        /// </summary>
        /// <param name="sprache">Die Anwendungssprache,
        /// die für die Namen der Lottoländer benutzt werden soll.</param>
        public Task<Land[]> HoleLänderAsync(Sprache sprache)
        {
            return System.Threading.Tasks.Task<Land[]>.Run(() => this.HoleLänder(sprache));
        }

        /// <summary>
        /// Gibt die Tage zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        public DateTime[] HoleZiehungen(Land land)
        {
            var Ergebnis = this.ManagerType.GetMethod("HoleZiehungen")
                .Invoke(this.Manager, new object[] { land.WechselnZu(this.LandType) });

            return (DateTime[])Ergebnis;
        }

        /// <summary>
        /// Gibt die Tage asynchron zurück, an denen für das 
        /// Land eine Ziehung gespeichert ist.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die gespeicherten Ziehungen benötigt werden.</param>
        public Task<DateTime[]> HoleZiehungenAsync(Land land)
        {
            return System.Threading.Tasks.Task<DateTime[]>.Run(() => this.HoleZiehungen(land));
        }

        /// <summary>
        /// Gibt die Zahlen einer Ziehung eines Tages in einem Land zurück.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        /// <param name="vonTag">Datum, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        public Ziehung HoleZiehung(Land land, DateTime vonTag)
        {
            var Ergebnis = this.ManagerType.GetMethod("HoleZiehung")
                .Invoke(this.Manager, new object[] { land.WechselnZu(this.LandType), vonTag });

            return Ergebnis.WechselnZu<Model.Ziehung>();
        }

        /// <summary>
        /// Gibt die Zahlen einer Ziehung eines Tages in einem Land asynchron zurück.
        /// </summary>
        /// <param name="land">Land, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        /// <param name="vonTag">Datum, von dem 
        /// die Zahlen der Ziehung benötigt werden.</param>
        public Task<Ziehung> HoleZiehungAsync(Land land, DateTime vonTag)
        {
            return System.Threading.Tasks.Task<Ziehung>.Run(() => this.HoleZiehung(land, vonTag));
        }

        /// <summary>
        /// Gibt einen Lottoschein mit der gewünschten Anzahl an Tipps zurück.
        /// </summary>
        /// <param name="land">Land, für das der Lottoschein erstellt werden soll.</param>
        /// <param name="anzahlTipps">Anzahl der zu berechnenden Tipps.</param>
        public Lottoschein BerechneLottoschein(Land land, int anzahlTipps)
        {
            var Ergebnis = this.ManagerType.GetMethod("BerechneLottoschein")
                .Invoke(this.Manager, new object[] { land.WechselnZu(this.LandType), anzahlTipps });

            return Ergebnis.WechselnZu<Model.Lottoschein>();
        }

        /// <summary>
        /// Gibt einen Lottoschein mit der gewünschten Anzahl an Tipps asynchron zurück.
        /// </summary>
        /// <param name="land">Land, für das der Lottoschein erstellt werden soll.</param>
        /// <param name="anzahlTipps">Anzahl der zu berechnenden Tipps.</param>
        public Task<Lottoschein> BerechneLottoscheinAsync(Land land, int anzahlTipps)
        {
            return System.Threading.Tasks.Task<Lottoschein>.Run(() => this.BerechneLottoschein(land, anzahlTipps));
        }

        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        public void SpeichereLottoschein(Lottoschein lottoschein)
        {
            //Bug in WechselnZu, Eigenschaft "Reihen" in Lottoschein wird nicht korrekt konvertiert
            //this.ManagerType.GetMethod("SpeichereLottoschein")
            //    .Invoke(this.Manager, new object[] { lottoschein.WechselnZu(this.LottoscheinType) });

            this.ManagerType.GetMethod("SpeichereLottoschein")
                .Invoke(this.Manager, new object[] { lottoschein.Konvertieren(this.LottoscheinType) });
        }

        /// <summary>
        /// Fügt einen Lottoschein zur Datenbank asynchron hinzu.
        /// </summary>
        /// <param name="lottoschein">Lottoschein, der hinzugefügt werden soll.</param>
        public Task SpeichereLottoscheinAsync(Lottoschein lottoschein)
        {
            return System.Threading.Tasks.Task.Run(() => this.SpeichereLottoschein(lottoschein));
        }

        public Information HoleVerteilung(Land land)
        {
            var Ergebnis = this.ManagerType.GetMethod("HoleVerteilung")
                .Invoke(this.Manager, new object[] { land.WechselnZu(this.LandType) });

            return Ergebnis.WechselnZu<Model.Information>();
        }

        public Task<Information> HoleVerteilungAsync(Land land)
        {
            return System.Threading.Tasks.Task<Information>.Run(() => this.HoleVerteilung(land));
        }
    }
}
