﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil2.Model
{
    /// <summary>
    /// Stellt einen Dienst zum
    /// Verwalten der Anwendungspunkte bereit.
    /// </summary>
    public class AufgabenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgaben _Liste = null;

        /// <summary>
        /// Ruft die Liste mit den unterstützten
        /// Anwendungspunkten ab.
        /// </summary>
        public Model.Aufgaben Liste
        {
            get
            {
                if (this._Liste == null)
                {
                    this._Liste = new Aufgaben();

                    //Könnte über einen Controller aus einer Datenbank 
                    //für einen Benutzer gelesen werden (Nächste Version)

                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "3",
                        Name = Properties.Texte.AufgabeProtokoll,
                        ArbeitsbereichTyp = typeof(ProtokollViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "@",
                        Name = Properties.Texte.AufgabeQuicktipp,
                        ArbeitsbereichTyp = typeof(QuicktippViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "$",
                        Name = Properties.Texte.AufgabeZiehung,
                        ArbeitsbereichTyp = typeof(ZiehungViewer)
                    });

                    //Das Zeichen mit dem Einser im Kreis funktioniert
                    //nicht direkt, weil das für den Editor eine Bedeutung hat.
                    //Deshalb in der Unicode Schreibweise...
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "\u008C",
                        Name = Properties.Texte.AufgabeVerteilung,
                        ArbeitsbereichTyp = typeof(VerteilungViewer)
                    });
                }

                return this._Liste;
            }
        }

    }
}
