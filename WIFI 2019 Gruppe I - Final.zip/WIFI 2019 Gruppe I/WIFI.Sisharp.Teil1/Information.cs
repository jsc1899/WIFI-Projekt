﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIFI.Sisharp.Teil1
{
    /// <summary>
    /// Stellt einen Dienst zum Anzeigen einer
    /// unformatierten Textdatei bereit.
    /// </summary>
    internal class Information : WIFI.Anwendung.Anwendungsobjekt, IHauptfensterObjekt
    {
        /// <summary>
        /// Ruft das Steuerelement ab, in die die Information
        /// dargestellt wird, oder legt dieses fest.
        /// </summary>
        public Control Besitzer { get; set; }

        /// <summary>
        /// Ruft den Text ab, der beim Speichern unter angzeigt wird.
        /// </summary>
        public string SpeichernTitel
        {
            get
            {
                return Properties.Resources.InformationSpeichernTitel;
            }
        }

        /// <summary>
        /// Ruft die unterstützten Dateitypen beim Speichern unter ab.
        /// </summary>
        public string SpeichernTypen
        {
            get
            {
                return Properties.Resources.InformationSpeichernTypen;
            }
        }

        /// <summary>
        /// Ruft das PrintDocument zum Drucken der Information ab.
        /// </summary>
        public PrintDocument Druckseite
        {
            get
            {
                var Seite = new System.Drawing.Printing.PrintDocument();

                Seite.PrintPage += (sender, e) => this.Zeichnen(e.Graphics, e.MarginBounds, ausdruck: true);

                return Seite;
            }
        }

        /// <summary>
        /// Interner Cache für die erste Zeile der Information.
        /// </summary>
        private string _Titel = null;

        /// <summary>
        /// Ruft die erste Zeile der Information ab.
        /// </summary>
        public string Titel
        {
            get
            {
                if (this._Titel == null)
                {
                    this.Lesen();
                }

                return this._Titel;
            }
        }

        /// <summary>
        /// Interner Cache für den Inhalt 
        /// der Information ohne Titel.
        /// </summary>
        private string _Text = null;

        /// <summary>
        /// Ruft den Inhalt der Information
        /// ohne Titel ab.
        /// </summary>
        public string Text
        {
            get
            {
                if (this._Text == null)
                {
                    this.Lesen();
                }

                return this._Text;
            }
        }

        /// <summary>
        /// Ruft den Titel und Text ab.
        /// </summary>
        protected string Inhalt
        {
            get
            {
                return string.Format(
                    "{0}\r\n\r\n{1}", 
                    this.Titel, 
                    this.Text);
            }
        }

        /// <summary>
        /// Stellt die Information in die Windows Zwischenablage.
        /// </summary>
        public void Kopieren()
        {
            System.Windows.Forms.Clipboard.SetText(this.Inhalt);
        }

        /// <summary>
        /// Schreibt den Inhalt in eine unformatierte Textdatei.
        /// </summary>
        /// <param name="pfad">Vollständige Pfadangebe der zu benutzenden Datei.</param>
        public void Speichern(string pfad)
        {
            try
            {
                using (var Schreiber 
                    = new System.IO.StreamWriter(
                        pfad, 
                        append: false, 
                        encoding: System.Text.Encoding.Default))
                {
                    Schreiber.Write(this.Inhalt);
                }
            }
            catch (System.Exception ex)
            {
                this.OnFehlerAufgetreten(new WIFI.Anwendung.FehlerAufgetretenEventArgs(ex));
            }
        }

        /// <summary>
        /// Stellt den Informationstext in der Graphics dar.
        /// </summary>
        /// <param name="g">Graphics Objekt, das für die Information benutzt wird.</param>
        public void Zeichnen(Graphics g)
        {
            this.Zeichnen(g, this.Besitzer.ClientRectangle, ausdruck: false);
        }

        /// <summary>
        /// Stellt den Informationstext in der Graphics dar.
        /// </summary>
        /// <param name="g">Graphics Objekt, das für die Information benutzt wird.</param>
        /// <param name="r">Die zu berücksichtigenden Seitenränder</param>
        /// <param name="ausdruck">False für den Bildschirm wegen
        /// der Bildlaufleisten. True beim Drucken</param>
        protected virtual void Zeichnen(Graphics g, Rectangle r, bool ausdruck)
        {
            const string Schriftart = "Courier New";
            const int Schriftgröße = 11;

            using (var Schrift = new System.Drawing.Font(Schriftart, Schriftgröße))
            {
                var Info = ausdruck ? this.Inhalt : this.Text;

                float X = r.Left;
                float Y = r.Top;

                //Falls kein Ausdruck und der Besitzer
                //ein ScrollableControl ist, die Bildlaufleisten
                //berechnen und X und Y justieren
                if (!ausdruck)
                {
                    var Control = this.Besitzer as ScrollableControl;

                    if (Control != null)
                    {
                        //Erstens:
                        //Den maximal benötigten Platzbedarf einstellen
                        Control.AutoScroll = true;
                        Control.AutoScrollMinSize = g.MeasureString(Info, Schrift).ToSize();

                        //Zweitens:
                        //Die X und Y Koordinaten um die
                        //Position der Bildlaufleisten korrigieren
                        X += Control.AutoScrollPosition.X;
                        Y += Control.AutoScrollPosition.Y;
                    }

                }

                g.DrawString(Info, Schrift, System.Drawing.Brushes.Black, X, Y);
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private string _Pfad = null;

        /// <summary>
        /// Ruft den vollständen Pfad der
        /// Informationsdatei ab oder legt diesen fest.
        /// </summary>
        public string Pfad
        {
            get
            {
                return this._Pfad;
            }
            set
            {
                //Damit bei einer neuen
                //Datei das Lesen angestoßen wird,
                //die Caches löschen...
                this._Titel = null;
                this._Text = null;

                this._Pfad = value;
            }
        }

        /// <summary>
        /// Liest die im Pfad angegebene unformatierte Textdatei.
        /// </summary>
        /// <remarks>Es wird davon ausgegangen, dass die
        /// erste Zeile des Dateiinhalts den Titel der Information enthält.</remarks>
        protected virtual void Lesen()
        {
            try
            {
                using (var Leser = new System.IO.StreamReader(this.Pfad, System.Text.Encoding.Default))
                {
                    if (!Leser.EndOfStream)
                    {
                        this._Titel = Leser.ReadLine().Trim();
                    }

                    if (!Leser.EndOfStream)
                    {
                        this._Text = Leser.ReadToEnd().Trim();
                    }
                }
            }
            catch (System.Exception ex)
            {
                this.OnFehlerAufgetreten(new WIFI.Anwendung.FehlerAufgetretenEventArgs(ex));
                
                //Damit im Fehlerfall nicht wieder gelesen wird:
                //Die Caches initialisieren
                this._Titel = string.Empty;
                this._Text = string.Empty;
            }
        }
    }
}
