﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Teil1
{
    /// <summary>
    /// Stellt Eigenschaften, Methoden und Ereignisse 
    /// bereit, damit ein Objekt im Hauptfenster
    /// angezeigt werden kann.
    /// </summary>
    internal interface IHauptfensterObjekt
    {
        /// <summary>
        /// Stellt die Daten des Objekts 
        /// in die Windows Zwischenablage.
        /// </summary>
        /// <remarks>Kann beim Kopieren, Speichern und beim
        /// Drucken zum Bestimmen von Farben, der Größe, ...
        /// benutzt werden.</remarks>
        void Kopieren();

        /// <summary>
        /// Ruft das Steuerelement ab, in dem
        /// das Objekt gezeichnet wird, oder
        /// legt dieses fest.
        /// </summary>
        System.Windows.Forms.Control Besitzer { get; set; }

        /// <summary>
        /// Schreibt die Daten in eine Datei.
        /// </summary>
        /// <param name="pfad">Vollständige Pfadangabe
        /// der zu benutzenden Datei.</param>
        void Speichern(string pfad);

        /// <summary>
        /// Ruft den Text ab, der für den
        /// Speichern Unter Dialog als Titel 
        /// benutzt werden soll.
        /// </summary>
        string SpeichernTitel { get; }

        /// <summary>
        /// Ruft die unterstützten Dateitypen
        /// beim Speichern Unter ab.
        /// </summary>
        string SpeichernTypen { get; }

        /// <summary>
        /// Ruft das PrintDocument für
        /// den Ausdruck des Objekts ab.
        /// </summary>
        System.Drawing.Printing.PrintDocument Druckseite { get; }

        /// <summary>
        /// Zeichnet den Inhalt des Objekts.
        /// </summary>
        /// <param name="g">Das zu benutzende Graphics Objekt.</param>
        /// <remarks>Immer das Graphics Objekt vom Paint-Ereignis
        /// benutzen und nicht selber erzeugen, weil sonst die
        /// Oberfläche "flackert". Bei der Graphics handelt es
        /// sich um die alte GDI, d.h. wird vom Betriebssytem
        /// verwaltet. Neue Anwendungen (WPF) benutzten die
        /// Grafikkarte direkt.</remarks>
        void Zeichnen(System.Drawing.Graphics g);

        /// <summary>
        /// Ruft den Text ab, der im 
        /// Hauptfenster oben als Überschrift angezeigt werden soll.
        /// </summary>
        string Titel { get; }
    }
}
