﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WIFI.Sisharp.Teil1
{
    /// <summary>
    /// Steuert die Anwendung zum Lernen
    /// von C# zum Erstellen von objektorientierten
    /// .Net Framework Anwendungen.
    /// </summary>
    internal static class Anwendung
    //          ^-> Schlüsselwort, dass etwas nicht
    //              einem Objekt sonder nur der Klasse gehört.
    //-> "internal" bei Klassen, falls diese nicht 
    //   in anderen Assemblies sichtbar sein sollen
    {
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [System.STAThread] //<- ein Attribut, damit die Windows Steuerelemente benutzt werden können
        private static void Main()
        //              ^-> Schlüsselwort für eine Methode ohne Rückgabe.
        //         ^-> Main() muss einer Klasse gehören!!
        //-> "private" bei Mitgliedern
        {
            //Für Windows Forms notwendig
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //---------

            //Die eigene Infrastruktur hochfahren...
            /*
            var AppKontext = new WIFI.Anwe....
            //                          ^-> Wo ist der Anwendungsnamespace?  
            */

            //Wie kann eine Assembly eine andere benutzen?
            //=> Ein VERWEIS auf WIFI.Anwendung ist notwendig
            //   (NICHT MIT using VERWECHSELN!)
            var AppKontext = new WIFI.Anwendung.Anwendungskontext();

            //In der Infrastruktur die letzte Sprache einstellen...
            AppKontext.Sprachen.Festlegen(WIFI.Sisharp.Teil1.Properties.Settings.Default.AktuelleSprache);


            //-> Solange das Fenster wegen eines Sprachwechsels 
            //   geschlossen wurde, das Fenster wieder öffnen
            var MussOffenBleiben = false;

            do
            { //<- Hier beginnt eine Gültigkeit
                System.Threading.Thread.CurrentThread.CurrentUICulture
                    = new System.Globalization.CultureInfo(AppKontext.Sprachen.AktuelleSprache.Code);

                //Den Sprachen Manager bitten, 
                //den Cache zu leeren, damit die
                //richtige Sprache für die Sprachen benutzt wird
                AppKontext.Sprachen.Aktualisieren();

                using (var Hauptfenster = AppKontext.Erzeuge<Hauptfenster>())
                {
                    Application.Run(Hauptfenster);

                    //Hier endet die Gültigkeit
                    //Die Einstellung vom Sprachwechsel retten
                    MussOffenBleiben = Hauptfenster.Sprachwechsel;

                    //Hier wird das Hauptfenster nicht mehr benötigt.
                    //Die Garbage Collecation würde das Objekt entfernen,
                    //wenn's kein Dispose() gibt
                    //Hauptfenster.Dispose(...existiert
                } //hier Dispose() implizit von der using-Anweisung aufgerufen

            } while (MussOffenBleiben);

            //Die aktuelle Sprache noch in der Anwendungskonfiguration speichern
            WIFI.Sisharp.Teil1.Properties.Settings.Default.AktuelleSprache
                = AppKontext.Sprachen.AktuelleSprache.Code;
            WIFI.Sisharp.Teil1.Properties.Settings.Default.Save();
            //                                              ^-> Notwendig, damit geänderte
            //                                                  Benutzereinstellungen gespeichert werden

            AppKontext.Herunterfahren();
        }
    }
}
