﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Zum Auslesen des Copyrights aus der Assembly
using WIFI.Anwendung.Erweiterungen;

namespace WIFI.Sisharp.Teil1
{
    /// <summary>
    /// Stellt einen Dienst zum Begrüßen
    /// der Benutzer bereit.
    /// </summary>
    internal class Begrüßung : WIFI.Anwendung.Anwendungsobjekt, IHauptfensterObjekt
    {
        /// <summary>
        /// Ruft das Steuerelement ab, in dem
        /// die Begrüßung gezeichnet wird, 
        /// oder legt dieses fest.
        /// </summary>
        /// <remarks>Kann beim Kopieren, Speichern und beim
        /// Drucken zum Bestimmen von Farben, der Größe, ...
        /// benutzt werden.</remarks>
        public Control Besitzer { get; set; }

        /// <summary>
        /// Ruft den Text für den Speichern Unter Titel ab.
        /// </summary>
        public string SpeichernTitel
        {
            get
            {
                return WIFI.Sisharp.Teil1.Properties.Resources.BegrüßungSpeichernTitel;
            }
        }

        /// <summary>
        /// Ruft die unterstützten Dateitypen
        /// beim Speichern ab.
        /// </summary>
        public string SpeichernTypen
        {
            get
            {
                return WIFI.Sisharp.Teil1.Properties.Resources.BegrüßungSpeichernTypen;
            }
        }

        /// <summary>
        /// Ruft das Dokument zum Ausdrucken
        /// der Begrüßung ab.
        /// </summary>
        public PrintDocument Druckseite
        {
            get
            {
                var Seite = new System.Drawing.Printing.PrintDocument();

                //Sind beim Drucken "Vorbereitungen" notwendig...
                //Seite.BeginPrint += behandeln

                //Je Seite (bei uns nur eine)
                Seite.PrintPage += (sender, e) => this.Zeichnen(e.Graphics, e.MarginBounds);
                //Hinweis:  Benötigt ein Ausdruck mehrere Seiten, an der
                //          Stelle im Behandler, wo die neue Seite begonnen werden
                //          soll, "e.HasMorePages = true;" einstellen und den
                //          Behandler verlassen. Sofort wird PrintPage wieder ausgelöst
                //          Seitenzähler im "BeginPrint" initialiersen
                
                //Zum Zusammenräumen (der Vorbereitungen)...
                //Seite.EndPrint += behandeln

                return Seite;
            }
        }

        /// <summary>
        /// Ruft die Überschrift der Begrüßung ab.
        /// </summary>
        public string Titel
        {
            get
            {
                return Properties.Resources.BegrüßungZweiteZeile;
            }
        }

        /// <summary>
        /// Stellt ein Bild der Begrüßung in 
        /// die Windows Zwischenablage
        /// </summary>
        public void Kopieren()
        {
            using (var Bild = new System.Drawing.Bitmap(
                this.Besitzer.ClientRectangle.Width,
                this.Besitzer.ClientRectangle.Height))
            {
                //Den Inhalt vom Bild zeichnen
                using (var g = System.Drawing.Graphics.FromImage(Bild))
                {
                    //Damit das Bild nicht transparent ist...
                    g.Clear(this.Besitzer.BackColor);

                    this.Zeichnen(g);
                }
               
                //Das Bild in die Zwischenablage
                System.Windows.Forms.Clipboard.SetImage(Bild);
            }
        }

        /// <summary>
        /// Speichert ein Bild der Begrüßung.
        /// </summary>
        /// <param name="pfad">Vollständige Pfadangabe
        /// der zu benutzenden Datei.</param>
        /// <remarks>Als Dateityp wird 
        /// PNG (Portable Network Graphics) benutzt.</remarks>
        public void Speichern(string pfad)
        {
            try
            {
                using (var Bild = new System.Drawing.Bitmap(
                    this.Besitzer.ClientRectangle.Width,
                    this.Besitzer.ClientRectangle.Height))
                {
                    //Den Inhalt vom Bild zeichnen
                    using (var g = System.Drawing.Graphics.FromImage(Bild))
                    {
                        //Damit das Bild nicht transparent ist...
                        g.Clear(this.Besitzer.BackColor);

                        this.Zeichnen(g);
                    }

                    Bild.Save(pfad, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
            catch (System.Exception ex)
            {
                this.OnFehlerAufgetreten(new WIFI.Anwendung.FehlerAufgetretenEventArgs(ex));
            }
        }

        /// <summary>
        /// Erstellt ein Bild der Begrüßung.
        /// </summary>
        /// <param name="g">Das zu benutzende Graphics Objekt.</param>
        public void Zeichnen(Graphics g)
        {
            this.Zeichnen(g, this.Besitzer.ClientRectangle);
        }

        /// <summary>
        /// Erstellt ein Bild der Begrüßung.
        /// </summary>
        /// <param name="g">Das zu benutzende Graphics Objekt.</param>
        /// <param name="r">Die zu berücksichtigenden Randeinstellungen.</param>
        protected virtual void Zeichnen(System.Drawing.Graphics g, System.Drawing.Rectangle r)
        {
            const string SchriftOben = "Arial";
            const int SchriftGradOben = 14;
            const string SchriftMitte = "Times New Roman";
            const int SchriftGradMitte = 18;
            const string SchriftUnten = "Arial Narrow";
            const int SchriftGradUnten = 10;

            System.Drawing.SizeF Platzbedarf;
            float X;
            float Y;

            //Willkommen oben...

            using (var Schrift = new System.Drawing.Font(SchriftOben, SchriftGradOben))
            {
                Platzbedarf = g.MeasureString(Properties.Resources.BegrüßungTitel, Schrift);

                Y = r.Top;
                X = r.Left + (r.Width - Platzbedarf.Width) / 2;

                g.DrawString(
                    Properties.Resources.BegrüßungTitel, 
                    Schrift, 
                    System.Drawing.Brushes.Blue, 
                    X, Y);

            } //<- Hier ist Schrift.Dispose()

            float Skalierung = 0.7f;

            //Das C# Logo pinseln...
            //Die Y-Koordinate und der 
            //Platzbedarf vom Willkommen wird benutzt
            //DIESE DATEN NICHT VORHER ÄNDERN!
            using (var Bild = new System.Drawing.Bitmap(
                Properties.Resources.siSharp,
                (int)(Properties.Resources.siSharp.Width * Skalierung),
                (int)(Properties.Resources.siSharp.Height * Skalierung)))
            {
                Y += 2 * Platzbedarf.Height;
                X = r.Left + (r.Width - Bild.Width) / 2;
                g.DrawImage(Bild, X, Y);
            }

            //Genau in der Mitte C# Entwickler und die Programmiersprache
            using (var Schrift = new System.Drawing.Font(SchriftMitte, SchriftGradMitte))
            {
                Platzbedarf = g.MeasureString(Properties.Resources.BegrüßungErsteZeile, Schrift);

                Y = r.Top + r.Height/2 - Platzbedarf.Height;
                X = r.Left + (r.Width - Platzbedarf.Width) / 2;

                g.DrawString(
                    Properties.Resources.BegrüßungErsteZeile,
                    Schrift,
                    System.Drawing.Brushes.Black,
                    X, Y);

                Platzbedarf = g.MeasureString(Properties.Resources.BegrüßungZweiteZeile, Schrift);

                Y = r.Top + r.Height / 2 ;
                X = r.Left + (r.Width - Platzbedarf.Width) / 2;

                g.DrawString(
                    Properties.Resources.BegrüßungZweiteZeile,
                    Schrift,
                    System.Drawing.Brushes.Black,
                    X, Y);

            }

            //Unten rechts das Copyright
            using (var Schrift = new System.Drawing.Font(SchriftUnten, SchriftGradUnten))
            {

                //Den Text cachen, weil wir nicht wissen, wie aufwändig
                //die Erweiterungsmethode zum Ergebnis kommt
                var Copyright = this.HoleCopyright();

                Platzbedarf = g.MeasureString(Copyright, Schrift);

                Y = r.Top + r.Height - Platzbedarf.Height;
                X = r.Left + r.Width - Platzbedarf.Width;

                g.DrawString(
                    Copyright,
                    Schrift,
                    System.Drawing.Brushes.DarkGray,
                    X, Y);

            }
        }
    }
}
