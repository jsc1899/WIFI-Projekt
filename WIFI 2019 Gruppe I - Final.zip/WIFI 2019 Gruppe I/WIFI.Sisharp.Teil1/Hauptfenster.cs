﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Für HoleLokalisiertenPfad()
using WIFI.Anwendung.Erweiterungen;

namespace WIFI.Sisharp.Teil1
{
    /// <summary>
    /// Steuert die Oberfläche vom Teil 1
    /// </summary>
    public partial class Hauptfenster : WIFI.Windows.Forms.Anwendungsfenster
    {
        /// <summary>
        /// Initialisiert ein neues Objekt.
        /// </summary>
        public Hauptfenster()
        {
            InitializeComponent();

            //Finger weg vom Konstruktor
            //Hier sind die Eigenschaften noch nicht
            //initialisiert.

            //Besser bei Windows Forms:
            //=> den Load Ereignisauslöser überschreiben

        }

        /// <summary>
        /// Löst das Ereignis Load aus.
        /// </summary>
        /// <param name="e">Weil System.EventArgs keine Zusatzdaten.</param>
        /// <remarks>Wird um Vorbereitungen, z. B. das Füllen der
        /// Liste mit den Sprachen, ... ergänzt.</remarks>
        protected override void OnLoad(EventArgs e)
        {
            //Zuerst einmal das, was sonst passiert...
            base.OnLoad(e);
            //      ^-> hier wird z. B. die Fensterposition wiederhergestellt

            //Jetzt noch die eigenen Vorbereitungen
            /*
            this._SprachenInitialisieren = true;
            */
            this.ComboBoxSprache.DataSource = this.AppKontext.Sprachen.Liste;
            //Damit die Liste weiß, welche Eigenschaft
            //aus dem komplexten Sprache - Objekt für
            //die Anzeige benutzt werden soll...
            this.ComboBoxSprache.DisplayMember = "Name";
            //                                      ^-> über die .Net Reflection ...
            //      ^-> ... sucht die Liste in den enthaltenen Objekten
            //          nach der Eigenschaft Name und benutzt diesen
            //          Inhalt für die Darstellung
            /*
            this._SprachenInitialisieren = false;
            */

            //Sicherstellen, dass die aktuelle Sprache
            //in der Liste ausgewählt ist...
            //So nicht...
            //this.ComboBoxSprache.SelectedItem = this.AppKontext.Sprachen.AktuelleSprache;
            //                                                                  ^-> Verweisobjekt, also eine Speicheradresse
            this.ComboBoxSprache.ValueMember = "Code";
            //                        ^-> wir benötigen einen eindeutigen Schlüssel
            this.ComboBoxSprache.SelectedValue = this.AppKontext.Sprachen.AktuelleSprache.Code;

            //Nach dem Füllen der Liste, den Ereignisbehandler anhängen
            //-> Mit einer anonymen Methode
            this.ComboBoxSprache.SelectedIndexChanged
                += (sender, daten) =>
                {
                    //Falls die ausgewählte Sprache unterschiedlich
                    //der aktuellen Sprache ist...
                    var NeueSprache = (WIFI.Anwendung.Daten.Sprache)this.ComboBoxSprache.SelectedItem;

                    if (this.AppKontext.Sprachen.AktuelleSprache.Code != NeueSprache.Code)
                    {
                        //Diese neue Sprache in die Infrastruktur übernehmen
                        this.AppKontext.Sprachen.AktuelleSprache = NeueSprache;
                        //Die Eigenschaft Sprachwechsel auf True setzen
                        this._Sprachwechsel = true;
                        //Fenster schließen
                        this.Close();
                    }
                };

            //#if DEBUG
            //            //Wie funktioniert die Reflection?
            //            object Demo = new WIFI.Anwendung.Daten.Sprache { Code = "xyz", Name = "Von der Reflection gelesen" };

            //            object EinstellungVomNameimDemoObjekt = Demo.GetType().GetProperty("Name").GetValue(Demo);
            //            System.Console.WriteLine(EinstellungVomNameimDemoObjekt);
            //#endif

            //Das aktuelle Objekt noch dem Verlauf hinzufügen...
            this.Verlauf.Hinterlegen(this.AktuellesObjekt);
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _Sprachwechsel = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, der angibt,
        /// ob das Fenster aktuell wegen eines 
        /// Sprachwechsels geschlossen wurde.
        /// </summary>
        /// <remarks>Standard: False</remarks>
        public bool Sprachwechsel
        {
            get
            {
                return this._Sprachwechsel;
            }
        }

        /*
         * Demonstration eines benannten Ereignisbehandlers...
        private bool _SprachenInitialisieren = false;

        private void SpracheWechseln(object sender, EventArgs e)
        {
            if (!this._SprachenInitialisieren)
            {
                this.Close();
            }
        }
        */

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private IHauptfensterObjekt _AktuellesObjekt = null;

        /// <summary>
        /// Ruft das aktuelle Objekt ab.
        /// </summary>
        /// <remarks>Standardwert ist die Begrüßung</remarks>
        private IHauptfensterObjekt AktuellesObjekt
        {
            get
            {
                if (this._AktuellesObjekt == null)
                {
                    this.AktuellesObjektFestlegen(this.AppKontext.Erzeuge<Begrüßung>());
                }

                return this._AktuellesObjekt;
            }
        }

        /// <summary>
        /// Macht das Objekt zum aktuellen Objekt.
        /// </summary>
        /// <param name="objekt">Objekt, das IHauptfenster implementiert
        /// und zum aktuellen Objekt werden soll.</param>
        private void AktuellesObjektFestlegen(IHauptfensterObjekt objekt)
        {

            objekt.Besitzer = this.PanelInfo;

            this._AktuellesObjekt = objekt;
            this.LabelTitel.Text = objekt.Titel;

            //Damit bei einem neuen Objekt
            //die Bildlaufleisten zurückgesetzt werden
            //(wird im Information.Zeichen eingeschaltet,
            // wenn der Text nicht Platz hat)
            this.PanelInfo.AutoScroll = false;

            this.PanelInfo.Refresh();
        }

        /// <summary>
        /// Stellt die Daten des aktuellen Objekts 
        /// in die Windows Zwischenablage.
        /// </summary>
        private void Kopieren(object sender, EventArgs e)
        {
            this.AktuellesObjekt.Kopieren();
        }

        /// <summary>
        /// Zeigt ein Dialogfenster zum Angeben eines
        /// Dateinamens an und speichert mit diesem
        /// die Daten des aktuellen Objekts.
        /// </summary>
        private void SpeichernUnter(object sender, EventArgs e)
        {
            using (var d = new System.Windows.Forms.SaveFileDialog())
            {

                d.Title = this.AktuellesObjekt.SpeichernTitel;
                d.Filter = this.AktuellesObjekt.SpeichernTypen;

                if (d.ShowDialog() == DialogResult.OK)
                {
                    this.AktuellesObjekt.Speichern(d.FileName);
                }
            }
        }

        /// <summary>
        /// Öffnet ein Dialogfenster zum Anzeigen und Drucken der
        /// Seitenansicht des aktuellen Dokuments.
        /// </summary>
        private void SeitenansichtZeigen(object sender, EventArgs e)
        {
            //20190124 Eigene Variante, die sich die Position merkt
            //using (var d = new System.Windows.Forms.PrintPreviewDialog())
            using (var d = this.AppKontext.Erzeuge<WIFI.Windows.Forms.PrintPreviewDialogEx>())
            {
                /*
                d.Load += (besitzer, daten) =>
                {
                    //Logik zum Wiederherstellen
                };
                d.FormClosing += (besitzer, daten) =>
                {
                    //Logik zum Speichern
                };
                */
                //Konfigurieren:

                //-> Symbol für das Fenster,
                //   weil das irgendwo bei Microsoft verloren wird...
                d.Icon = this.Icon;

                //-> Ein Objektname für den Fenstermanager der Infrastruktur
                d.Name = "Seitenansicht";

                //Vom aktuellen Objekt die Druckseite einstellen...
                d.Document = this.AktuellesObjekt.Druckseite;

                d.ShowDialog();
            }
        }

        /// <summary>
        /// Stellt das aktuelle Objekt im PanelInfo dar.
        /// </summary>
        /// <param name="sender">Objektverweis auf den Besitzer</param>
        /// <param name="e">Stellt die Zeichenfläche System.Drawing.Graphics bereit.</param>
        private void AktuellesObjektZeichnen(object sender, PaintEventArgs e)
        {
            this.AktuellesObjekt.Zeichnen(e.Graphics);
        }

        /// <summary>
        /// Schließt das Hauptfenster.
        /// </summary>
        private void Beenden(object sender, System.EventArgs e)
        //                                          ^-> keine Zusatzinformation
        {
            //Hier darf nicht gefragt werden!
            //Es gibt ja viele Möglichkeiten,
            //das Fenster zu schließen
            this.Close();
        }

        /// <summary>
        /// Löst das FormClosing Ereignis aus
        /// </summary>
        /// <param name="e">Ereignisdaten mit 
        /// der Möglichkeit zum Abbrechen.</param>
        protected override void OnFormClosing(FormClosingEventArgs e)
        //                                          ^-> Zusatzinformation
        {

            //Nur, wenn's kein Sprachwechsel ist
            //und der Benutzer das Fragen nicht abgeschaltet hat...
            if (!this.Sprachwechsel && this.CheckBoxBeimBeendenFragen.Checked)
            {
                //Zuerst einmal fragen
                //Weil wir gerade eine Benutzerschnittstelle
                //und keine "Anwendungsklasse" programmieren,
                //DÜRFEN wir HIER mit dem Benutzer reden...
                var Antwort = System.Windows.Forms.MessageBox.Show(
                    WIFI.Sisharp.Teil1.Properties.Resources.BeendenFrage,
                    WIFI.Sisharp.Teil1.Properties.Resources.BeendenTitel,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                //Abhängig von der Antwort das Schließen abbrechen oder nicht
                e.Cancel = Antwort == DialogResult.No;
            }

            //Zum Schluss noch das, was sonst passiert
            base.OnFormClosing(e);
        }

        /// <summary>
        /// Erzwingt ein Neuzeichnen des PanelInfo's
        /// </summary>
        private void Aktualisieren(object sender, EventArgs e)
        {
            this.PanelInfo.Refresh();
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Anwendung.Verlauf _Verlauf = null;

        /// <summary>
        /// Ruft den Dienst zum Verwalten des
        /// Zurück- bzw. Vorwärtswechselns in
        /// der Anwendung ab.
        /// </summary>
        protected WIFI.Anwendung.Verlauf Verlauf
        {
            get
            {
                if (this._Verlauf == null)
                {
                    this._Verlauf = new WIFI.Anwendung.Verlauf();

                    //Die Ereignisse des Verlauf-Objekts an
                    //die Oberfläche "binden"

                    this._Verlauf.KeinZurück += (sender, e) => this.ButtonZurück.Enabled = false;
                    this._Verlauf.KeinVorwärts += (sender, e) => this.ButtonVorwärts.Enabled = false;
                    this._Verlauf.ZurückMöglich += (sender, e) => this.ButtonZurück.Enabled = true;
                    this._Verlauf.VorwärtsMöglich += (sender, e) => this.ButtonVorwärts.Enabled = true;

                }

                return this._Verlauf;
            }
        }

        /// <summary>
        /// Ruft das Verzeichnis ab, in dem
        /// die Informationsdateien gespeichert sind.
        /// </summary>
        /// <remarks>Falls die Konfigurationseinstellung ein
        /// absoluter Pfad ist, wird dieser benutzt. Sonst wird
        /// davon ausgegegangen, dass es sich um einen Unterordner
        /// im Anwendungsverzeichnis handelt.</remarks>
        protected string Informationspfad
        {
            get
            {
                var Pfad = Properties.Settings.Default.Informationspfad;

                //Ist die Konfigurationseinstellung absolut?
                if (!System.IO.Path.IsPathRooted(Pfad))
                {
                    //Nein? Davon ausgehen, dass der Pfad unterhalb vom
                    //      Anwendungspfad relativ ist
                    Pfad = System.IO.Path.Combine(this.AppKontext.Anwendungspfad, Pfad);
                }

                return Pfad.HoleLokalisiertenPfad();
            }
        }

        /// <summary>
        /// Abhängig vom Sender die passende Informationsdatei anzeigen.
        /// </summary>
        private void InfoAuswählen(object sender, EventArgs e)
        {
            /*
            //Folgende Anweisung kann abstürzen, wenn "sender" kein LinkLabel ist..
            System.Windows.Forms.LinkLabel Befehl = (System.Windows.Forms.LinkLabel)sender;
            */

            //Folgendes Casten stürzt nicht ab. Falls sender kein
            //LinkLabel ist, wird null geliefert
            var Befehl = sender as System.Windows.Forms.LinkLabel;

            if (Befehl != null)
            {
                var Datei = string.Empty;

                switch (Befehl.Name)
                {
                    case "LinkLabelAllgemein":
                        Datei = "Allgemein.txt";
                        break;
                    case "LinkLabelStruktur":
                        Datei = "Struktur.txt";
                        break;
                    case "LinkLabelBinär":
                        Datei = "Binär.txt";
                        break;
                    case "LinkLabelFall":
                        Datei = "Fallentscheidung.txt";
                        break;
                    case "LinkLabelZählen":
                        Datei = "Zählen.txt";
                        break;
                    case "LinkLabelAbweisen":
                        Datei = "Abweisen.txt";
                        break;
                    case "LinkLabelDurchlaufen":
                        Datei = "Durchlaufen.txt";
                        break;
                }

                //Falls eine Datei ermittelt wurde...
                if (Datei != string.Empty)
                {
                    var InfoPfad = System.IO.Path.Combine(this.Informationspfad, Datei);

                    //Damit dieselbe Information nicht mehrmals hintereinander angzeigt wird
                    //Neue Info nur, wenn der Pfad des aktuellen Objekts
                    //ein anderer ist, als der gerade berechnete...
                    var AktuelleInformation = this.AktuellesObjekt as Information;

                    if (AktuelleInformation == null || AktuelleInformation.Pfad != InfoPfad)
                    {
                        AktuelleInformation = new Information();
                        AktuelleInformation.Pfad = InfoPfad;

                        this.Verlauf.Hinterlegen(AktuelleInformation);

                        this.AktuellesObjektFestlegen(AktuelleInformation);
                    }
                }
            }
        }

        /// <summary>
        /// Zeigt das vorherige oder nächste Objekt aus dem Verlauf an.
        /// </summary>
        private void ImVerlaufBewegen(object sender, EventArgs e)
        {
            var Befehl = sender as Button;

            if (Befehl != null)
            {
                IHauptfensterObjekt NeuesObjekt = null;

                switch (Befehl.Name)
                {
                    case "ButtonZurück":
                        NeuesObjekt = this.Verlauf.HoleZurückObjekt() as IHauptfensterObjekt;
                        break;
                    case "ButtonVorwärts":
                        NeuesObjekt = this.Verlauf.HoleVorwärtsObjekt() as IHauptfensterObjekt;
                        break;
                }

                if (NeuesObjekt != null)
                {
                    this.AktuellesObjektFestlegen(NeuesObjekt);
                }
            }
        }
    }
}
