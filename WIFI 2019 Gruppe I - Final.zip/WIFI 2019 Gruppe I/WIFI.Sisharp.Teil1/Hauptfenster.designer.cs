﻿namespace WIFI.Sisharp.Teil1
{
    partial class Hauptfenster
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hauptfenster));
            this.PanelKopf = new System.Windows.Forms.Panel();
            this.LabelTitel = new System.Windows.Forms.Label();
            this.ButtonVorwärts = new System.Windows.Forms.Button();
            this.ImageListVerlauf = new System.Windows.Forms.ImageList(this.components);
            this.ButtonZurück = new System.Windows.Forms.Button();
            this.ComboBoxSprache = new System.Windows.Forms.ComboBox();
            this.Menü = new System.Windows.Forms.ToolStrip();
            this.MenüAktionen = new System.Windows.Forms.ToolStripDropDownButton();
            this.AktionenKopieren = new System.Windows.Forms.ToolStripMenuItem();
            this.AktionenSpeichernUnter = new System.Windows.Forms.ToolStripMenuItem();
            this.AktionenLinie01 = new System.Windows.Forms.ToolStripSeparator();
            this.AktionenSeitenansicht = new System.Windows.Forms.ToolStripMenuItem();
            this.AktionenLinie02 = new System.Windows.Forms.ToolStripSeparator();
            this.AktionenBeenden = new System.Windows.Forms.ToolStripMenuItem();
            this.PanelAuswahl = new System.Windows.Forms.Panel();
            this.LinkLabelDurchlaufen = new System.Windows.Forms.LinkLabel();
            this.LinkLabelAbweisen = new System.Windows.Forms.LinkLabel();
            this.LinkLabelZählen = new System.Windows.Forms.LinkLabel();
            this.LinkLabelFall = new System.Windows.Forms.LinkLabel();
            this.LinkLabelBinär = new System.Windows.Forms.LinkLabel();
            this.LinkLabelStruktur = new System.Windows.Forms.LinkLabel();
            this.LinkLabelAllgemein = new System.Windows.Forms.LinkLabel();
            this.CheckBoxBeimBeendenFragen = new System.Windows.Forms.CheckBox();
            this.PanelInfo = new System.Windows.Forms.Panel();
            this.PanelKopf.SuspendLayout();
            this.Menü.SuspendLayout();
            this.PanelAuswahl.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelKopf
            // 
            this.PanelKopf.Controls.Add(this.LabelTitel);
            this.PanelKopf.Controls.Add(this.ButtonVorwärts);
            this.PanelKopf.Controls.Add(this.ButtonZurück);
            this.PanelKopf.Controls.Add(this.ComboBoxSprache);
            resources.ApplyResources(this.PanelKopf, "PanelKopf");
            this.PanelKopf.Name = "PanelKopf";
            // 
            // LabelTitel
            // 
            resources.ApplyResources(this.LabelTitel, "LabelTitel");
            this.LabelTitel.BackColor = System.Drawing.SystemColors.Control;
            this.LabelTitel.Name = "LabelTitel";
            // 
            // ButtonVorwärts
            // 
            resources.ApplyResources(this.ButtonVorwärts, "ButtonVorwärts");
            this.ButtonVorwärts.FlatAppearance.BorderSize = 0;
            this.ButtonVorwärts.ImageList = this.ImageListVerlauf;
            this.ButtonVorwärts.Name = "ButtonVorwärts";
            this.ButtonVorwärts.UseVisualStyleBackColor = true;
            this.ButtonVorwärts.Click += new System.EventHandler(this.ImVerlaufBewegen);
            // 
            // ImageListVerlauf
            // 
            this.ImageListVerlauf.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageListVerlauf.ImageStream")));
            this.ImageListVerlauf.TransparentColor = System.Drawing.Color.Yellow;
            this.ImageListVerlauf.Images.SetKeyName(0, "Zurück.bmp");
            this.ImageListVerlauf.Images.SetKeyName(1, "Vorwärts.bmp");
            // 
            // ButtonZurück
            // 
            resources.ApplyResources(this.ButtonZurück, "ButtonZurück");
            this.ButtonZurück.FlatAppearance.BorderSize = 0;
            this.ButtonZurück.ImageList = this.ImageListVerlauf;
            this.ButtonZurück.Name = "ButtonZurück";
            this.ButtonZurück.UseVisualStyleBackColor = true;
            this.ButtonZurück.Click += new System.EventHandler(this.ImVerlaufBewegen);
            // 
            // ComboBoxSprache
            // 
            resources.ApplyResources(this.ComboBoxSprache, "ComboBoxSprache");
            this.ComboBoxSprache.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxSprache.FormattingEnabled = true;
            this.ComboBoxSprache.Name = "ComboBoxSprache";
            // 
            // Menü
            // 
            this.Menü.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.Menü.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenüAktionen});
            resources.ApplyResources(this.Menü, "Menü");
            this.Menü.Name = "Menü";
            // 
            // MenüAktionen
            // 
            this.MenüAktionen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MenüAktionen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AktionenKopieren,
            this.AktionenSpeichernUnter,
            this.AktionenLinie01,
            this.AktionenSeitenansicht,
            this.AktionenLinie02,
            this.AktionenBeenden});
            resources.ApplyResources(this.MenüAktionen, "MenüAktionen");
            this.MenüAktionen.Name = "MenüAktionen";
            // 
            // AktionenKopieren
            // 
            this.AktionenKopieren.Name = "AktionenKopieren";
            resources.ApplyResources(this.AktionenKopieren, "AktionenKopieren");
            this.AktionenKopieren.Click += new System.EventHandler(this.Kopieren);
            // 
            // AktionenSpeichernUnter
            // 
            this.AktionenSpeichernUnter.Name = "AktionenSpeichernUnter";
            resources.ApplyResources(this.AktionenSpeichernUnter, "AktionenSpeichernUnter");
            this.AktionenSpeichernUnter.Click += new System.EventHandler(this.SpeichernUnter);
            // 
            // AktionenLinie01
            // 
            this.AktionenLinie01.Name = "AktionenLinie01";
            resources.ApplyResources(this.AktionenLinie01, "AktionenLinie01");
            // 
            // AktionenSeitenansicht
            // 
            this.AktionenSeitenansicht.Name = "AktionenSeitenansicht";
            resources.ApplyResources(this.AktionenSeitenansicht, "AktionenSeitenansicht");
            this.AktionenSeitenansicht.Click += new System.EventHandler(this.SeitenansichtZeigen);
            // 
            // AktionenLinie02
            // 
            this.AktionenLinie02.Name = "AktionenLinie02";
            resources.ApplyResources(this.AktionenLinie02, "AktionenLinie02");
            // 
            // AktionenBeenden
            // 
            this.AktionenBeenden.Name = "AktionenBeenden";
            resources.ApplyResources(this.AktionenBeenden, "AktionenBeenden");
            this.AktionenBeenden.Click += new System.EventHandler(this.Beenden);
            // 
            // PanelAuswahl
            // 
            this.PanelAuswahl.Controls.Add(this.LinkLabelDurchlaufen);
            this.PanelAuswahl.Controls.Add(this.LinkLabelAbweisen);
            this.PanelAuswahl.Controls.Add(this.LinkLabelZählen);
            this.PanelAuswahl.Controls.Add(this.LinkLabelFall);
            this.PanelAuswahl.Controls.Add(this.LinkLabelBinär);
            this.PanelAuswahl.Controls.Add(this.LinkLabelStruktur);
            this.PanelAuswahl.Controls.Add(this.LinkLabelAllgemein);
            this.PanelAuswahl.Controls.Add(this.CheckBoxBeimBeendenFragen);
            resources.ApplyResources(this.PanelAuswahl, "PanelAuswahl");
            this.PanelAuswahl.Name = "PanelAuswahl";
            // 
            // LinkLabelDurchlaufen
            // 
            this.LinkLabelDurchlaufen.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelDurchlaufen, "LinkLabelDurchlaufen");
            this.LinkLabelDurchlaufen.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelDurchlaufen.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelDurchlaufen.Name = "LinkLabelDurchlaufen";
            this.LinkLabelDurchlaufen.TabStop = true;
            this.LinkLabelDurchlaufen.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelDurchlaufen.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelAbweisen
            // 
            this.LinkLabelAbweisen.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelAbweisen, "LinkLabelAbweisen");
            this.LinkLabelAbweisen.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelAbweisen.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelAbweisen.Name = "LinkLabelAbweisen";
            this.LinkLabelAbweisen.TabStop = true;
            this.LinkLabelAbweisen.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelAbweisen.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelZählen
            // 
            this.LinkLabelZählen.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelZählen, "LinkLabelZählen");
            this.LinkLabelZählen.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelZählen.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelZählen.Name = "LinkLabelZählen";
            this.LinkLabelZählen.TabStop = true;
            this.LinkLabelZählen.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelZählen.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelFall
            // 
            this.LinkLabelFall.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelFall, "LinkLabelFall");
            this.LinkLabelFall.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelFall.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelFall.Name = "LinkLabelFall";
            this.LinkLabelFall.TabStop = true;
            this.LinkLabelFall.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelFall.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelBinär
            // 
            this.LinkLabelBinär.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelBinär, "LinkLabelBinär");
            this.LinkLabelBinär.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelBinär.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelBinär.Name = "LinkLabelBinär";
            this.LinkLabelBinär.TabStop = true;
            this.LinkLabelBinär.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelBinär.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelStruktur
            // 
            this.LinkLabelStruktur.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelStruktur, "LinkLabelStruktur");
            this.LinkLabelStruktur.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelStruktur.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelStruktur.Name = "LinkLabelStruktur";
            this.LinkLabelStruktur.TabStop = true;
            this.LinkLabelStruktur.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelStruktur.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // LinkLabelAllgemein
            // 
            this.LinkLabelAllgemein.ActiveLinkColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.LinkLabelAllgemein, "LinkLabelAllgemein");
            this.LinkLabelAllgemein.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LinkLabelAllgemein.LinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelAllgemein.Name = "LinkLabelAllgemein";
            this.LinkLabelAllgemein.TabStop = true;
            this.LinkLabelAllgemein.VisitedLinkColor = System.Drawing.SystemColors.ControlText;
            this.LinkLabelAllgemein.Click += new System.EventHandler(this.InfoAuswählen);
            // 
            // CheckBoxBeimBeendenFragen
            // 
            resources.ApplyResources(this.CheckBoxBeimBeendenFragen, "CheckBoxBeimBeendenFragen");
            this.CheckBoxBeimBeendenFragen.Checked = global::WIFI.Sisharp.Teil1.Properties.Settings.Default.BeimBeendenFragen;
            this.CheckBoxBeimBeendenFragen.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBoxBeimBeendenFragen.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::WIFI.Sisharp.Teil1.Properties.Settings.Default, "BeimBeendenFragen", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.CheckBoxBeimBeendenFragen.Name = "CheckBoxBeimBeendenFragen";
            this.CheckBoxBeimBeendenFragen.UseVisualStyleBackColor = true;
            // 
            // PanelInfo
            // 
            this.PanelInfo.BackColor = System.Drawing.SystemColors.Window;
            resources.ApplyResources(this.PanelInfo, "PanelInfo");
            this.PanelInfo.Name = "PanelInfo";
            this.PanelInfo.Paint += new System.Windows.Forms.PaintEventHandler(this.AktuellesObjektZeichnen);
            // 
            // Hauptfenster
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.PanelInfo);
            this.Controls.Add(this.PanelAuswahl);
            this.Controls.Add(this.Menü);
            this.Controls.Add(this.PanelKopf);
            this.Name = "Hauptfenster";
            this.Resize += new System.EventHandler(this.Aktualisieren);
            this.PanelKopf.ResumeLayout(false);
            this.Menü.ResumeLayout(false);
            this.Menü.PerformLayout();
            this.PanelAuswahl.ResumeLayout(false);
            this.PanelAuswahl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PanelKopf;
        private System.Windows.Forms.ToolStrip Menü;
        private System.Windows.Forms.ComboBox ComboBoxSprache;
        private System.Windows.Forms.Panel PanelAuswahl;
        private System.Windows.Forms.Panel PanelInfo;
        private System.Windows.Forms.CheckBox CheckBoxBeimBeendenFragen;
        private System.Windows.Forms.Button ButtonZurück;
        private System.Windows.Forms.ImageList ImageListVerlauf;
        private System.Windows.Forms.Button ButtonVorwärts;
        private System.Windows.Forms.ToolStripDropDownButton MenüAktionen;
        private System.Windows.Forms.ToolStripMenuItem AktionenKopieren;
        private System.Windows.Forms.ToolStripMenuItem AktionenSpeichernUnter;
        private System.Windows.Forms.ToolStripSeparator AktionenLinie01;
        private System.Windows.Forms.ToolStripMenuItem AktionenSeitenansicht;
        private System.Windows.Forms.ToolStripSeparator AktionenLinie02;
        private System.Windows.Forms.ToolStripMenuItem AktionenBeenden;
        private System.Windows.Forms.LinkLabel LinkLabelDurchlaufen;
        private System.Windows.Forms.LinkLabel LinkLabelAbweisen;
        private System.Windows.Forms.LinkLabel LinkLabelZählen;
        private System.Windows.Forms.LinkLabel LinkLabelFall;
        private System.Windows.Forms.LinkLabel LinkLabelBinär;
        private System.Windows.Forms.LinkLabel LinkLabelStruktur;
        private System.Windows.Forms.LinkLabel LinkLabelAllgemein;
        private System.Windows.Forms.Label LabelTitel;
    }
}

