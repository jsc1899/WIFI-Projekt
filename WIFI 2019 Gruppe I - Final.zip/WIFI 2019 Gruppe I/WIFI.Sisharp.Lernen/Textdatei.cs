﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Lernen
{
    /// <summary>
    /// Stellt einen Dienst zum
    /// Lesen und Ausgeben einer
    /// unformatierten Textdatei bereit.
    /// </summary>
    internal class Textdatei : Entwicklungsbasis
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private string _Pfad = string.Empty;
        //                     |-----------> == "";
        //      ^-> "Verweistyp" mit Standard null
        //          Mit null kann niemand arbeiten
        //Tipp: Eine String Variable (hier Feld) immer
        //      mit einem leeren Text "" (string.Empty)
        //      initialisieren, wenn es nirgends gecachet wird.

        /// <summary>
        /// Ruft den vollständigen Pfad der zu
        /// benutzenden Datei ab oder legt diesen fest.
        /// </summary>
        public string Pfad
        {
            //eine Eigenschaft wird vom Kompiler
            //in mind. eine Funktionsmethode und
            //wenn nicht schreibgeschützt in eine void-Methode aufgelöst
            get
            {
                //"Getter"
                //Wie ein Funktionsmethode, wenn die
                //Einstellung der Eigenschaft geholt wird.
                return this._Pfad;
                //-> zum Zurückgeben des Werts
                //   bei einer Funktionsmethode
            }

            //Falls nicht schreibgeschützt auch der ...
            set
            {
                //Setter
                //Wird vom Kompiler (unsichtbar) zu
                //void Pfad_Set(string value)
                //                       ^-> vom Kompiler benutzter Name
                //                           für den Schnittstellen Parameter
                this._Pfad = value;
                //Hier muss später this.OnPropertyChanged("Pfad")
                //für Windows Presentation Foundation (Teil 2)
                //aufgerufen werden.
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private System.Collections.ArrayList _Zeilen = null;

        /// <summary>
        /// Ruft die Liste mit den gelesenen Zeilen ab.
        /// </summary>
        /// <remarks>C# hat keine eigenen dynamischen Listen!</remarks>
        protected System.Collections.ArrayList Zeilen
        {
            get
            {
                if (this._Zeilen == null)
                {
                    this._Zeilen = new System.Collections.ArrayList();
                    Textdatei.Ausgeben("Textdatei hat die Liste für den Inhalt gecachet...", AusgabeModus.Debug);
                }

                return this._Zeilen;
            }
        }

        /// <summary>
        /// Liest die im Pfad angegebene Datei.
        /// </summary>
        /// <remarks>Der Inhalt kann über Zeilen abgerufen werden.</remarks>
        public void Lesen()
        {
            Textdatei.Ausgeben("Textdatei.Lesen startet...", AusgabeModus.Debug);

            //Datei öffnen
            //var Leser = new System.IO.StreamReader(this.Pfad);
            //                              ^-> dieser Konstruktor interpretiert nicht richtig
            var Leser = new System.IO.StreamReader(this.Pfad, System.Text.Encoding.Default);

            //Solange Zeilen vorhanden
            while (!Leser.EndOfStream)
            //              ^-> false, wenn etwas vorhanden ist. true, wenn nix (mehr) vorhanden ist
            //     ^-> Rufzeichen: C# Operator für die Verneinung
            //              !false -> true
            //              !true  -> false
            {

                //  Eine Zeile lesen
                //  und in die Liste eintragen
                this.Zeilen.Add(Leser.ReadLine().Trim());

            }

            //Datei schließen
            Leser.Close();
            //Leser.Dispose();
            //          ^-> im Handbuch steht, wenn ein Objekt
            //              eine Close() und eine Dispose() Methode hat,
            //              reicht eine der beiden aufzurufen

            Leser = null;
            //      ^-> als Hinweis, dass auf Dispose()
            //          geprüft wurde.

            Textdatei.Ausgeben($"Es wurden {this.Zeilen.Count} Zeilen gelesen...", AusgabeModus.Debug);

            Textdatei.Ausgeben("Textdatei.Lesen beendet...", AusgabeModus.Debug);
        }

        /// <summary>
        /// Gibt den Inhalt der Datei als Fließtext zurück.
        /// </summary>
        /// <param name="maxZeilenlänge">Die maximale Anzahl der Zeichen einer Zeile.</param>
        public string HoleFließtext(int maxZeilenlänge)
        { //<- neue Gültigkeit

            //StringBuilder erzeugen
            var Text = new System.Text.StringBuilder();
            //  ^-> der Name für die lokale Variable kann
            //      wieder benutzt werden, obwohl bereits auch
            //      an anderen Stellen benutzt.

            var AktuelleLänge = 0;

            //Für jedes Wort in den Zeilen

            /*
            //Weil die Anzahl der Wörter bekannt ist...
            for (int i = 0; i<this.Zeilen.Count;i++)
            {
                //Standardzählschleife
            }
            */
            //Falls alle Elemente eines Arrays 
            //benötigt werden, eleganter...
            //=> Spezialzählschleife
            foreach (string Wort in this.Zeilen)
            {
                //Falls das Wort nicht mehr Platz hat,
                //neue Zeile beginnen
                if (Wort.Length + AktuelleLänge > maxZeilenlänge)
                {
                    Text.AppendLine();
                    AktuelleLänge = 0;
                }

                //Das Wort mit Leerzeichen ausgeben
                Text.Append(Wort + " ");

                //Den Inhalt einer Variable verändern und
                //das Ergebnis wieder in die Variable schreiben...
                //----
                //AktuelleLänge = AktuelleLänge + Wort.Length + 1;
                //---

                //In C# kürzer
                AktuelleLänge += Wort.Length + 1;
                //                             ^-> wegen Leerzeichens

            }

            return Text.ToString();
        } //<- Ende Gültigkeit
    }
}