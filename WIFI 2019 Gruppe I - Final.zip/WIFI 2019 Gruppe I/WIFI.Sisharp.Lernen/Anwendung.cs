﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Lernen
{
    /// <summary>
    /// Steuert die Anwendung zum Lernen
    /// der objektorientierten Programmierung
    /// mit C# und dem .Net Framework.
    /// </summary>
    internal class Anwendung : Entwicklungsbasis
    {
        /// <summary>
        /// Stellt den Haupteinstiegspunkt in 
        /// eine .Net Anwendung bereit.
        /// </summary>
        private static void Main()
        //                       ^-> leere Schnittstelle
        //                  ^-> Die Haupteinstiegsmethode
        //                      Diese MUSS "Main" heißen
        //              ^-> arbeitet ohne Rückgabe
        //        ^-> weil am Anfang noch kein Objekt existiert,
        //            muss Main() der Klasse und nicht einem Objekt 
        //            gehören. Deshalb "static" (statisch)
        //-> ob der Haupteinstiegspunkt "private" oder
        //   "public" modifiziert ist, ist egal.
        {

            Anwendung.Begrüßen();

            Anwendung.ZeigeMenü();

            //Wo bitte ist "ZeigeSequenz()"
            //Algorithmus.Zeig....
            //              ^-> NICHT STATISCH, Objekt erforderlich
            //-> Klasse.

            //Standardablauf zum Benutzen einer Klasse als Objekt

            //(1) Speicher für das Objekt reservieren (=Variable)
            Algorithmus AlgoObjekt = null;
            //                         ^-> C# Schlüsselwort für "keine Speicheradresse"
            //                             ("Nothing" in BASIC, "nil" irgendwo anders)
            //                     ^-> Gleich, Operator für die Wertzuweisung
            //              ^-> Der Name der Variable
            //-> der Datentyp, weil als "class" deklariert, ein Verweistyp
            //   d.h. in unserer Variable befindet sich nicht das Objekt,
            //        sondern nur die Speicheradresse, wo das Objekt im
            //        Arbeitsspeicher beginnt

            //(2) Die Klasse als Objekt initialisieren
            AlgoObjekt = new Algorithmus();
            //                          ^-> die Schnittstelle vom Konstruktor
            //                              (eine Spezialmethode, die von new ausgeführt wird)
            //                  ^-> Klasse, von der ein Objekt benötigt
            //            ^-> "new" baut das Objekt im Speicher durch Aufruf
            //                vom Konstruktor und gibt die Startspeicheradresse (des "Verweistyp")
            //                zurück...
            //         ^-> Istgleich, Wertzuweisung
            //-> Die "Variable" zum Merken der Speicheradresse vom "new",
            //   damit später mit dem Objekt gearbeitet werden kann.
            //=> Mit jedem "new" geht Speicher verloren

            //(3) Das Objekt benutzen

            //AlgoObjekt.ZeigeSequenz();
            ////              ^-> eine nicht statisch Methode
            ////-> Objekt der Algorithmus Klasse

            //AlgoObjekt.ZeigeBinär();
            ////Damit getestet werden kann, ob der
            ////Zufallsgenerator wirklich nur einmal erstellt wird...
            //AlgoObjekt.ZeigeBinär();

            //AlgoObjekt.ZeigeFall();

            //AlgoObjekt.ZeigeZählen();

            ////Zum Testen vom Lottoland
            //AlgoObjekt.ZeigeDurchlaufen();

            //Der Benutzer soll sich aussuchen können,
            //was er stehen möchte
            const string Prompt = "C#> ";
            //                        ^-> damit ein Abstand zur Benutzereingabe ist

            const string FehlerHinweis = "Eingabe nicht erkannt! Fragezeichen ? für Hilfe...";

            string Programmpunkt = null;

            //Mit einer Durchlaufeschleife...
            do
            {
                Anwendung.Ausgeben(Prompt, AusgabeModus.NormalOhneVorschub);
                Programmpunkt = System.Console.ReadLine().Trim().ToUpper();
                //                                                  ^->  weil Windows Benutzer
                //                                                       nicht gewohnt sind, auf
                //                                                       Groß-/kleinschreibung zu achten

                switch (Programmpunkt)
                {
                    case "HALLO":
                    case "1":
                        AlgoObjekt.ZeigeSequenz();
                        break;
                    case "IF":
                    case "2":
                        AlgoObjekt.ZeigeBinär();
                        break;
                    case "SWITCH":
                    case "3":
                        AlgoObjekt.ZeigeFall();
                        break;
                    case "FOR":
                    case "FOREACH":
                    case "4":
                        AlgoObjekt.ZeigeZählen();
                        break;
                    case "WHILE":
                    case "5":
                        AlgoObjekt.ZeigeAbweisen();
                        break;
                    case "DO":
                    case "6":
                        AlgoObjekt.ZeigeDurchlaufen();
                        break;

                    case "?":
                        Anwendung.ZeigeMenü();
                        break;

                    case "EXIT":
                        Programmpunkt = "9";
                        break;
                    
                    //Dummy-Fall, damit
                    //beim Beenden und bei leeren
                    //Eingaben kein Fehler angezeigt wird
                    case "":
                    case "9":
                        //Leer, damit kein Fehler angezeigt wird
                        //Nur damit die Fallentscheidung nicht
                        //in den Standardfall
                        break;

                    default:
                        Anwendung.Ausgeben(FehlerHinweis, AusgabeModus.Fehler);
                        break;
                }


            } while (Programmpunkt != "9");
            //                     ^-> Rufzeichen-Gleich Operator für ungleich

            //(4) Den Speicher für die Freigabe kennzeichnen
            //    Hier wird das Gegenteil vom Konstruktor benötigt,
            //    => der Destruktor
            //       Weil Programmierer auf den Aufruf immer vergessen haben,
            //       macht .Net das jetzt "automatisch"
            //       Technik: .Net Garbage Collection
            //                (System.GC)
            //
            //    ===================
            //    In der .Net Programmierung kann der
            //    Desktruktor NICHT von den Programmierern
            //    aufgerufen werden.
            //    ===================
            //
            //    Die Garbage Collection ist extrem komplex
            //    Vor allem, wie merkt die Garbage Collection,
            //    dass ein Objekt nicht mehr benutzt wird?
            //    => durch "Wegschmeissen der Speicheradresse"

            //AlgoObjekt.dis...
            //            ^-> Keine Dispose() Methode. D. h. das Objekt
            //                muss nichts zusammenräumen. 
            //               Falls ein Dispose() gibt
            //               UNBEDINGT AUFRUFEN!!!!!!!!
            //               ==========================
            AlgoObjekt = null;

#if DEBUG
            //NIE IN DER REALITÄT!!! NUR HIER ZU DEMONSTRATIONSZWECKEN!!!
            //DIE GARBAGE COLLECTION IN RUHE LASSEN!
            //-> manuelle Müllsammlung
            System.GC.Collect();
            System.GC.WaitForPendingFinalizers();
            //                      ^-> englisch für Destruktor

            //Damit die Entwickler wissen, dass die Eingabetaste
            //zum Beenden zu tippen ist...
            //Anwendung.Ausgeben("Zum Beenden die Eingabetaste tippen...", true);
            //                                                               ^-> Warum "true"?
            //Tipp: Benannte Parameter einsetzen
            Anwendung.Ausgeben("Zum Beenden die Eingabetaste tippen...", debug: true);

            //Damit das Anwendungsfenster offen bleibt
            System.Console.ReadLine();
#endif
        }

        /// <summary>
        /// Internes Feld zum Cachen der ZeigeMenü Ausgabe.
        /// </summary>
        private static string _MenüText = null;

        /// <summary>
        /// Gibt die möglichen Programmpunkte
        /// am Bildschirm aus.
        /// </summary>
        private static void ZeigeMenü()
        {
            Anwendung.Ausgeben("ZeigeMenü startet...", debug: true);

            if (Anwendung._MenüText == null)
            {
                //KEINE Texte verketten! Nicht "Algorithmenbausteine\r\n" + "1. Sequenz,...
                //
                //Zum Verketten von Text ausschließlich den System.Text.StringBuilder verwenden!!!
                var Text = new System.Text.StringBuilder();

                Text.AppendLine("Algorithmen Bausteine:");
                Text.AppendLine();
                Text.AppendLine(" 1. Sequenz");
                Text.AppendLine(" 2. Binärentscheidung");
                Text.AppendLine(" 3. Fallentscheidung");
                Text.AppendLine(" 4. Zählschleife");
                Text.AppendLine(" 5. Abweiseschleife");
                Text.AppendLine(" 6. Durchlaufeschleife");
                Text.AppendLine();
                Text.AppendLine(" 9. Beenden");

                Anwendung._MenüText = Text.ToString();

                //Text.dis...
                Text = null;

                Anwendung.Ausgeben("Die Anwendung hat den Menütext gecachet...", AusgabeModus.Debug);

            }

            Anwendung.Ausgeben(Anwendung._MenüText);

            Anwendung.Ausgeben("ZeigeMenü beendet.", debug: true);
        }

        /// <summary>
        /// Fragt die Benutzer nach dem Namen und
        /// begrüßt diese passend zur aktuellen Computer Stunde.
        /// </summary>
        /// <remarks>Wird kein Name angegeben, verwendet
        /// die Methode den Namen des aktuellen Kontos.</remarks>
        private static void Begrüßen()
        {
            Anwendung.Ausgeben("Begrüßen startet...", AusgabeModus.Debug);

            //Speicher reservieren
            //Die Frage kommt später für mehrsprachige Anwendungen
            //aus Ressource-Dateien
            const string Frage = "Wie heißen Sie? ";
            //                                   ^-> Damit ein Abstand zur Antwort ist

            //Frage ausgeben
            Anwendung.Ausgeben(Frage, AusgabeModus.NormalOhneVorschub);

            //Den Namen lesen
            var Name = System.Console.ReadLine().Trim();
            //                                     ^-> Die Leerzeichen der Eingabe 
            //                                         vorne und hinten entfernen!

            //Falls kein Name vorhanden ist,
            //den Namen vom Betriebssytem nehmen
            if (Name.Length == 0)
            {
                Name = System.Environment.UserName;
            }

            //Für die aktuelle Computer Stunde die
            //Begrüßung ermitteln und vor dem Rufzeichen
            //den Namen beistrich getrennt einsetzen und ausgeben
            Anwendung.Ausgeben(Algorithmus.ErmittleBegrüßung(System.DateTime.Now.Hour).Replace("!", ", " + Name + "!"));
            //                                                   <--------- || --------------->
            Anwendung.Ausgeben("Begrüßen beendet.", AusgabeModus.Debug);
        }
    }
}
