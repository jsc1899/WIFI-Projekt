﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Lernen
{
    /// <summary>
    /// Steuert die Ausgabe Möglichkeiten
    /// </summary>
    public enum AusgabeModus
    {
        Normal,
        NormalOhneVorschub,
        Debug,
        Fehler
    }

    /// <summary>
    /// Unterstützt sämtliche WIFI Lernen Klassen.
    /// </summary>
    /// <remarks>Diese Klasse kann nur als 
    /// Basisklasse benutzt werden (abstract).</remarks>
    public abstract class Entwicklungsbasis : System.Object
    //                                                  ^-> alle Klassen sind eine Erweiterung
    //                                                      der .Net Object Klasse. Standard Typ
    //                                              ^-> Punkt: Zugriffsoperator
    //                                          ^-> "System" ist der Namespace, indem Object gefunden
    //                                              wird (voll qualifiziert)
    //                                      ^-> Doppelpunkt ist der Operator für die
    //                                          Vererbung, d.h. System.Object wird erweitert durch...
    //                          ^-> Name der eigenen Klasse. Pascal-Notation, Substantiv, 
    //                              keine ungarische Notation, also "cEntwicklungs..."
    //              ^-> "class" ist das C# Schlüsselwort zum Implementieren einer 
    //                   eigenen Klasse
    //      ^-> "abstract" - Modifizierer der angibt, dass
    //          diese Klasse nur als Basisklasse benutzt werden kann (Kein Objekt möglich)
    //->"public" ist ein Zugriffsmodifizierer
    //      "internal": Nur innerhalb der Klasse nutzbar
    //      "public": auch außerhalb der Assembly (WIFI.Sishar.Lernen)
    {
       
        /// <summary>
        /// Schreibt den Text für den Benutzer auf den Bildschirm.
        /// </summary>
        /// <param name="text">Hinweis, der angezeigt werden soll.</param>
        /// <remarks>Hier handelt es sich um eine "überladene" Methode.
        /// D.h. derselbe Methodenname öfter aber mit unterschiedlicher 
        /// Schnittstelle.</remarks>
        protected static void Ausgeben(string text)
        //                             |---------| -> die Schnittstelle
        //                              Hier können "Daten" an die Methode übergeben werden
        //                              (später beim Benutzen)
        //                      ^-> eine Methode muss ein Verb sein
        //          ^-> "static" deshalb, weil diese Methode auch
        //              im Haupteinstiegspunkt Main() benutzt werden soll
        //              und in einer statischen Methode nur andere Methoden
        //              direkt benutzt werden können, wenn diese ebensfalls statisch sind
        //-> "protected" heißt, dass in einem Objekt Ausgeben nicht sichtbar ist,
        //   aber in einer abgeleiteten Klassen genutzt werden kann
        //   Mittelding zwischen "public" und "private"
        {

            //eine überladene Methode kann einfach eine
            //andere Version aufrufen...
            //               ========
            Entwicklungsbasis.Ausgeben(text, debug: false);
            //                                     ^-> jede C# Anweisung muss mit Strichpunkt beendet werden
            //                        |-----------| -> Die Daten für die Parameter der Schnittstelle
            //                  ^-> die zweite Überladung
            //-> der Name Klasse, weil "Ausgeben" statisch ist
            //   (sonst müsste ein Objekt benutzt werden)
        }

        /// <summary>
        /// Schreibt den Text auf den Bildschirm.
        /// </summary>
        /// <param name="text">Der Hinweis, der angezeigt werden soll.</param>
        /// <param name="modus">Steuert, wie der Text angezeigt wird.</param>
        protected static void Ausgeben(string text, AusgabeModus modus)
        //                                              ^-> Hauptvorteil der Aufzählungen:
        //                                                  Diese können als Datentyp benutzt werden
        //                                                  und erlauben später nur Daten, die
        //                                                  in der Auflistung aufgezählt sind
        {
            switch (modus)
            {
                case AusgabeModus.Debug:
                    Entwicklungsbasis.Ausgeben(text, debug: true);
                    break;

                case AusgabeModus.Fehler:
                    System.Console.ForegroundColor = ConsoleColor.Yellow;
                    System.Console.WriteLine(text);
                    System.Console.ResetColor();
                    break;

                case AusgabeModus.Normal:
                    Entwicklungsbasis.Ausgeben(text, debug: false);
                    break;

                case AusgabeModus.NormalOhneVorschub:
                    System.Console.Write(text);
                    break;

#if DEBUG
                default:
                    Entwicklungsbasis.Ausgeben($"FEHLER: Ausgeben kennt \"{modus}\" nicht!", AusgabeModus.Fehler);
                    //                  ^-> wir sind gerade in dieser Methode und
                    //                      rufen uns "selber" auf. So etwas
                    //                      heißt "Rekursion"
                    //                      Hier bewusst benutzt. Oft passiert
                    //                      das irrtümlich, was zu einem Absturz 
                    //                      "Stapel-Überlauf (Stack overflow)" führt
                    break;

#endif
            }
        }

        /// <summary>
        /// Schreibt den Text auf den Bildschirm.
        /// </summary>
        /// <param name="text">Hinweis, der angezeigt werden soll.</param>
        /// <param name="debug">False, wenn der Text für den Benutzer ist.
        /// True, falls der Text nur für Entwicklungszwecke zum Debuggen benötigt wird.</param>
        /// <remarks>Hier handelt es sich um eine "überladene" Methode.
        /// D.h. derselbe Methodenname öfter aber mit unterschiedlicher 
        /// Schnittstelle.</remarks>
        protected static void Ausgeben(string text, bool debug)
        //                                                 ^-> hat das etwas mit dem
        //                                                     Visual Studio "Debug" in der
        //                                                     Symbolleiste zu tun? -> NEIN
        //                                                     Das in der Symbolleiste ist ganz etwas anderes
        //                            |-----------------------|
        //                              Die Daten kommen von der
        //                              benutzenden Stelle, z. B. im Konstruktor
        {
            
            //Binärentscheidung:
            if (debug)
            //-> Binärentscheidung benötigt in runden Klammern
            //   einen Ausdruck, der true oder false ergibt
            //   (Unser Parameter debug, weil dieser bereits Boolean,
            //    also true oder false ist)
            //Bitte nicht
            //if (debug == true)
            //          ^-> Operator für GLEICH, zwei Istgleich-Zeichen
            {

                //Soll beim Kunden "fehlen"
                //(Release-Version)
#if DEBUG
//^-> Präprozessor Direktive

                //Sequenz:
                //Die Farbe wechseln
                System.Console.ForegroundColor = ConsoleColor.DarkGray;
                //                                       ^-> .Net Enumeration
                //                             ^-> Wertzuweisungsoperator
                //                  ^-> Substantiv, also Eigenschaft
                //                      keine runde Klammer


                //Ausgeben
                System.Console.WriteLine(text);
                //                ^-> Verb, also Methode
                //                    immer runde Klammern für die Schnittstelle

                //Die ursprüngliche Farbe wiederherstellen
                System.Console.ResetColor();
#endif
            }
            else
            {
                //Sonst "normal" schreiben
                System.Console.WriteLine(text);
            }
        }

        /// <summary>
        /// Initialisiert ein neues Objekt.
        /// </summary>
        /// <remarks>Im Protokoll wird eingetragen, dass ein
        /// Objekt erstellt wurde.
        /// Hier handelt es sich um den Konstruktor. MUSS wie die Klasse heißen.
        /// Wird durch das "new" Schlüsselwort aufgerufen.</remarks>
        public Entwicklungsbasis()
        {
            Entwicklungsbasis.Ausgeben($"Ein Objekt \"{this.GetType().Name}\" lebt...", debug: true);
            //                                                             ^-> C# unterstützt sämtliche 
            //                                                                 https://de.wikipedia.org/wiki/Escape-Sequenz    
            //                                                 ^-> Zauberwort für die .Net Reflection. 
            //                                                     Damit bekommt man Informationen über ein Objekt
            //                                         ^-> "Zauberwort auf das aktuelle Objekt
            //                                             Bei uns später also z. B. Lotto, Textdatei, Algorithmus
            //                                             Kurz: einfach "this" zum Zugreifen auf das Objekt
            //                         ^-> Dollar, ermöglicht das direkte Einsetzen
            //                             von Variablen in einen Text (Kurzform für die System.String.Format Methode)
        }

        //Soll nicht in der Kundenversion sein
#if DEBUG

        /// <summary>
        /// Zerstört ein Objekt.
        /// </summary>
        /// <remarks>Hier handelt es sich um den
        /// Destruktor. Kann nicht mehr von der
        /// Programmierung aufgerufen werden. Nur mehr
        /// vom Garbage Collector. Deshalb wird's kaum
        /// Klassen mit Destruktoren geben. 
        /// Laut .Net muss ein Objekt, das etwas zum
        /// Zusammenräumen hat, eine Dispose-Methode besitzen (Teil 1)</remarks>
        ~Entwicklungsbasis()
        {
            Entwicklungsbasis.Ausgeben($"Ein Objekt \"{this.GetType().Name}\" ist tot.", debug: true);
        }

#endif

        //Hier ist die Klassenebene
        //Deklarationen für Variablen hier sind
        //IMMER privat.
        //Grundprinzip der objektorientieren Programmierung:
        //================
        //D A T E N K A P S E L U N G
        //================
        //Variablen auf Klassenebene werden als Feld bezeichnet.

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private static System.Random _Zufallsgenerator = null;
        //                                             ^-> Operator für Wertzuweisung
        //          ^-> weil's nur GENAU EINEN ZUFALLSGENERATOR GEBEN DARF.

        /// <summary>
        /// Ruft den Würfel der Anwendung ab.
        /// </summary>
        /// <remarks>Der Kommentar einer Eigenschaft beginnt
        /// immer mit "Ruft ab". Falls die Eigenschaft nicht
        /// schreibgeschützt ist, kommt noch "oder legt fest" dazu.</remarks>
        protected System.Random Zufallsgenerator
        {
            get
            {
                //Beim Holen des Zufallsgenerators darf
                //nicht jedes Mal ein neues Objekt gemacht werden,
                //weil dann die Gleichverteilung gestört ist.

                //Wir müssen uns unser Random-Objekt "merken"
                //=> Auf Klassenebene. Variablen auf Klassenebene 
                //   werden als Feld bezeichnet.

                //Prüfen, ob bereits ein Zufallsgenerator existiert.
                //Wenn nicht diesen erstellen
                if (Entwicklungsbasis._Zufallsgenerator == null)
                //                                      ^-> Operator für "gleich", Syntax (ist so)
                {
                    Entwicklungsbasis._Zufallsgenerator = new System.Random();
                    Entwicklungsbasis.Ausgeben("Die Anwendung hat den Zufallsgenerator erstellt...", debug: true);
                    //                         |---- darf nur EINMAL ausgegeben werden (weil "static")
                }

                return Entwicklungsbasis._Zufallsgenerator;
                //-> "return" Schlüsselwort bei allen Sprachen, damit
                //   ein Wert zurückgegeben wird.
            }

            /*
            set
            {
            //Unser Zufallsgenerator ist schreibgeschützt!
            }
            */
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        /// <remarks>Die Anwendung kann nur genau 
        /// eine Anwendungsverzeichnis besitzen, deshalb "statisch".</remarks>
        private static string _Anwendungsverzeichnis = null;

        /// <summary>
        /// Ruft das Verzeichnis ab, aus dem die Anwendung gestartet wurde.
        /// </summary>
        protected string Anwendungsverzeichnis
        {
            get
            {

                if (Entwicklungsbasis._Anwendungsverzeichnis == null)
                {
                    Entwicklungsbasis._Anwendungsverzeichnis 
                        = System.IO.Path.GetDirectoryName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);

                    Entwicklungsbasis.Ausgeben("Die Anwendung hat das Startverzeichnis gecachet...", AusgabeModus.Debug);
                }

                return Entwicklungsbasis._Anwendungsverzeichnis;
            }
        }
    }

}
