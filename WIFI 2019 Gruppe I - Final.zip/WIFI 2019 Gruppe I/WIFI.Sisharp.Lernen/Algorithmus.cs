﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Lernen
{ //<- Hier beginnt die Gültigkeit "WIFI.Sisharp.Lernen"

    /// <summary>
    /// Enthält für jeden Programmierbaustein
    /// ein Beispiel zum Lernen.
    /// </summary>
    /// <remarks>Hier handelt es sich um Xml-Dokumentationskommentar.</remarks>
    internal class Algorithmus : Entwicklungsbasis
    //-> Zugriffsmodifizierer, dass die Klasse nur
    //   innerhalb der Assembly sichtbar. Standard
    //   Konvention: "Die Lesbarkeit geht vor der Kürze"
    { //<- Hier beginnt die Gültigkeit der Klasse Algorithmus

        /// <summary>
        /// Gibt den obligatorischen "Hallo Welt!" 
        /// Text am Bildschirm aus.
        /// </summary>
        public void ZeigeSequenz()
        { //<- Beginn Gültigkeit der Methode

            //Für die Entwicklung...
            Algorithmus.Ausgeben(debug: true, text: "ZeigeSequenz startet..." );
            //                      ^-> beim Einsetzen von benannten Parametern
            //                          muss die Reihenfolge dieser nicht beachtet werden.
            //                          Ab dem ersten benannten Parameter muss der
            //                          Rest aber auch benannt sein

            //(1) Speicher für "Hallo Welt!" reservieren
            //System.String Hinweis = "Hallo Welt!";
            //-------------
            string Hinweis = "Hallo objektorientierte Welt!";
            //^-> zeigt auf System.String
            //Tipp: Release-Texte (für den Kunden)
            //      immer in eigenen Variablen
            //      Warum?
            //      -> damit die Oberfläche einer
            //         Anwendung "mehrsprachig" realisiert werden kann
            //         (Diese Texte kommen aus Ressource-Dateien, Teil 1)

            //(2) Ausgeben von "Hallo Welt!"
            Algorithmus.Ausgeben(Hinweis);
            //              ^-> die 1. Überladung, ruft intern die zweite
            //                  Überladung mit "debug: false" auf, d.h.
            //                  steht in der Kundenversion ("Release") am Bildschirm
            //                  Überladung: nur um den Komfort zu erhöhen

            Algorithmus.Ausgeben("ZeigeSequenz beendet.", debug: true);
            //              ^-> die 2. Überladung direkt, damit im 2. Parameter
            //                  "true" benutzt werden, damit später beim
            //                  Kunden das nicht angezeigt wird (Debug-Version)
        } //<- Ende Gültigkeit

        /// <summary>
        /// Eine zufällige Ganzzahl zwischen 1 und 100
        /// würfeln und ausgeben, ob die Zahl unter 50
        /// oder größer gleich 50 ist.
        /// </summary>
        public void ZeigeBinär()
        {

            //Falls eine Methode bereits beim Kunden war und
            //Änderungen durchgeführt, nie alten Code löschen

            //Änderungen
            // 20181115 Die Methode gibt die Grenze genau an.

            Algorithmus.Ausgeben("ZeigeBinär startet...", debug: true);

            //Speicherreservierungen
            //-> für die Texte
            //   Diese Texte kommen in Wirklichkeit später aus Ressource-Dateien (ab Teil 1)
            const string HinweisKleiner = "Die Zahl {0} ist kleiner der Grenze {1}!";

            //20181115 Grenze genau melden
            //const string HinweisGrößerGleich = "Die Zahl {0} ist größer oder gleich der Grenze {1}!";
            //                                           |-|-> Platzhalter für die formatierte Ausgabe
            //                                                 mit System.String.Format(...) Methode!
            const string HinweisGrößer = "Die Zahl {0} ist größer der Grenze {1}!";
            const string HinweisGleich = "Die Zahl {0} ist genau die Grenze!";

            //-> zum Rechnen
            const int Untergrenze = 1;
            //    |-------------------> Eine "Variable", deren Wert 
            //                          zur Laufzeit veränderbar ist.
            //-> mit "const" kann sich der Wert zur Laufzeit NICHT MEHR ÄNDERN
            const int Obergrenze = 100;
            const int Grenze = 50;
            //     ^-> "struct" => Werttyp, kann nicht "null" sein

            //Die Zufallszahl ist nicht bekannt, d.h
            //=> eine Variable
            var Zufallszahl = this.Zufallsgenerator.Next(Untergrenze, Obergrenze + 1);
            //                                                                   ^-> weil im Parameter-Kommentar steht,
            //                                                                       dass es sich um einen "exklusiven" (also nicht enthalten)
            //                                                                       Wert handelt.
            //-> Schlüsselwort, dass sich der Compiler den
            //   Typ ermitteln soll. Weil die Next()-Methode "int" zurückgibt,
            //   ist auch unsere Variable "Zufallsgenerator" vom Typ int.

            if (Zufallszahl < Grenze)
            {
                //Falls die Zahl kleiner der Grenze ist

                //WEHE!!!! NIE SO!!!
                //Algorithmus.Ausgeben("Die Zahl " + Zufallszahl + ...)
                //                     |------------------------------|
                //                          Keine solchen Verkettungen!!!
                //                          Warum?
                //                              1. Langsam
                //                              2. Hauptgrund:
                //                                  Nicht in andere Sprachen übersetzbar!!!

                //unbedingte die .Net Textformatierungsmethode benutzen!
                Algorithmus.Ausgeben(string.Format(HinweisKleiner, Zufallszahl, Grenze));
                //                                                   Wert {0}   Wert {1}
                //                                      ^-> aus einer übersetzbaren Ressourdatei
                //                                          ein Text mit {0} und {1}
            }

            //20181115
            else if (Zufallszahl == Grenze)
            {
                Algorithmus.Ausgeben(string.Format(HinweisGleich, Zufallszahl));
            }
            //---

            else
            {
                //Falls die Zahl größer oder gleich ist

                //20181115
                //Algorithmus.Ausgeben(string.Format(HinweisGrößerGleich, Zufallszahl, Grenze));
                Algorithmus.Ausgeben(string.Format(HinweisGrößer, Zufallszahl, Grenze));
            }

            Algorithmus.Ausgeben("ZeigeBinär beendet.", debug: true);
        }

        /// <summary>
        /// Zeigt zu einer zufälligen Stunde
        /// einen Begrüßungtext an.
        /// </summary>
        public void ZeigeFall()
        {
            Algorithmus.Ausgeben("ZeigeFall startet...", debug: true);

            //Ausgabemuster deklarieren
            const string Ausgabemuster = "{0} Es ist {1} Uhr...";
            //                  ^-> kommt später aus einer "lokalisierten" Ressource Datei

            //Eine zufällige Stunde berechnen
            var z = this.Zufallsgenerator.Next(24);

            //Das Ausgabemuster für die zufällige Stunde
            //auf den Bildschirm schreiben
            Algorithmus.Ausgeben(string.Format(
                Ausgabemuster, 
                Algorithmus.ErmittleBegrüßung(zuStunde: z), // {0}
                z // {1}
                ));

            Algorithmus.Ausgeben("ZeigeFall beendet.", debug: true);
        }

        /// <summary>
        /// Testet die Begrüßung für
        /// jede mögliche Stunde.
        /// </summary>
        public void ZeigeZählen()
        { //<- Hier beginnt eine "private" Gültigkeit
            Algorithmus.Ausgeben("ZeigeZählen startet...", debug: true);

            //Ausgabemuster deklarieren
            const string Ausgabemuster = "{0} Es ist {1} Uhr...";

            //Idee:
            /*
            //-> Fad, wäre eine Sequenz
            Algorithmus.Ausgeben(string.Format(
                Ausgabemuster,
                Algorithmus.ErmittleBegrüßung(0), // {0}
                0 // {1}
                ));
            Algorithmus.Ausgeben(string.Format(
                Ausgabemuster,
                Algorithmus.ErmittleBegrüßung(1), // {0}
                1 // {1}
                ));
            //...
            Algorithmus.Ausgeben(string.Format(
                Ausgabemuster,
                Algorithmus.ErmittleBegrüßung(23), // {0}
                //                             ^-> (I)ndex
                23 // {1}
                ));
            */
            //Lösung:
            //=> Ein Schleife
            //      a) Die Anzahl ist unbekannt, aber mind. 1x
            //         (Durchlaufeschleife, hier nicht)
            //      b) Die Anzahl ist vollkommen unbekannt, unter Umständen nie
            //         (Abweiseschleife, hier nicht)
            //      c) Die Anzahl der Wiederholungen ist vor dem
            //         Schleifeneintritt bekannt (fix oder berechnet)
            //=> Die Zählschleife
            //   in allen Sprachen: for - Anweisung
            //   Ungeschriebenes Gesetz: der Zähler heißt "i", wie Index

            for (var i = 0; i < 24; i++)
            {
                Algorithmus.Ausgeben(string.Format(
                    Ausgabemuster,
                    Algorithmus.ErmittleBegrüßung(i), // {0}
                    i // {1}
                    ));
            }

            Algorithmus.Ausgeben("ZeigeZählen beendet.", debug: true);
        } //<- Hier endet die Gültigkeit. Alle Deklarationen innerhalb
        //     der Methode sind wieder ungültig

        /// <summary>
        /// Liest den Inhalt einer unformatierten
        /// Textdatei und gibt diesen am Bildschirm aus.
        /// </summary>
        /// <remarks>Die Datei muss Wörter.txt heißen
        /// und in demselben Verzeichnis wie die Anwendung liegen.</remarks>
        public void ZeigeAbweisen()
        {
            Algorithmus.Ausgeben("ZeigeAbweisen startet...", debug: true);

            const string Dateiname = "Wörter.txt";

            //-> Jammerei, kann man das abkürzen?
            /*
            //(1) Objektvariable deklarieren
            Textdatei Datei = null;
            // ^-> geht das nicht einmal?

            //(2) Klasse initialisieren
            Datei = new Textdatei();
            */
            //NUR, wenn ein Objekt sofort benötigt wird,
            //können Punkt (1) und (2) in einer Zeile geschrieben werden
            //(weil "new" langsam ist, wirklich nur, wenn
            // das Objekt sofort benötigt wird)

            //seit 2008: neues Schlüsselwort
            var Datei = new Textdatei();
            //-> "var" -> Compiler, bestimme den Datentyp aus der Instanzierung

            //(3) Benutzen
            Datei.Pfad = System.IO.Path.Combine(this.Anwendungsverzeichnis, Dateiname);
            Datei.Lesen();

            Algorithmus.Ausgeben(Datei.HoleFließtext(maxZeilenlänge: 50));

            //(4) Zusammenräumen. Gibt's ein Dispose
            Datei = null;

            Algorithmus.Ausgeben("ZeigeAbweisen beendet.", debug: true);
        }

        /// <summary>
        /// Zeigt einen Lottoquicktipp
        /// für ein unterstütztes Land an.
        /// </summary>
        public void ZeigeDurchlaufen()
        {
            Algorithmus.Ausgeben( debug: true, text: "ZeigeDurchlaufen startet...");

            var Lotto = new Lotto();

            Algorithmus.Ausgeben(Lotto.Land.ToString());

            var Zahlen = string.Empty;
            
            foreach (var Zahl in Lotto.BerechneQuicktipp())
            {
                Zahlen += Zahl.ToString().PadLeft(3);
            }

            Algorithmus.Ausgeben(Zahlen);

            Lotto = null;

            Algorithmus.Ausgeben("ZeigeDurchlaufen beendet.", debug: true);
        }

        /// <summary>
        /// Gibt passend zur Stunde einen Begrüßungstext zurück.
        /// </summary>
        /// <param name="zuStunde">Eine Zahl zwischen 0 und 23.</param>
        /// <remarks>Von 5 bis 10 Guten Morgen, von 11 bis 14 Mahlzeit, 
        /// von 18 bis 22 Guten Abend und sonst Grüß Gott!</remarks>
        public static string ErmittleBegrüßung(int zuStunde)
        //                                          ^-> die willkürlilch gewählte Bezeichnung
        //                                              für den Wert, den ErmittleBegrüßung benötigt
        //                                    |------------|
        //                                      Schnittstelle
        {

            //Speicherreservierung für die Rückgabe
            //(später aus einer Ressourcedatei)
            const string GrußAmMorgen = "Guten Morgen!";
            const string GrußZuMittag = "Mahlzeit!";
            const string GrußAmAbend = "Guten Abend!";
            const string StandardGruß = "Grüß Gott!";

            //Weil wir den Gruß noch nicht kennen...
            var Ergebnis = StandardGruß;

            //Abhängig vom Parameter "zuStunde"
            //einen anderen Gruß einstellen

            //Nicht schön
            //Drei Binärentscheidungen mit "if"

            //Eleganter:
            //-> Fallentscheidung

            //Bis C# 2016 wie C
            /*
            switch (zuStunde)
            {
                case 5:
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                    Ergebnis = GrußAmMorgen;
                    break;
                //...
            }
            */
            //Seit C# 2016 7.0 voi cool
            //(weil wie in Basic)
            switch (zuStunde)
            //          ^-> Parameter aus der Schnittstelle
            {
                case var s when s >= 5 && s <= 10:
                    //                  ^-> logisches Und
                    //                      Zwei Pipes || wären das Oder
                    //      ^-> neues Kontextschlüsselwort "when" seit 2016,
                    //          damit mit der C# Fallentscheidung in einem
                    //          Zweig mehrere Prüfungen durchgeführt werden können
                    // ^-> "s" wie Stunde; wird als "Lambda" bezeichnet, Details im Teil 1
                    //     (Hilfsvariable, notwendig damit when arbeitet, Syntax)
                    Ergebnis = GrußAmMorgen;
                    break;

                case var s when s >= 11 && s <= 14:
                    Ergebnis = GrußZuMittag;
                    break;

                case var s when s >= 18 && s <= 22:
                    Ergebnis = GrußAmAbend;
                    break;
            }

            return Ergebnis;

        }

    } //<-> Ende Gültigkeit der Algorithmus-Klasse
} //<- Ende Gültigkeit Namespace "WIFI.Sishapr.Lernen"
//in BASIC "End Namespace"
