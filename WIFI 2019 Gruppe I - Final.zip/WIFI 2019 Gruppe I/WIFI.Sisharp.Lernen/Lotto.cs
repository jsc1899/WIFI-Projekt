﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIFI.Sisharp.Lernen
{

    /// <summary>
    /// Listet die möglichen Länder
    /// auf, die vom Lotto unterstützt werden.
    /// </summary>
    public enum LottoLänder
    {
        Österreich,
        Deutschland,
        Italien
    }

    /// <summary>
    /// Stellt einen Dienst zum Berechnen 
    /// eines Lotto Quicktipps für 
    /// diverse Länder bereit.
    /// </summary>
    public sealed class Lotto : Entwicklungsbasis
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        /// <remarks>Immer mit dem Feld arbeiten.
        /// Nicht mit der impliziten Variante.</remarks>
        private LottoLänder _Land = LottoLänder.Österreich;

        /*
        //BITTE NICHT!!!!
        public LottoLänder Lottoland
        //                  ^-> nicht im Namen eines
        //                      Mitglieds den Namen der Klasse
        //                      wiederholen!!!!
        { ...
        */

        /// <summary>
        /// Ruft das Land, in dem gespielt wird, 
        /// ab oder legt dieses fest.
        /// </summary>
        /// <remarks>Der Standardwert ist Österreich.</remarks>
        public LottoLänder Land
        {
            get
            {
                //Wie eine Funktionsmethode, gibt zurück.
                return this._Land;
                //      ^-> Zeiger auf das aktuelle Objekt
            }
            set
            { //<- Hier beginnt die Gültigkeit
                //Wie eine Methode, ohne Rückgabe, also "void"
                //Von wo kommt der neue Wert?
                //  -> über die Schnittstelle
                //  -> Diese Methode ist vom Compiler
                //  -> Wie nennt der Compiler den Parameter?
                //  => value

                this._Land = value;
                //             ^-> der vom Compiler benutzte Bezeichner
                //                 für den Parameter des neuen Werts
                //                 (muss man wissen)

                //Wegen der ständigen Jammerei, ob
                //das so gemacht werden muss?
                //=>JA, auch wenn's eine kürze Variante gäbe
                //  Diese ist nicht brauchbar, weil

                //HIER muss ein Ereignis ausgelöst werden,
                //dass sich der Wert der Eigenschaft verändert hat
                //(Neue Windows Oberflächen Programmierung, 
                //Windows Presentation Foundation WPF, Teil 2)

            } //<- Hier ist die Gültigkeit zu ende, der Wert weg
        }

        /// <summary>
        /// Ruft die Anzahl der Zahlen eines 
        /// Tipps für das eingestellte Land ab.
        /// </summary>
        public int AnzahlZahlen
        {
            get
            {
                switch (this.Land)
                {
                    case LottoLänder.Österreich:
                    case LottoLänder.Italien:
                    case LottoLänder.Deutschland:
                        return 6;
                        //^-> nach der return - Anweisung
                        //    wird keine weitere Anweisung ausgeführt
                        //deshalb kann hier auf "break;" verzichtet werden
                    default:
                        return -1;
                        //-> damit ein "unbekanntes" Land
                        //   auch zu einer Rückgabe führt
                        //   (weil sonst der Kompiler beim "get" meckert)
                }
            }
        }

        /// <summary>
        /// Ruft die höchste Lottozahl
        /// für das eingestellte Land ab.
        /// </summary>
        public int HöchsteZahl
        {
            get
            {
                switch (this.Land)
                {
                    case LottoLänder.Österreich:
                        return 45;
                    case LottoLänder.Italien:
                        return 90;
                    case LottoLänder.Deutschland:
                        return 49;
                    //^-> nach der return - Anweisung
                    //    wird keine weitere Anweisung ausgeführt
                    //deshalb kann hier auf "break;" verzichtet werden
                    default:
                        return -1;
                        //-> damit ein "unbekanntes" Land
                        //   auch zu einer Rückgabe führt
                        //   (weil sonst der Kompiler beim "get" meckert)
                }
            }
        }

        //public int
        //        ^-> wäre nur eine Zahl
        //Wir benötigen ein Datenfeld (Array)

        /// <summary>
        /// Gibt einen Quicktipp für das eingestellte Land zurück.
        /// </summary>
        /// <returns>Ein Datenfeld mit der Anzahl der Zahlen.</returns>
        public int[] BerechneQuicktipp()
        //        ^-> die eckigen Klammern in C#
        //            als Hinweis auf ein C# Datenfeld
        {

            var Ergebnis = new int[this.AnzahlZahlen];
            //             |------------------------|
            //              Ein C# Array statisch,
            //              kann ab jetzt im Umfang nicht
            //              mehr geändert werden.
            var AktuelleAnzahl = 0;

            do
            {
                var NeueZahl = this.Zufallsgenerator.Next(1, this.HöchsteZahl + 1);

                var i = 0;
                var Gefunden = false;
                
                //Ab der zweiten Zahl nachsehen, ob diese schon vorhanden ist
                while (i < AktuelleAnzahl && !Gefunden)
                {
                    if (Ergebnis[i] == NeueZahl)
                    {
                        Gefunden = true;
                    }
                    else
                    {
                        i++;
                    }
                }

                //Nur merken, wenn die neue Zahl noch nicht vorhanden ist
                if (!Gefunden)
                {
                    Ergebnis[AktuelleAnzahl] = NeueZahl;
                    AktuelleAnzahl++;
                }

            } while (AktuelleAnzahl < this.AnzahlZahlen);

            return Ergebnis;
        }

    }
}
