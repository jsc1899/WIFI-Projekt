﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für BestellungAuswahl.xaml
    /// </summary>
    public partial class BestellungAuswahl : UserControl
    {
        public BestellungAuswahl()
        {
            InitializeComponent();
        }

        private void Bestellungfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BestellungOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Bestellungen.ItemsSource);

            BestellungOriginal.Filter = (bestellung) =>
            {
                if (String.IsNullOrEmpty(Bestellungfilter.Text))
                {
                    return true;
                }
                else
                {
                    if (((Daten.Bestellung)bestellung).Buch.NrUndTitel.ToLower().Contains(Bestellungfilter.Text.ToLower())
                            || ((Daten.Bestellung)bestellung).Kunde.KompletterName.ToLower().Contains(Bestellungfilter.Text.ToLower())
                        )
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            };

            BestellungOriginal.Refresh();

        }

        private void Bestellungfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Bestellungfilter.Text = "Damit es keinen Treffer gibt und AktuelleBestellung zurückgesetzt wird";
            Bestellungfilter_KeyUp(Bestellungfilter, null);
            Bestellungfilter.Text = string.Empty;
            Bestellungfilter_KeyUp(Bestellungfilter, null);
        }

    }
}
