﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.ViewModels
{
    /// <summary>
    /// Steuert die Hauptoberfläche der Anwendung.
    /// </summary>
    /// <remarks>Im Rahmen von MVVM handelt es sich um
    /// ein VM (ViewModel) Objekt.</remarks>
    public class FensterManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Wird vom Starten initialisiert und
        /// beim Anzeigen eines neuens Fensters benötigt.
        /// </summary>
        private static Type _FensterTyp = null;

        /// <summary>
        /// Zeigt ein Fenster des gewünschten Typs an
        /// und macht es zum Hauptfenster der WPF Anwendung.
        /// </summary>
        /// <typeparam name="T">Der Typ der anzuzeigenden View.</typeparam>
        public void Starten<T>() where T : System.Windows.Window, new()
        {

            this.AktiviereBeschäftigt("ViewModel");

            FensterManager._FensterTyp = typeof(T);

            //var Fenster = new T();
            //var Fenster = System.Activator.CreateInstance<T>();
            //damit trotzdem new funktioniert, eine Typeinschränkung...

            var Fenster = new T();

            this.InitialisiereFenster(Fenster);

            //Das ViewModel und die View "verknüpfen"...
            Fenster.DataContext = this;

            this.DeaktiviereBeschäftigt("ViewModel");

            System.Windows.Application.Current.Run(Fenster);
        }

        /// <summary>
        /// Bereitet ein Fenster für die Anzeige vor.
        /// </summary>
        /// <param name="fenster">Das Fenster-Objekt,
        /// das vorbereitet werden soll.</param>
        protected virtual void InitialisiereFenster(System.Windows.Window fenster)
        {
            this.AktiviereBeschäftigt();

            //Damit xml keine Probleme beim Formatieren
            //von Datumsangaben und anderen Zahlen hat...
            fenster.Language
                = System.Windows.Markup.XmlLanguage.GetLanguage(
                    System.Threading.Thread.CurrentThread.CurrentCulture.IetfLanguageTag);

            //Dazu dem Fenster einen Namen verpassen
            fenster.Name = fenster.GetType().Name;

            //Zum Unterscheiden der Fenster 
            //eine Nummer so anhängen, dass
            //die erste freie Nummer wiederbenutzt wird.

            //Gut, aber aus... LINQ nicht implementiert
            //var OffeneFenster = (from f in System.Windows.Application.Current.Windows select f).ToArray();

            //Also, eine eigene Liste mit den aktuellen Fensternamen aufbauen
            var OffeneFenster = new System.Collections.ArrayList(System.Windows.Application.Current.Windows.Count);
            foreach (System.Windows.Window w in System.Windows.Application.Current.Windows)
            {
                OffeneFenster.Add(w.Name);
            }

            var FreieNummer = 1;
            while (OffeneFenster.Contains(fenster.Name + FreieNummer))
            {
                FreieNummer++;
            }

            fenster.Name += FreieNummer;

            //Eine alte Fensterposition wiederherstellen...
            var AltePosition = this.AppKontext.Fenster.Abrufen(fenster.Name);

            if (AltePosition != null)
            {
                fenster.Left = AltePosition.Links ?? fenster.Left;
                fenster.Top = AltePosition.Oben ?? fenster.Top;
                fenster.Width = AltePosition.Breite ?? fenster.Width;
                fenster.Height = AltePosition.Höhe ?? fenster.Height;

                //Nur Maximiert wiederherstellen, sonst normal,
                //weil minimierte Fenster von den Benutzern übersehen werden
                fenster.WindowState =
                    (System.Windows.WindowState)AltePosition.Zustand == System.Windows.WindowState.Maximized ?
                    System.Windows.WindowState.Maximized : System.Windows.WindowState.Normal;

            }

            //Dafür sorgen, dass beim Schließen
            //die Fensterposition gespeichert wird
            //(dazu ein anonymer Ereignisbehandler)
            fenster.Closing += (sender, e) =>
            {
                //Hr. Grabner; 20190214
                //-> Den CallerMemberName wegen der
                //   anonymen Methode überschreiben
                //this.AktiviereBeschäftigt();
                this.AktiviereBeschäftigt("FensterPositionSpeichern");

                var Position = new WIFI.Anwendung.Daten.Fenster { Name = fenster.Name };

                //Position initialisieren:

                //Auf alle Fälle den Zustand
                Position.Zustand = (int)fenster.WindowState;

                //Die Größenangaben nur, falls ein normales Fenster
                if (fenster.WindowState == System.Windows.WindowState.Normal)
                {
                    Position.Links = (int)fenster.Left;
                    Position.Oben = (int)fenster.Top;
                    Position.Breite = (int)fenster.Width;
                    Position.Höhe = (int)fenster.Height;
                }

                this.AppKontext.Fenster.Hinterlegen(Position);

                //Hr. Grabner; 20190214
                //-> Den CallerMemberName wegen der
                //   anonymen Methode überschreiben
                //this.DeaktiviereBeschäftigt();
                this.DeaktiviereBeschäftigt("FensterPositionSpeichern");

                //Damit die Garbage Collection das
                //WPF Fenster entfernt (nirgendwo ein Dispose)
                //den DataContext freigeben, weil sonst
                //Speicherloch auftritt...
                fenster.DataContext = null;
            };

            this.DeaktiviereBeschäftigt();
        }
        
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgaben _Aufgaben = null;

        /// <summary>
        /// Ruft die Anwendungspunkte ab.
        /// </summary>
        public Model.Aufgaben Aufgaben
        {
            get
            {
                if (this._Aufgaben == null)
                {
                    this.AktiviereBeschäftigt();

                    var AufgabenManager = this.AppKontext.Erzeuge<Model.AufgabenManager>();
                    this._Aufgaben = AufgabenManager.Liste;

                    this.AppKontext.Protokoll.Eintragen("Das Fenster hat die Aufgaben gecachet...");

                    //Die Standardaufgabe aktivieren...
                    var i = Buchausstellung.Properties.Settings.Default.AktuelleAufgabe;
                    if (this._Aufgaben != null && i < this._Aufgaben.Count)
                    {
                        this.AktuelleAufgabe = this._Aufgaben[i];
                        this.AppKontext.Protokoll.Eintragen($"Die Aufgabe \"{this.AktuelleAufgabe.Name}\" wurde aktiviert...");
                    }

                    this.DeaktiviereBeschäftigt();
                }

                return this._Aufgaben;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgabe _MenüpunktProtokoll = null;

        /// <summary>
        /// Ruft den Anwendungspunkt für das Protokoll ab.
        /// </summary>
        public Model.Aufgabe MenüpunktProtokoll
        {
            get
            {
                if (this._MenüpunktProtokoll == null)
                {
                    this.AktiviereBeschäftigt();

                    var AufgabenManager = this.AppKontext.Erzeuge<Model.AufgabenManager>();
                    this._MenüpunktProtokoll = AufgabenManager.MenüpunktProtokoll;

                    this.AppKontext.Protokoll.Eintragen("Das Fenster hat den Anwendungspunkt für das Protokoll gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._MenüpunktProtokoll;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _MenüpunktProtokollAktivieren = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem der Menüpunkt für 
        /// das Protokoll aufgerufen werden kann.
        /// </summary>
        public WIFI.Windows.Befehl MenüpunktProtokollAktivieren
        {
            get
            {
                if (this._MenüpunktProtokollAktivieren == null)
                {
                    this.AktiviereBeschäftigt();

                    this._MenüpunktProtokollAktivieren = new WIFI.Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.AktiviereBeschäftigt();

                            this.AktuelleAufgabe = this.MenüpunktProtokoll;

                            this.AppKontext.Protokoll.Eintragen(
                                $"Die Anwendung hat das Protokoll aufgerufen...");

                            this.DeaktiviereBeschäftigt();
                        });

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._MenüpunktProtokollAktivieren;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Model.Aufgabe _AktuelleAufgabe = null;

        /// <summary>
        /// Ruft den aktuellen Anwendungspunkt
        /// ab oder legt diesen fest.
        /// </summary>
        public Model.Aufgabe AktuelleAufgabe
        {
            get
            {
                return this._AktuelleAufgabe;
            }
            set
            {
                this._AktuelleAufgabe = value;

                if (this._AktuelleAufgabe.Arbeitsbereich == null
                    && this._AktuelleAufgabe.ArbeitsbereichTyp != null)
                {
                    this._AktuelleAufgabe.Arbeitsbereich
                        = System.Activator.CreateInstance(this._AktuelleAufgabe.ArbeitsbereichTyp)
                        as System.Windows.Controls.UserControl;
                }

                //Falls das Protkoll geöffnet wird,
                //unbestätigte Fehler zurücksetzen
                if (this._AktuelleAufgabe.Arbeitsbereich is ProtokollViewer)
                {
                    this.AppKontext.Protokoll.FehlerVorhanden = false;
                }

                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _AufgabeAlsStandardFestlegen = null;

        /// <summary>
        /// Ruft den Befehl ab, mit dem eine
        /// Aufgabe als Standard festgelegt werden kann.
        /// </summary>
        public WIFI.Windows.Befehl AufgabeAlsStandardFestlegen
        {
            get
            {
                if (this._AufgabeAlsStandardFestlegen == null)
                {
                    this.AktiviereBeschäftigt();

                    this._AufgabeAlsStandardFestlegen = new WIFI.Windows.Befehl(
                        //Execute Methode...
                        daten =>
                        {
                            this.AktiviereBeschäftigt();

                            Buchausstellung.Properties.Settings.Default.AktuelleAufgabe
                                = this.Aufgaben.IndexOf(this.AktuelleAufgabe);

                            this.AppKontext.Protokoll.Eintragen(
                                $"Die Anwendung hat die Aufgabe \"{this.AktuelleAufgabe.Name}\" (Index = {Buchausstellung.Properties.Settings.Default.AktuelleAufgabe}) als Standard festgelegt...");

                            this.DeaktiviereBeschäftigt();
                        },
                        //CanExecute Methode...
                        daten => this.AktuelleAufgabe != null
                        );

                    this.AppKontext.Protokoll.Eintragen("Der Befehl wurde gecachet...");

                    this.DeaktiviereBeschäftigt();
                }

                return this._AufgabeAlsStandardFestlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private ViewModels.BuchausstellungManager _BuchausstellungManager = null;

        /// <summary>
        /// Ruft das ViewModel zum Steuern
        /// der Kundenoberfläche ab.
        /// </summary>
        public ViewModels.BuchausstellungManager BuchausstellungManager
        {
            get
            {
                //if (this._BuchausstellungManager == null)
                //{
                    this.AktiviereBeschäftigt();

                    this._BuchausstellungManager = this.AppKontext.Erzeuge<ViewModels.BuchausstellungManager>();
                    this._BuchausstellungManager.Besitzer = this;

                    this.DeaktiviereBeschäftigt();
                //}

                return this._BuchausstellungManager;
            }
        }

    }
}
