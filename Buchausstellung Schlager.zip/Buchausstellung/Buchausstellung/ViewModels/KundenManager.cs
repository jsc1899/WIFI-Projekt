﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Documents.Serialization;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;

namespace Buchausstellung.ViewModels
{
    public class KundenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Daten.Manager.DatenManager _Controller = null;

        /// <summary>
        /// Verwaltet den Kundenmanager.
        /// </summary>
        private Daten.Manager.DatenManager Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Daten.Manager.DatenManager>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Kundenmanager initialisiert hat,
        /// ab oder legt diesen fest.
        /// </summary>
        public FensterManager Besitzer { get; set; }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Kunden _Kunden = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Kunden ab.
        /// </summary>
        public Daten.Kunden Kunden
        {
            get
            {
                if (this._Kunden == null)
                {
                    this._Kunden = this.Controller.KundenHolen();
                }
                return this._Kunden;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundenAktualisieren = null;
        /// <summary>
        /// Ruft den Befehl zum Aktualisieren der Kundenliste ab.
        /// </summary>
        public WIFI.Windows.Befehl KundenAktualisieren
        {
            get
            {
                if (this._KundenAktualisieren == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundenAktualisieren = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._Kunden = null;
                            this.OnPropertyChanged("Kunden");

                            this.KundeSpeichernLäuft = false;
                            this.OnPropertyChanged("KundeSpeichernLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundenAktualisieren;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bücher _Bücher = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bücher ab.
        /// </summary>
        public Daten.Bücher Bücher
        {
            get
            {
                if (this._Bücher == null)
                {
                    this._Bücher = this.Controller.BücherHolen();
                }
                return this._Bücher;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellungen _Bestellungen = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen ab.
        /// </summary>
        public Daten.Bestellungen Bestellungen
        {
            get
            {

                if (this._Bestellungen == null)
                {
                    this._Bestellungen = new Daten.Bestellungen();

                    if (this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
                    {
                        this._Bestellungen = this.Controller.BestellungenHolen();
                    }

                    if (this.OffeneBestellungenAnzeigen && !this.ErledigteBestellungenAnzeigen)
                    {
                        foreach (Daten.Bestellung bestellung in this.Controller.BestellungenHolen())
                        {
                            if (!bestellung.Erledigt)
                            {
                                this._Bestellungen.Add(bestellung);
                            }
                        }
                    }

                    if (!this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
                    {
                        foreach (Daten.Bestellung bestellung in this.Controller.BestellungenHolen())
                        {
                            if (bestellung.Erledigt)
                            {
                                this._Bestellungen.Add(bestellung);
                            }
                        }
                    }

                }
                return this._Bestellungen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buch _AktuellesBuch = null;

        /// <summary>
        /// Ruft das aktuelle Buch der Bestellung ab.
        /// </summary>
        public Daten.Buch AktuellesBuch
        {
            get
            {
                if (this._AktuellesBuch == null)
                {
                    this._AktuellesBuch = new Daten.Buch();
                }

                return this._AktuellesBuch;
            }
            set
            {
                if (this._AktuellesBuch != value)
                {
                    this._AktuellesBuch = value;
                    this.OnPropertyChanged();
                    this._BuchBearbeitenLäuft = false;
                    this.OnPropertyChanged("BuchBearbeitenLäuft");

                    if (this._AktuellesBuch.Nr != null)
                    {
                        this._BuchAnlegenLäuft = false;
                        this.OnPropertyChanged("BuchAnlegenLäuft");
                    }
                }
            }
        }


        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Kunde _AktuellerKunde = null;

        /// <summary>
        /// Ruft den aktuellen Kunden ab oder legt ihn fest.
        /// </summary>
        public Daten.Kunde AktuellerKunde
        {
            get
            {
                if (this._AktuellerKunde == null)
                {
                    this._AktuellerKunde = new Daten.Kunde();
                }
                return this._AktuellerKunde;
            }
            set
            {
                if (this._AktuellerKunde != value)
                {
                    this._AktuellerKunde = value;
                    this.OnPropertyChanged();
                    this._KundeBearbeitenLäuft = false;
                    this.OnPropertyChanged("KundeBearbeitenLäuft");
                    this._BestellungBearbeitenLäuft = false;
                    this.OnPropertyChanged("BestellungBearbeitenLäuft");
                    this._BestellungAnlegenLäuft = false;
                    this.OnPropertyChanged("BestellungAnlegenLäuft");

                    if (this._AktuellerKunde.Nr != null)
                    {
                        this._KundeAnlegenLäuft = false;
                        this.OnPropertyChanged("KundeAnlegenLäuft");
                        this._KundeBestellungen = null;
                        this.OnPropertyChanged("KundeBestellungen");
                    }
                    if (this._AktuellerKunde.Nr == null)
                    {
                        this._AktuelleBestellung = null;
                        this.OnPropertyChanged("AktuelleBestellung");
                    }
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob der Kunde 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool KundeSpeichernLäuft
        {
            get
            {
                return this._KundeSpeichernLäuft;
            }
            set
            {
                this._KundeSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeSpeichern
        {
            get
            {
                if (this._KundeSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeSpeichernLäuft = true;

                            if (this.KundeAnlegenLäuft)
                            {
                                this.Controller.KundeSpeichern(this.AktuellerKunde);
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                                // Neu angelegter Kunde wird vorausgewählt
                                this.AktuellerKunde = (from k in this.Kunden orderby k.Nr select k).LastOrDefault();
                                this.OnPropertyChanged("AktuellerKunde");
                                this._KundeAnlegenLäuft = false;
                                this.OnPropertyChanged("KundeAnlegenLäuft");
                            }

                            if (this.KundeBearbeitenLäuft)
                            {
                                this.Controller.KundeBearbeiten(this.AktuellerKunde);
                                var BearbeiteterKunde = this.AktuellerKunde.Nr;
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                                this._KundeBearbeitenLäuft = false;
                                // Bearbeiteter Kunde wird vorausgewählt
                                this._AktuellerKunde = (from k in this.Kunden where k.Nr == BearbeiteterKunde select k).LastOrDefault();
                                this.OnPropertyChanged("AktuellerKunde");
                                this.OnPropertyChanged("KundeBearbeitenLäuft");
                            }

                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }, data => this.KundeAnlegenLäuft || this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeAnlegenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Kundenanlage läuft, oder legt ihn fest.
        /// </summary>
        public bool KundeAnlegenLäuft
        {
            get
            {
                return this._KundeAnlegenLäuft;
            }
            set
            {
                this._KundeAnlegenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeAnlegen = null;

        /// <summary>
        /// Ruft den Befehl zum Anlegen eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeAnlegen
        {
            get
            {
                if (this._KundeAnlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeAnlegen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeAnlegenLäuft = true;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._AktuellerKunde = null;
                            this.OnPropertyChanged("AktuellerKunde");
                            this._AktuelleBestellung = null;
                            this.OnPropertyChanged("AktuelleBestellung");
                            this._Kunden = null;
                            this.OnPropertyChanged("Kunden");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                        , data => !this.KundeAnlegenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeAnlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeBearbeitenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Kundenbearbeitung läuft, oder legt ihn fest.
        /// </summary>
        public bool KundeBearbeitenLäuft
        {
            get
            {
                return this._KundeBearbeitenLäuft;
            }
            set
            {
                this._KundeBearbeitenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeBearbeiten = null;

        /// <summary>
        /// Ruft den Befehl zum Bearbeiten eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeBearbeiten
        {
            get
            {
                if (this._KundeBearbeiten == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeBearbeiten = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeBearbeitenLäuft = true;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellerKunde != null && this.AktuellerKunde.Nr != null && !this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeBearbeiten;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeLöschen = null;

        /// <summary>
        /// Ruft den Befehl zum Löschen des Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeLöschen
        {
            get
            {
                if (this._KundeLöschen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeLöschen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var Frage = System.Windows.MessageBox.Show(
                                            "Soll der Kunde wirklich gelöscht werden?",
                                            "Kunden löschen",
                                            System.Windows.MessageBoxButton.YesNo,
                                            System.Windows.MessageBoxImage.Warning);
                            if (Frage == System.Windows.MessageBoxResult.Yes)
                            {
                                this.Controller.KundeLöschen(this.AktuellerKunde);

                                this.AktuellerKunde = null;
                                this.OnPropertyChanged("AktuellerKunde");
                                this._AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                            }

                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellerKunde!= null && this.AktuellerKunde.Nr != null);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeLöschen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeAbbrechen = null;

        /// <summary>
        /// Ruft den Befehl zum Abbrechen der Kundenaktion ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeAbbrechen
        {
            get
            {
                if (this._KundeAbbrechen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeAbbrechen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.KundeSpeichernLäuft = false;
                            this.OnPropertyChanged("KundeSpeichernLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            //this._AktuelleBestellung = null;
                            //this.OnPropertyChanged("AktuelleBestellung");
                            //this._Kunden = null;
                            //this.OnPropertyChanged("Kunden");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.KundeAnlegenLäuft || this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeAbbrechen;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellungen _KundeBestellungen = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen des Kunden ab.
        /// </summary>
        public Daten.Bestellungen KundeBestellungen
        {
            get
            {
                if (this._KundeBestellungen == null && this._AktuellerKunde.Nr != null)
                {
                    this._KundeBestellungen = this.KundeBestellungenHolen(this.AktuellerKunde);
                }
                return this._KundeBestellungen;
            }
        }

        /// <summary>
        /// Holt die Bestellungen eines Kunden
        /// </summary>
        /// <param name="kunde">Kunde, von dem die Bestellungen geholt werden sollen.</param>
        /// <returns></returns>
        private Daten.Bestellungen KundeBestellungenHolen(Daten.Kunde kunde)
        {

            this._KundeBestellungen = new Daten.Bestellungen();

            if (this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
            {
                this._KundeBestellungen = this.Controller.KundeBestellungenHolen(kunde);
            }

            if (this.OffeneBestellungenAnzeigen && !this.ErledigteBestellungenAnzeigen)
            {
                foreach (Daten.Bestellung bestellung in this.Controller.KundeBestellungenHolen(kunde))
                {
                    if (!bestellung.Erledigt)
                    {
                        this._KundeBestellungen.Add(bestellung);
                    }
                }
            }

            if (!this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
            {
                foreach (Daten.Bestellung bestellung in this.Controller.KundeBestellungenHolen(kunde))
                {
                    if (bestellung.Erledigt)
                    {
                        this._KundeBestellungen.Add(bestellung);
                    }
                }
            }

            return this._KundeBestellungen;
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _OffeneBestellungenAnzeigen = true;

        /// <summary>
        /// Gibt einen Wahrheitswert an, ob offene Kundenbestellungen 
        /// angezeigt werden sollen, oder legt ihn fest.
        /// </summary>
        public bool OffeneBestellungenAnzeigen
        {
            get
            {
                return this._OffeneBestellungenAnzeigen;
            }
            set
            {
                this._OffeneBestellungenAnzeigen = value;
                this.OnPropertyChanged();
                this._KundeBestellungen = null;
                this.OnPropertyChanged("KundeBestellungen");
                this._Bestellungen = null;
                this.OnPropertyChanged("Bestellungen");
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _ErledigteBestellungenAnzeigen = false;

        /// <summary>
        /// Gibt einen Wahrheitswert an, ob erledigte Kundenbestellungen 
        /// angezeigt werden sollen, oder legt ihn fest.
        /// </summary>
        public bool ErledigteBestellungenAnzeigen
        {
            get
            {
                return this._ErledigteBestellungenAnzeigen;
            }
            set
            {
                this._ErledigteBestellungenAnzeigen = value;
                this.OnPropertyChanged();
                this._KundeBestellungen = null;
                this.OnPropertyChanged("KundeBestellungen");
                this._Bestellungen = null;
                this.OnPropertyChanged("Bestellungen");
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellung _AktuelleBestellung = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen des Kunden ab.
        /// </summary>
        public Daten.Bestellung AktuelleBestellung
        {
            get
            {
                if (this._AktuelleBestellung == null)
                {
                    this._AktuelleBestellung = new Daten.Bestellung();
                }
                return this._AktuelleBestellung;
            }

            set
            {
                if (this._AktuelleBestellung != value)
                {
                    this._AktuelleBestellung = value;
                    this.OnPropertyChanged();
                    this._AktuellesBuch = null;
                    this.OnPropertyChanged("AktuellesBuch");
                    this._BestellungBearbeitenLäuft = false;
                    this.OnPropertyChanged("BestellungBearbeitenLäuft");

                    if (this._AktuelleBestellung.Nr != null)
                    {
                        this._BestellungAnlegenLäuft = false;
                        this.OnPropertyChanged("BestellungAnlegenLäuft");
                    }     
                }

                if (this.BestellungAnlegenLäuft && this._AktuelleBestellung.Kunde == null && this.AktuellerKunde != null)
                {
                    this._AktuelleBestellung.Kunde = this.AktuellerKunde;
                    this.OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Bestellung 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool BestellungSpeichernLäuft
        {
            get
            {
                return this._BestellungSpeichernLäuft;
            }
            set
            {
                this._BestellungSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungSpeichern
        {
            get
            {
                if (this._BestellungSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungSpeichernLäuft = true;

                            if (this.BestellungAnlegenLäuft)
                            {

                                this.Controller.BestellungSpeichern(this.AktuelleBestellung);
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                this._Bestellungen = null;
                                this.OnPropertyChanged("Bestellungen");
                                //Neu angelegte Bestellung wird vorausgewählt
                                //this.AktuelleBestellung = (from b in this.KundeBestellungen orderby b.Nr select b).LastOrDefault();
                                this._AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._BestellungAnlegenLäuft = false;
                                this.OnPropertyChanged("BestellungAnlegenLäuft");
                            }

                            if (this.BestellungBearbeitenLäuft)
                            {
                                this.Controller.BestellungBearbeiten(this.AktuelleBestellung);
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                this._Bestellungen = null;
                                this.OnPropertyChanged("Bestellungen");
                                this._BestellungBearbeitenLäuft = false;
                                this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            }

                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BestellungAnlegenLäuft || this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungAnlegenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Bestellungsanlage läuft, oder legt ihn fest.
        /// </summary>
        public bool BestellungAnlegenLäuft
        {
            get
            {
                return this._BestellungAnlegenLäuft;
            }
            set
            {
                this._BestellungAnlegenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungAnlegen = null;

        /// <summary>
        /// Ruft den Befehl zum Anlegen einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungAnlegen
        {
            get
            {
                if (this._BestellungAnlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungAnlegen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungAnlegenLäuft = true;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this.AktuelleBestellung = null;
                            this.OnPropertyChanged("AktuelleBestellung");
                            this._KundeBestellungen = null;
                            this.OnPropertyChanged("KundeBestellungen");
                            this._Bestellungen = null;
                            this.OnPropertyChanged("Bestellungen");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                        , data => !this.BestellungAnlegenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungAnlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungBearbeitenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Bestellungsbearbeitung läuft, oder legt ihn fest.
        /// </summary>
        public bool BestellungBearbeitenLäuft
        {
            get
            {
                return this._BestellungBearbeitenLäuft;
            }
            set
            {
                this._BestellungBearbeitenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungBearbeiten = null;

        /// <summary>
        /// Ruft den Befehl zum Bearbeiten einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungBearbeiten
        {
            get
            {
                if (this._BestellungBearbeiten == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungBearbeiten = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungBearbeitenLäuft = true;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuelleBestellung != null && this.AktuelleBestellung.Nr != null && !this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungBearbeiten;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungLöschen = null;

        /// <summary>
        /// Ruft den Befehl zum Löschen der Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungLöschen
        {
            get
            {
                if (this._BestellungLöschen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungLöschen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var Frage = System.Windows.MessageBox.Show(
                                            "Soll die Bestellung wirklich gelöscht werden?",
                                            "Bestellung löschen",
                                            System.Windows.MessageBoxButton.YesNo,
                                            System.Windows.MessageBoxImage.Warning);
                            if (Frage == System.Windows.MessageBoxResult.Yes)
                            {

                                this.Controller.BestellungLöschen(this.AktuelleBestellung);

                                this.AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                this._Bestellungen = null;
                                this.OnPropertyChanged("Bestellungen");

                            }

                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuelleBestellung != null && this.AktuelleBestellung.Nr != null);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungLöschen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungAbbrechen = null;

        /// <summary>
        /// Ruft den Befehl zum Abbrechen der Bestellaktion ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungAbbrechen
        {
            get
            {
                if (this._BestellungAbbrechen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungAbbrechen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.BestellungSpeichernLäuft = false;
                            this.OnPropertyChanged("BestellungSpeichernLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            if (this.BestellungAnlegenLäuft)
                            {
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                this._Bestellungen = null;
                                this.OnPropertyChanged("Bestellungen");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BestellungAnlegenLäuft || this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungAbbrechen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buchgruppen _Buchgruppen;

        /// <summary>
        /// Ruft die Liste der Buchgruppen ab.
        /// </summary>
        public Daten.Buchgruppen Buchgruppen
        {
            get
            {
                if (this._Buchgruppen == null)
                {
                    this._Buchgruppen = this.Controller.BuchgruppenHolen();
                }
                return this._Buchgruppen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Rabattgruppen _Rabattgruppen;

        /// <summary>
        /// Ruft die Liste der Rabattgruppen ab.
        /// </summary>
        public Daten.Rabattgruppen Rabattgruppen
        {
            get
            {
                if (this._Rabattgruppen == null)
                {
                    this._Rabattgruppen = this.Controller.RabattgruppenHolen();
                }
                return this._Rabattgruppen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchAnlegen = null;

        /// <summary>
        /// Ruft den Befehl zum Anlegen eines Buches ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchAnlegen
        {
            get
            {
                if (this._BuchAnlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchAnlegen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BuchAnlegenLäuft = true;
                            this.OnPropertyChanged("BuchAnlegenLäuft");
                            this._AktuellesBuch = null;
                            this.OnPropertyChanged("AktuellesBuch");
                            this._Bücher = null;
                            this.OnPropertyChanged("Bücher");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                        , data => !this.BuchAnlegenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchAnlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Buches ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchSpeichern
        {
            get
            {
                if (this._BuchSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BuchSpeichernLäuft = true;

                            if (this.BuchAnlegenLäuft)
                            {

                                this.Controller.BuchSpeichern(this.AktuellesBuch);
                                this._Bücher = null;
                                this.OnPropertyChanged("Bücher");
                                this._AktuellesBuch = null;
                                this.OnPropertyChanged("AktuellesBuch");
                                this._BuchAnlegenLäuft = false;
                                this.OnPropertyChanged("BuchAnlegenLäuft");
                            }

                            if (this.BuchBearbeitenLäuft)
                            {
                                this.Controller.BuchBearbeiten(this.AktuellesBuch);
                                this._Bücher = null;
                                this.OnPropertyChanged("Bücher");
                                this._BuchBearbeitenLäuft = false;
                                this.OnPropertyChanged("BuchBearbeitenLäuft");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BuchAnlegenLäuft || this.BuchBearbeitenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchBearbeiten = null;

        /// <summary>
        /// Ruft den Befehl zum Bearbeiten einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchBearbeiten
        {
            get
            {
                if (this._BuchBearbeiten == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchBearbeiten = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BuchBearbeitenLäuft = true;
                            this.OnPropertyChanged("BuchBearbeitenLäuft");
                            this._BuchAnlegenLäuft = false;
                            this.OnPropertyChanged("BuchAnlegenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }                        ,
                        data => this.AktuellesBuch != null && this.AktuellesBuch.Nr != null && !this.BuchBearbeitenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchBearbeiten;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchLöschen = null;

        /// <summary>
        /// Ruft den Befehl zum Löschen des Buches ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchLöschen
        {
            get
            {
                if (this._BuchLöschen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchLöschen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var Frage = System.Windows.MessageBox.Show(
                                            "Soll das Buch wirklich gelöscht werden?",
                                            "Buch löschen",
                                            System.Windows.MessageBoxButton.YesNo,
                                            System.Windows.MessageBoxImage.Warning);
                            if (Frage == System.Windows.MessageBoxResult.Yes)
                            {
                                this.Controller.BuchLöschen(this.AktuellesBuch);

                                this.AktuellesBuch = null;
                                this.OnPropertyChanged("AktuellesBuch");
                                this._Bücher = null;
                                this.OnPropertyChanged("Bücher");
                            }

                            this._BuchAnlegenLäuft = false;
                            this.OnPropertyChanged("BuchAnlegenLäuft");
                            this._BuchBearbeitenLäuft = false;
                            this.OnPropertyChanged("BuchBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellesBuch != null && this.AktuellesBuch.Nr != null);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchLöschen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchAbbrechen = null;

        /// <summary>
        /// Ruft den Befehl zum Abbrechen der Buchaktion ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchAbbrechen
        {
            get
            {
                if (this._BuchAbbrechen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchAbbrechen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.BuchSpeichernLäuft = false;
                            this.OnPropertyChanged("BuchSpeichernLäuft");
                            this._BuchAnlegenLäuft = false;
                            this.OnPropertyChanged("BuchAnlegenLäuft");
                            this._BuchBearbeitenLäuft = false;
                            this.OnPropertyChanged("BuchBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BuchAnlegenLäuft || this.BuchBearbeitenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchAbbrechen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BuchAnlegenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Buchanlage läuft, oder legt ihn fest.
        /// </summary>
        public bool BuchAnlegenLäuft
        {
            get
            {
                return this._BuchAnlegenLäuft;
            }
            set
            {
                this._BuchAnlegenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BuchBearbeitenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Buchbearbeitung läuft, oder legt ihn fest.
        /// </summary>
        public bool BuchBearbeitenLäuft
        {
            get
            {
                return this._BuchBearbeitenLäuft;
            }
            set
            {
                this._BuchBearbeitenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BuchSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob das Buch 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool BuchSpeichernLäuft
        {
            get
            {
                return this._BuchSpeichernLäuft;
            }
            set
            {
                this._BuchSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzZurück = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzZurück
        {
            get
            {
                if (this._DatensatzZurück == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzZurück = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Kunden")
                            {
                                var index = this.Kunden.IndexOf(this.AktuellerKunde);
                                if (index > 0)
                                {
                                    this.AktuellerKunde = (from k in this.Kunden select this.Kunden[index - 1]).FirstOrDefault();
                                }
                                this.OnPropertyChanged("AktuellerKunde");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bestellungen")
                            {
                                var index = this.Bestellungen.IndexOf(this.AktuelleBestellung);
                                if (index > 0)
                                {
                                    this.AktuelleBestellung = (from b in this.Bestellungen select this.Bestellungen[index - 1]).FirstOrDefault();
                                }
                                this.OnPropertyChanged("AktuelleBestellung");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bücher")
                            {
                                var index = this.Bücher.IndexOf(this.AktuellesBuch);
                                if (index > 0)
                                {
                                    this.AktuellesBuch = (from b in this.Bücher select this.Bücher[index - 1]).FirstOrDefault();
                                }
                                this.OnPropertyChanged("AktuellesBuch");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzZurück;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzVorwärts = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des nächsten Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzVorwärts
        {
            get
            {
                if (this._DatensatzVorwärts == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzVorwärts = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Kunden")
                            {
                                var index = this.Kunden.IndexOf(this.AktuellerKunde);
                                if (index < this.Kunden.Count - 1)
                                {
                                    this.AktuellerKunde = (from k in this.Kunden select this.Kunden[index + 1]).FirstOrDefault();
                                };
                                this.OnPropertyChanged("AktuellerKunde");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bestellungen")
                            {
                                var index = this.Bestellungen.IndexOf(this.AktuelleBestellung);
                                if (index < this.Bestellungen.Count - 1)
                                {
                                    this.AktuelleBestellung = (from b in this.Bestellungen select this.Bestellungen[index + 1]).FirstOrDefault();
                                };
                                this.OnPropertyChanged("AktuelleBestellung");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bücher")
                            {
                                var index = this.Bücher.IndexOf(this.AktuellesBuch);
                                if (index < this.Bücher.Count - 1)
                                {
                                    this.AktuellesBuch = (from b in this.Bücher select this.Bücher[index + 1]).FirstOrDefault();
                                };
                                this.OnPropertyChanged("AktuellesBuch");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzVorwärts;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzErster = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzErster
        {
            get
            {
                if (this._DatensatzErster == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzErster = new WIFI.Windows.Befehl(
                        data =>
                        {
                        this.Besitzer.AktiviereBeschäftigt();

                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Kunden")
                            {
                                this.AktuellerKunde = this.Kunden.FirstOrDefault();
                                this.OnPropertyChanged("AktuellerKunde");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bestellungen")
                            {
                                this.AktuelleBestellung = this.Bestellungen.FirstOrDefault();
                                this.OnPropertyChanged("AktuelleBestellung");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bücher")
                            {
                                this.AktuellesBuch = this.Bücher.FirstOrDefault();
                                this.OnPropertyChanged("AktuellesBuch");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzErster;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzLetzter = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzLetzter
        {
            get
            {
                if (this._DatensatzLetzter == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzLetzter = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Kunden")
                            {
                                this.AktuellerKunde = this.Kunden.LastOrDefault();
                                this.OnPropertyChanged("AktuellerKunde");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bestellungen")
                            {
                                this.AktuelleBestellung = this.Bestellungen.LastOrDefault();
                                this.OnPropertyChanged("AktuelleBestellung");
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.Name == "Bücher")
                            {
                                this.AktuellesBuch = this.Bücher.LastOrDefault();
                                this.OnPropertyChanged("AktuellesBuch");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzLetzter;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DruckBestellerinnerung = null;

        /// <summary>
        /// Ruft den Befehl zum Drucken einer Bestellerinnerung ab.
        /// </summary>
        public WIFI.Windows.Befehl DruckBestellerinnerung
        {
            get
            {
                if (this._DruckBestellerinnerung == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DruckBestellerinnerung = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            // FlowDocument erstellen.  
                            FlowDocument Bestellerinnerung = DruckBestellerinnerungErstellen(this.AktuellerKunde);

                            // Flowdocument in Fixeddocument umwandeln
                            FixedDocument BestellerinnerungFixedDocument = this.FlowDocumentZuFixedDocumentKonvertieren(Bestellerinnerung);

                            // Druckvorschau
                            this.DruckvorschauErstellen(BestellerinnerungFixedDocument);

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DruckBestellerinnerung;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DruckBestellerinnerungen = null;

        /// <summary>
        /// Ruft den Befehl zum Drucken der Bestellerinnerungen ab.
        /// </summary>
        public WIFI.Windows.Befehl DruckBestellerinnerungen
        {
            get
            {
                if (this._DruckBestellerinnerungen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DruckBestellerinnerungen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            // FlowDocument erstellen.  
                            FlowDocument Bestellerinnerungen = this.DruckBestellerinnerungenErstellen();

                            // Flowdocument in Fixeddocument umwandeln
                            FixedDocument BestellerinnerungenFixedDocument = this.FlowDocumentZuFixedDocumentKonvertieren(Bestellerinnerungen);

                            // Druckvorschau
                            this.DruckvorschauErstellen(BestellerinnerungenFixedDocument);

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DruckBestellerinnerungen;
            }
        }

        private void DruckvorschauErstellen (FixedDocument fixedDocument)
        {
            var xps = new XpsDocument("Druckvorschau.xps", System.IO.FileAccess.Write, System.IO.Packaging.CompressionOption.Maximum);
            var writer = XpsDocument.CreateXpsDocumentWriter(xps);
            writer.Write(fixedDocument);
            
            var Druckvorschau = new Druckvorschau();
            MyDocumentViewer Vorschau = LogicalTreeHelper.FindLogicalNode(Druckvorschau, "Vorschau") as MyDocumentViewer;
            Vorschau.Document = fixedDocument as IDocumentPaginatorSource;
            Druckvorschau.ShowDialog();

            xps.Close();
            System.IO.File.Delete("Druckvorschau.xps");
        }

        private FixedDocument FlowDocumentZuFixedDocumentKonvertieren(FlowDocument flowDocument)
        {
            var paginator = ((IDocumentPaginatorSource)flowDocument).DocumentPaginator;
            var package = System.IO.Packaging.Package.Open(new System.IO.MemoryStream(), System.IO.FileMode.Create, System.IO.FileAccess.ReadWrite);
            var packUri = new Uri("pack://temp.xps");
            System.IO.Packaging.PackageStore.RemovePackage(packUri);
            System.IO.Packaging.PackageStore.AddPackage(packUri, package);
            var xps = new XpsDocument(package, System.IO.Packaging.CompressionOption.NotCompressed, packUri.ToString());
            XpsDocument.CreateXpsDocumentWriter(xps).Write(paginator);
            FixedDocument fixedDocument = xps.GetFixedDocumentSequence().References[0].GetDocument(true);
            return fixedDocument;
        }

        /// <summary>  
        /// Erstellt die Bestellerinnerung eines Kunden.
        /// </summary>  
        /// <returns></returns>  
        private FlowDocument DruckBestellerinnerungErstellen(Daten.Kunde kunde)
        {
            // Flowdocument erstellen  
            FlowDocument Bestellerinnerung = new FlowDocument();
            Bestellerinnerung.Name = "Bestellerinnerung";
            Bestellerinnerung.ColumnWidth = 800;

            // Überschrift  
            Paragraph Überschrift = new Paragraph();
            Überschrift.FontSize = 26;
            Bold bld = new Bold();
            bld.Inlines.Add(new Run("Bestellerinnerung"));
            Italic italicBld = new Italic();
            italicBld.Inlines.Add(bld);
            Underline underlineItalicBld = new Underline();
            underlineItalicBld.Inlines.Add(italicBld);
            Überschrift.Inlines.Add(underlineItalicBld);

            // Druckdatum hinzufügen
            Paragraph Druckdatum = new Paragraph();
            Druckdatum.Inlines.Add("vom " + DateTime.Now.ToString() + "\n");

            // Anschrift
            Paragraph Anschrift = new Paragraph();
            Anschrift.FontSize = 20;
            Anschrift.Inlines.Add(new Run(kunde.KompletterName + "\n"
                                            + kunde.Straße + "\n"
                                            + kunde.PLZ + " "
                                            + kunde.Ort + "\n"));

            // Bestellungen
            Table Bestellungen = new Table();

            // Spalten erstellen
            int AnzahlDerSpalten = 7;
            for (int x = 0; x < AnzahlDerSpalten; x++)
            {
                Bestellungen.Columns.Add(new TableColumn());
            }
            Bestellungen.Columns[0].Width = new GridLength(90);
            Bestellungen.Columns[1].Width = new GridLength(120);
            Bestellungen.Columns[2].Width = new GridLength(90);
            Bestellungen.Columns[3].Width = new GridLength(220);
            Bestellungen.Columns[4].Width = new GridLength(70);
            Bestellungen.Columns[5].Width = new GridLength(70);
            Bestellungen.Columns[6].Width = new GridLength(70);

            // Reihengruppe erstellen
            Bestellungen.RowGroups.Add(new TableRowGroup());

            // Kundenbestellungen holen
            var KundenBestellungen = this.KundeBestellungenHolen(kunde);

            // Reihen erstellen (Anzahl der Bestellungen + Kopf- und Fußzeile)
            int AnzahlDerReihen = KundenBestellungen.Count + 2;
            for (int x = 0; x < AnzahlDerReihen; x++)
            {
                Bestellungen.RowGroups[0].Rows.Add(new TableRow());
            }

            TableRow currentRow = Bestellungen.RowGroups[0].Rows[0];

            // Formatierung der Beschriftungsreihe.
            currentRow.Background = Brushes.LightGray;
            currentRow.FontSize = 14;
            currentRow.FontWeight = FontWeights.Bold;

            // Zellen der Beschriftungsreihe hinzufügen.
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("BestellNr"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Bestelldatum"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("BuchNr"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Titel"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Anzahl"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Lieferbar"))));
            currentRow.Cells.Add(new TableCell(new Paragraph(new Run("Erledigt"))));

            // Reihen der Bestellungen.
            currentRow.FontSize = 14;
            currentRow.FontWeight = FontWeights.Normal;

            int aktuelleReihe = 1;

            foreach (Daten.Bestellung bestellung in KundenBestellungen)
            {
                currentRow = Bestellungen.RowGroups[0].Rows[aktuelleReihe];

                // Bestellungen hinzufügen.
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Nr.ToString()))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Bestelldatum.ToShortDateString()))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Buch.BuchNr))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Buch.Titel))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Anzahl.ToString()))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Lieferbar ? "ja" : "nein"))));
                currentRow.Cells.Add(new TableCell(new Paragraph(new Run(bestellung.Erledigt ? "ja" : "nein"))));
                aktuelleReihe++;
            }

            // Reihe für die Anzahl der Bestellungen.
            currentRow = Bestellungen.RowGroups[0].Rows.LastOrDefault();
            currentRow.Background = Brushes.LightGray;
            currentRow.FontSize = 14;
            currentRow.FontWeight = System.Windows.FontWeights.Normal;

            currentRow.Cells.Add(new TableCell(new Paragraph(new Run(KundenBestellungen.Count + " Bestellungen"))));
            currentRow.Cells[0].ColumnSpan = 6;


            // Blocks hinzufügen  
            Bestellerinnerung.Blocks.Add(Überschrift);
            Bestellerinnerung.Blocks.Add(Druckdatum);
            Bestellerinnerung.Blocks.Add(Anschrift);
            Bestellerinnerung.Blocks.Add(Bestellungen);
            Bestellerinnerung.Blocks.Add(new BlockUIContainer(new Separator()));

            return Bestellerinnerung;
        }

        /// <summary>  
        /// Erstellt Bestellerinnerungen aller Kunden.
        /// </summary>  
        /// <returns></returns>  
        private FlowDocument DruckBestellerinnerungenErstellen()
        {

            // Flowdocument für alle Bestellerinnerungen erstellen  
            FlowDocument Bestellerinnerungen = new FlowDocument();
            Bestellerinnerungen.Name = "Bestellerinnerungen";
            Bestellerinnerungen.ColumnWidth = 800;

            int i = 0;
            foreach (Daten.Kunde kunde in this.Kunden)
            {
                // einzelne Bestellerinnerung erstellen
                var Bestellerinnerung = this.DruckBestellerinnerungErstellen(kunde);

                // Blocks der Bestellerinnerung in gesamte Bestellerinnerungen umfüllen
                List<Block> BestellerinnerungBlocks = new List<Block>(Bestellerinnerung.Blocks);
                foreach (Block block in BestellerinnerungBlocks)
                {
                    Bestellerinnerungen.Blocks.Add(block);

                }

                // Seitenumbruch
                var AnzahlBestellungen = this.KundeBestellungenHolen(kunde).Count;
                if (i % 2 != 0 || AnzahlBestellungen > 8)
                {
                    if (this.Kunden.IndexOf(kunde) >= AnzahlBestellungen - 1)
                    {
                        
                    }
                    else
                    {
                        Paragraph Seitenumbruch = new Paragraph();
                        Seitenumbruch.BreakPageBefore = true;
                        Bestellerinnerungen.Blocks.Add(Seitenumbruch);
                        if (AnzahlBestellungen > 8) { i++; }
                    }
                }

                i++;
            }

            return Bestellerinnerungen;
        }

        /// <summary>

        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _Drucken = null;

        /// <summary>
        /// Ruft den Befehl zum Drucken der aktuellen View ab.
        /// </summary>
        public WIFI.Windows.Befehl Drucken
        {
            get
            {
                if (this._Drucken == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._Drucken = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            string path = "test.xps";

                            System.IO.Packaging.Package package = System.IO.Packaging.Package.Open(path, System.IO.FileMode.Create);
                            System.Windows.Xps.Packaging.XpsDocument document = new System.Windows.Xps.Packaging.XpsDocument(package);
                            System.Windows.Xps.XpsDocumentWriter writer = System.Windows.Xps.Packaging.XpsDocument.CreateXpsDocumentWriter(document);
                            FixedDocument doc = new FixedDocument();

                            FixedPage page1 = new FixedPage();
                            PageContent page1Content = new PageContent();
                            ((System.Windows.Markup.IAddChild)page1Content).AddChild(page1);

                            // Viewer in Fixeddocument laden
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.GetType() == typeof(KundenViewer))
                            {
                                var viewer = new KundenViewer();
                                viewer.DataContext = this;
                                viewer.IsEnabled = false;
                                page1.Children.Add(viewer);
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.GetType() == typeof(BestellungenViewer))
                            {
                                var viewer = new BestellungenViewer();
                                viewer.DataContext = this;
                                viewer.IsEnabled = false;
                                page1.Children.Add(viewer);
                            }
                            if (this.Besitzer.AktuelleAufgabe.Arbeitsbereich.GetType() == typeof(BücherViewer))
                            {
                                var viewer = new BücherViewer();
                                viewer.DataContext = this;
                                viewer.IsEnabled = false;
                                page1.Children.Add(viewer);
                            }

                            doc.Pages.Add(page1Content);

                            writer.Write(doc);
                            
                            document.Close();
                            package.Close();

                            this.DruckvorschauErstellen(doc);

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._Drucken;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.BuchBestellungen _BuchBestellungen = null;

        /// <summary>
        /// Ruft die Anzahl der Buchbestellungen ab oder legt sie fest.
        /// </summary>
        public Daten.BuchBestellungen BuchBestellungen
        {
            get
            {
                if (this._BuchBestellungen == null)
                {
                    this._BuchBestellungen = this.Controller.BuchBestellungenHolen();
                }
                return this._BuchBestellungen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DruckBuchBestellungen = null;

        /// <summary>
        /// Ruft den Befehl zum Drucken der Buchbestellungen ab.
        /// </summary>
        public WIFI.Windows.Befehl DruckBuchBestellungen
        {
            get
            {
                if (this._DruckBuchBestellungen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DruckBuchBestellungen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BuchBestellungen = this.Controller.BuchBestellungenHolen();
                            this.DruckBuchBestellungenErstellen();

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DruckBuchBestellungen;
            }
        }

        /// <summary>  
        /// Erstellt einen Gesamtdruck der Buchbestellungen.
        /// </summary>  
        /// <returns></returns>  
        private void DruckBuchBestellungenErstellen()
        {

            // Druckdialog
            PrintDialog pd = new PrintDialog();

            FixedDocument BuchBestellungen = new FixedDocument();
            BuchBestellungen.Name = "Buchbestellungen";
            BuchBestellungen.DocumentPaginator.PageSize = new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            foreach (Daten.Buchgruppe buchgruppe in this.Buchgruppen)
            {

                // Buchbestellungen der Buchgruppe holen
                Daten.BuchBestellungen BuchgruppeBestellungen = new Daten.BuchBestellungen();
                foreach (Daten.BuchBestellung buchbestellung in this.BuchBestellungen)
                {
                    var Buch = (from b in this.Bücher where b.Nr == buchbestellung.Buch select b).FirstOrDefault();

                    if (Buch.Buchgruppe.Nr == buchgruppe.Nr)
                    {
                        BuchgruppeBestellungen.Add(buchbestellung);
                    }
                }

                if (BuchgruppeBestellungen.Count > 0)
                {
                    var Seite = this.DruckBuchgruppeBestellungenErstellen(pd, buchgruppe, BuchgruppeBestellungen);

                    PageContent Seiteninhalt = new PageContent();
                    ((System.Windows.Markup.IAddChild)Seiteninhalt).AddChild(Seite);
                    BuchBestellungen.Pages.Add(Seiteninhalt);
                }

            }

            // Druckvorschau
            this.DruckvorschauErstellen(BuchBestellungen);

        }

        /// <summary>  
        /// Erstellt eine Druckseite mit den Bestellungen einer Buchgruppe.
        /// </summary>  
        /// <returns></returns>  
        private FixedPage DruckBuchgruppeBestellungenErstellen(PrintDialog pd, Daten.Buchgruppe buchgruppe, Daten.BuchBestellungen buchgruppeBestellungen)
        {

            // Seite erstellen
            FixedPage Seite = new FixedPage();

            // Querformat
            Seite.Height = pd.PrintableAreaWidth;
            Seite.Width = pd.PrintableAreaHeight;

            // Kopfzeile
            TextBlock Kopfzeile = new TextBlock();
            Kopfzeile.Text = "Buchausstellung 2019, Gemeinde XYZ";
            FixedPage.SetTop(Kopfzeile, 50.0);
            Kopfzeile.FontSize = 28;
            Kopfzeile.Width = pd.PrintableAreaWidth;
            Kopfzeile.TextAlignment = TextAlignment.Center;
            Kopfzeile.FontWeight = FontWeights.Bold;
            Seite.Children.Add(Kopfzeile);

            // Buchgruppe
            TextBlock Buchgruppe = new TextBlock();
            Buchgruppe.Text = buchgruppe.Bezeichnung;
            FixedPage.SetLeft(Buchgruppe, 80.0);
            FixedPage.SetTop(Buchgruppe, 120.0);
            Buchgruppe.FontSize = 22;
            Buchgruppe.FontWeight = FontWeights.Bold;
            Seite.Children.Add(Buchgruppe);

            // Header Anzahl
            TextBlock HeaderAnzahl = new TextBlock();
            FixedPage.SetLeft(HeaderAnzahl, 80.0);
            FixedPage.SetTop(HeaderAnzahl, 180.0);
            HeaderAnzahl.FontSize = 20;
            HeaderAnzahl.Width = 100;
            HeaderAnzahl.FontWeight = FontWeights.Bold;
            HeaderAnzahl.Text = "Anzahl";
            HeaderAnzahl.TextAlignment = TextAlignment.Center;
            Seite.Children.Add(HeaderAnzahl);

            // Header BuchNr
            TextBlock HeaderBuchNr = new TextBlock();
            FixedPage.SetLeft(HeaderBuchNr, 180.0);
            FixedPage.SetTop(HeaderBuchNr, 180.0);
            HeaderBuchNr.FontSize = 20;
            HeaderBuchNr.Width = 100;
            HeaderBuchNr.FontWeight = FontWeights.Bold;
            HeaderBuchNr.Text = "Nr";
            HeaderBuchNr.TextAlignment = TextAlignment.Center;
            Seite.Children.Add(HeaderBuchNr);

            // Header Titel
            TextBlock HeaderTitel = new TextBlock();
            FixedPage.SetLeft(HeaderTitel, 280.0);
            FixedPage.SetTop(HeaderTitel, 180.0);
            HeaderTitel.FontSize = 20;
            HeaderTitel.FontWeight = FontWeights.Bold;
            HeaderTitel.Text = "Titel";
            Seite.Children.Add(HeaderTitel);

            // Header Autor
            TextBlock HeaderAutor = new TextBlock();
            FixedPage.SetLeft(HeaderAutor, 520.0);
            FixedPage.SetTop(HeaderAutor, 180.0);
            HeaderAutor.FontSize = 20;
            HeaderAutor.FontWeight = FontWeights.Bold;
            HeaderAutor.Text = "Autor";
            Seite.Children.Add(HeaderAutor);

            // Header Verlag
            TextBlock HeaderVerlag = new TextBlock();
            FixedPage.SetLeft(HeaderVerlag, 680.0);
            FixedPage.SetTop(HeaderVerlag, 180.0);
            HeaderVerlag.FontSize = 20;
            HeaderVerlag.FontWeight = FontWeights.Bold;
            HeaderVerlag.Text = "Verlag";
            Seite.Children.Add(HeaderVerlag);

            // Header Preis
            TextBlock HeaderPreis = new TextBlock();
            FixedPage.SetLeft(HeaderPreis, 840.0);
            FixedPage.SetTop(HeaderPreis, 180.0);
            HeaderPreis.FontSize = 20;
            HeaderPreis.Width = 100;
            HeaderPreis.FontWeight = FontWeights.Bold;
            HeaderPreis.Text = "Preis";
            HeaderPreis.TextAlignment = TextAlignment.Center;
            Seite.Children.Add(HeaderPreis);

            // Rabattgruppe
            TextBlock HeaderRabattgruppe = new TextBlock();
            FixedPage.SetLeft(HeaderRabattgruppe, 940.0);
            FixedPage.SetTop(HeaderRabattgruppe, 180.0);
            HeaderRabattgruppe.FontSize = 20;
            HeaderRabattgruppe.Width = 100;
            HeaderRabattgruppe.FontWeight = FontWeights.Bold;
            HeaderRabattgruppe.Text = "Rab.Gr";
            HeaderRabattgruppe.TextAlignment = TextAlignment.Center;
            Seite.Children.Add(HeaderRabattgruppe);

            // Trennlinie
            Separator Linie = new Separator();
            FixedPage.SetLeft(Linie, 80.0);
            Linie.Width = 960;
            FixedPage.SetTop(Linie, 210.0);
            Linie.BorderBrush = Brushes.Black;
            Linie.BorderThickness = new Thickness(1);
            Seite.Children.Add(Linie);

            double TopPosition = 220.0;

            foreach (Daten.BuchBestellung buchbestellung in buchgruppeBestellungen)
            {
                var Buch = (from b in this.Bücher where b.Nr == buchbestellung.Buch select b).FirstOrDefault();

                // Anzahl
                TextBlock Anzahl = new TextBlock();
                FixedPage.SetLeft(Anzahl, 80.0);
                FixedPage.SetTop(Anzahl, TopPosition);
                Anzahl.Width = 100;
                Anzahl.FontSize = 20;
                Anzahl.Text = buchbestellung.Anzahl.ToString();
                Anzahl.TextAlignment = TextAlignment.Center;
                Seite.Children.Add(Anzahl);

                // BuchNr
                TextBlock BuchNr = new TextBlock();
                FixedPage.SetLeft(BuchNr, 180.0);
                FixedPage.SetTop(BuchNr, TopPosition);
                BuchNr.Width = 100;
                BuchNr.FontSize = 20;
                BuchNr.Text = Buch.BuchNr;
                BuchNr.TextAlignment = TextAlignment.Center;
                Seite.Children.Add(BuchNr);

                // Titel
                TextBlock Titel = new TextBlock();
                FixedPage.SetLeft(Titel, 280.0);
                FixedPage.SetTop(Titel, TopPosition);
                Titel.FontSize = 20;
                Titel.Text = Buch.Titel;
                Seite.Children.Add(Titel);

                // Autor
                TextBlock Autor = new TextBlock();
                FixedPage.SetLeft(Autor, 520.0);
                FixedPage.SetTop(Autor, TopPosition);
                Autor.FontSize = 20;
                Autor.Text = Buch.Autor;
                Seite.Children.Add(Autor);

                // Verlag
                TextBlock Verlag = new TextBlock();
                FixedPage.SetLeft(Verlag, 680.0);
                FixedPage.SetTop(Verlag, TopPosition);
                Verlag.FontSize = 20;
                Verlag.Text = Buch.Verlag;
                Seite.Children.Add(Verlag);

                // Preis
                TextBlock Preis = new TextBlock();
                FixedPage.SetLeft(Preis, 840.0);
                FixedPage.SetTop(Preis, TopPosition);
                Preis.Width = 70;
                Preis.FontSize = 20;
                Preis.Text = String.Format("{0:0.00}", Buch.Preis);
                Preis.TextAlignment = TextAlignment.Right;
                Seite.Children.Add(Preis);

                // Rabattgruppe
                TextBlock Rabattgruppe = new TextBlock();
                FixedPage.SetLeft(Rabattgruppe, 940.0);
                FixedPage.SetTop(Rabattgruppe, TopPosition);
                Rabattgruppe.Width = 80;
                Rabattgruppe.FontSize = 20;
                Rabattgruppe.Text = Buch.Rabattgruppe.Nr.ToString();
                Rabattgruppe.TextAlignment = TextAlignment.Center;
                Seite.Children.Add(Rabattgruppe);

                // Positon für nächste Zeile
                TopPosition += 30.0;
            }

            return Seite;
        }

    }
}
