﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.ViewModels
{
    public class BücherManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Daten.Manager.DatenManager _Controller = null;

        /// <summary>
        /// Verwaltet den Büchermanager.
        /// </summary>
        private Daten.Manager.DatenManager Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Daten.Manager.DatenManager>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Büchermanager initialisiert hat,
        /// ab oder legt diesen fest.
        /// </summary>
        public FensterManager Besitzer { get; set; }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bücher _Bücher = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bücher ab.
        /// </summary>
        public Daten.Bücher Bücher
        {
            get
            {
                if (this._Bücher == null)
                {
                    this._Bücher = this.Controller.BücherHolen();
                }
                return this._Bücher;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buchgruppen _BuchgruppenListe;

        /// <summary>
        /// Ruft die Liste der Buchgruppen ab.
        /// </summary>
        public Daten.Buchgruppen BuchgruppenListe
        {
            get
            {
                if (this._BuchgruppenListe == null)
                {
                    this._BuchgruppenListe = this.Controller.BuchgruppenHolen();
                }
                return this._BuchgruppenListe;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Rabattgruppen _RabattgruppenListe;

        /// <summary>
        /// Ruft die Liste der Buchgruppen ab.
        /// </summary>
        public Daten.Rabattgruppen RabattgruppenListe
        {
            get
            {
                if (this._RabattgruppenListe == null)
                {
                    this._RabattgruppenListe = this.Controller.RabattgruppenHolen();
                }
                return this._RabattgruppenListe;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buch _AktuellesBuch = null;

        /// <summary>
        /// Ruft das aktuelle Buch ab oder legt es fest.
        /// </summary>
        public Daten.Buch AktuellesBuch
        {
            get
            {
                return this._AktuellesBuch;
            }
            set
            {
                if (this._AktuellesBuch != value)
                {
                    this._AktuellesBuch = value;
                    this.OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buch _NeuesBuch = null;

        /// <summary>
        /// Ruft das neue Buch ab oder legt es fest.
        /// </summary>
        public Daten.Buch NeuesBuch
        {
            get
            {
                if (this._NeuesBuch == null)
                {
                    this._NeuesBuch = new Daten.Buch();
                }
                return this._NeuesBuch;
            }
            set
            {
                this._NeuesBuch = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BuchSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob das Buch 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool BuchSpeichernLäuft
        {
            get
            {
                return this._BuchSpeichernLäuft;
            }
            set
            {
                this._BuchSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BuchSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Buches ab.
        /// </summary>
        public WIFI.Windows.Befehl BuchSpeichern
        {
            get
            {
                if (this._BuchSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BuchSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BuchSpeichernLäuft = true;

                            this.Controller.BuchSpeichern(this.NeuesBuch);

                            this._Bücher = null;
                            this.OnPropertyChanged("Bücher");
                            this._NeuesBuch = null;
                            this.OnPropertyChanged("NeuesBuch");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BuchSpeichern;
            }
        }

    }
}
