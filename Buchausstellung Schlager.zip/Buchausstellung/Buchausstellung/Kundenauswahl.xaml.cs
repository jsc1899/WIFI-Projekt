﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für Kundenauswahl.xaml
    /// </summary>
    public partial class Kundenauswahl : UserControl
    {
        public Kundenauswahl()
        {
            InitializeComponent();
        }

        public static System.Windows.DependencyProperty KundenOriginalProperty
            = System.Windows.DependencyProperty.Register("KundenOriginal", typeof(CollectionView), typeof(Kundenauswahl));

        public CollectionView KundenOriginal
        {
            get
            {
                return this.GetValue(Kundenauswahl.KundenOriginalProperty) as CollectionView;
            }
            set
            {
                this.SetValue(Kundenauswahl.KundenOriginalProperty, value);
            }
        }

        private void Kundenfilter_KeyUp(object sender, KeyEventArgs e)
        {
            KundenOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Kunden.ItemsSource);

            KundenOriginal.Filter = (kunde) =>
            {
                if (String.IsNullOrEmpty(Kundenfilter.Text))
                {
                    return true;
                }
                else
                {
                    if (((Daten.Kunde)kunde).KompletterName.ToLower().Contains(Kundenfilter.Text.ToLower()))
                    {
                        return true;
                    }
                    else return false;
                }
            };

            KundenOriginal.Refresh();

        }

        private void Kundenfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Kundenfilter.Text = "Damit es keinen Treffer gibt und AktuellerKunde zurückgesetzt wird";
            Kundenfilter_KeyUp(Kundenfilter, null);
            Kundenfilter.Text = string.Empty;
            Kundenfilter_KeyUp(Kundenfilter, null);
        }

        private void Kundenfilter_LostFocus(object sender, RoutedEventArgs e)
        {
            Kundenfilter.Text = string.Empty;
        }
    }
}
