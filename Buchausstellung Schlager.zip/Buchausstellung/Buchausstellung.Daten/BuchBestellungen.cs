﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{

    /// <summary>
    /// Stellt eine Liste mit Buchbestellungen bereit.
    /// </summary>
    public class BuchBestellungen : System.Collections.ObjectModel.ObservableCollection<BuchBestellung>
    {

    }

    /// <summary>
    /// Beschreibt eine Buchbestellung.
    /// </summary>
    public class BuchBestellung
    {
        /// <summary>
        /// Ruft das Buch ab oder legt es fest.
        /// </summary>
        public int Buch { get; set; }

        /// <summary>
        /// Ruft die Anzahl, wie oft das Buch bestellt 
        /// wurde, ab, oder legt sie fest.
        /// </summary>
        public int Anzahl { get; set; }
    }

}
