﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für TestViewer.xaml
    /// </summary>
    public partial class TestBücherViewer : UserControl
    {
        public TestBücherViewer()
        {
            InitializeComponent();
        }

        private void Buchfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BücherOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Buchfilter.ItemsSource);

            BücherOriginal.Filter = (buch) =>
            {
                if (String.IsNullOrEmpty(Buchfilter.Text))
                {
                    Buchfilter.IsDropDownOpen = true;
                    Buchfilter.SelectedItem = null;
                    return true;
                }
                else
                {
                    if (((Daten.Buch)buch).Suchstring.ToLower().Contains(Buchfilter.Text.ToLower()))
                    {
                        Buchfilter.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            BücherOriginal.Refresh();

        }

        private void Buchfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Buchfilter.IsDropDownOpen = true;
        }
    }

}
