﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für TestBestellungenViewer.xaml
    /// </summary>
    public partial class TestBestellungenViewer : UserControl
    {
        public TestBestellungenViewer()
        {
            InitializeComponent();
        }


        private void Bestellungenfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BestellungenOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Bestellungenfilter.ItemsSource);

            BestellungenOriginal.Filter = (bestellung) =>
            {
                if (String.IsNullOrEmpty(Bestellungenfilter.Text))
                {
                    Bestellungenfilter.IsDropDownOpen = true;
                    Bestellungenfilter.SelectedItem = null;
                    return true;
                }
                else
                {
                    if (((Daten.Bestellung)bestellung).Suchstring.ToLower().Contains(Bestellungenfilter.Text.ToLower()))
                    {
                        Bestellungenfilter.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            BestellungenOriginal.Refresh();

        }

        private void Bestellungenfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Bestellungenfilter.IsDropDownOpen = true;
        }

        private void Buchfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BücherOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Buchfilter.ItemsSource);

            BücherOriginal.Filter = (buch) =>
            {
                if (String.IsNullOrEmpty(Buchfilter.Text))
                {
                    Buchfilter.IsDropDownOpen = true;
                    Buchfilter.SelectedItem = null;
                    return true;
                }
                else
                {
                    if (((Daten.Buch)buch).NrUndTitel.ToLower().Contains(Buchfilter.Text.ToLower()))
                    {
                        Buchfilter.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            BücherOriginal.Refresh();

        }

        private void Buchfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Buchfilter.IsDropDownOpen = true;
        }

        private void Kundenfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView KundenOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Kundenfilter.ItemsSource);

            KundenOriginal.Filter = (kunde) =>
            {
                if (String.IsNullOrEmpty(Kundenfilter.Text))
                {
                    Kundenfilter.IsDropDownOpen = true;
                    Kundenfilter.SelectedItem = null;
                    return true;
                }
                else
                {
                    if (((Daten.Kunde)kunde).GesamterName.ToLower().Contains(Kundenfilter.Text.ToLower()))
                    {
                        Kundenfilter.IsDropDownOpen = true;
                        return true;
                    }
                    else return false;
                }
            };

            KundenOriginal.Refresh();

        }

        private void Kundenfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Kundenfilter.IsDropDownOpen = true;
            Kundenfilter.SelectedItem = null;
        }
    }
}
