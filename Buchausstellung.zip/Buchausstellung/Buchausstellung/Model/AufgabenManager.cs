﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Model
{
    /// <summary>
    /// Stellt einen Dienst zum
    /// Verwalten der Anwendungspunkte bereit.
    /// </summary>
    public class AufgabenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgaben _Liste = null;

        /// <summary>
        /// Ruft die Liste mit den unterstützten
        /// Anwendungspunkten ab.
        /// </summary>
        public Model.Aufgaben Liste
        {
            get
            {
                if (this._Liste == null)
                {
                    this._Liste = new Aufgaben();

                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "\u008C",
                        Name = Properties.Texte.MenüpunktBücher,
                        ArbeitsbereichTyp = typeof(BücherViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "@",
                        Name = Properties.Texte.MenüpunktKunden,
                        ArbeitsbereichTyp = typeof(KundenViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "$",
                        Name = Properties.Texte.MenüpunktBestellungen,
                        ArbeitsbereichTyp = typeof(BestellungenViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "4",
                        Name = "Test Bücher",
                        ArbeitsbereichTyp = typeof(TestBücherViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "4",
                        Name = "Test Kunde",
                        ArbeitsbereichTyp = typeof(TestKundenViewer)
                    });
                    this._Liste.Add(new Aufgabe
                    {
                        Symbol = "4",
                        Name = "Test Bestellungen",
                        ArbeitsbereichTyp = typeof(TestBestellungenViewer)
                    });
                }

                return this._Liste;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Model.Aufgabe _MenüpunktProtokoll = null;

        /// <summary>
        /// Ruft den Anwendungspunkt für das Protokoll ab.
        /// </summary>
        public Model.Aufgabe MenüpunktProtokoll
        {
            get
            {
                if (this._MenüpunktProtokoll == null)
                {
                    this._MenüpunktProtokoll = new Aufgabe
                    {
                        Symbol = "3",
                        Name = Properties.Texte.MenüpunktAnwendungsprotokoll,
                        ArbeitsbereichTyp = typeof(ProtokollViewer)
                    };
                }

                return this._MenüpunktProtokoll;
            }
        }

    }
}
