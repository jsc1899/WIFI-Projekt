﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.ViewModels
{
    public class BestellungenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Daten.Manager.DatenManager _Controller = null;

        /// <summary>
        /// Verwaltet den Bestellungenmanager.
        /// </summary>
        private Daten.Manager.DatenManager Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Daten.Manager.DatenManager>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Bestellungenmanager initialisiert hat,
        /// ab oder legt diesen fest.
        /// </summary>
        public FensterManager Besitzer { get; set; }



        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellungen _Bestellungen = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen ab.
        /// </summary>
        public Daten.Bestellungen Bestellungen
        {
            get
            {
                if (this._Bestellungen == null)
                {
                    this._Bestellungen = this.Controller.BestellungenHolen();
                }
                return this._Bestellungen;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bücher _Bücher = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bücher ab.
        /// </summary>
        public Daten.Bücher Bücher
        {
            get
            {
                if (this._Bücher == null)
                {
                    this._Bücher = this.Controller.BücherHolen();
                }
                return this._Bücher;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Kunden _Kunden = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Kunden ab.
        /// </summary>
        public Daten.Kunden Kunden
        {
            get
            {
                if (this._Kunden == null)
                {
                    this._Kunden = this.Controller.KundenHolen();
                }
                return this._Kunden;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Bestellung _AktuelleBestellung = null;

        /// <summary>
        /// Ruft die aktuelle Bestellung ab oder legt sie fest.
        /// </summary>
        public Daten.Bestellung AktuelleBestellung
        {
            get
            {
                return this._AktuelleBestellung;
            }
            set
            {
                if (this._AktuelleBestellung != value)
                {
                    this._AktuelleBestellung = value;
                    this.OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Bestellung _NeueBestellung = null;

        /// <summary>
        /// Ruft die neue Bestellung ab oder legt sie fest.
        /// </summary>
        public Daten.Bestellung NeueBestellung
        {
            get
            {
                if (this._NeueBestellung == null)
                {
                    this._NeueBestellung = new Daten.Bestellung();
                }
                return this._NeueBestellung;
            }
            set
            {
                this._NeueBestellung = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Bestellung 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool BestellungSpeichernLäuft
        {
            get
            {
                return this._BestellungSpeichernLäuft;
            }
            set
            {
                this._BestellungSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungSpeichern
        {
            get
            {
                if (this._BestellungSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungSpeichernLäuft = true;

                            this.Controller.BestellungSpeichern(this.NeueBestellung);

                            this._Bestellungen = null;
                            this.OnPropertyChanged("Bestellungen");
                            this._NeueBestellung = null;
                            this.OnPropertyChanged("NeueBestellung");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungSpeichern;
            }
        }

    }
}
