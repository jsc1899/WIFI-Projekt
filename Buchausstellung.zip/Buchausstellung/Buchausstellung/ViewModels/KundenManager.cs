﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.ViewModels
{
    public class KundenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Daten.Manager.DatenManager _Controller = null;

        /// <summary>
        /// Verwaltet den Kundenmanager.
        /// </summary>
        private Daten.Manager.DatenManager Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Daten.Manager.DatenManager>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Kundenmanager initialisiert hat,
        /// ab oder legt diesen fest.
        /// </summary>
        public FensterManager Besitzer { get; set; }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Kunden _Kunden = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Kunden ab.
        /// </summary>
        public Daten.Kunden Kunden
        {
            get
            {
                if (this._Kunden == null)
                {
                    this._Kunden = this.Controller.KundenHolen();
                }
                return this._Kunden;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bücher _Bücher = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bücher ab.
        /// </summary>
        public Daten.Bücher Bücher
        {
            get
            {
                if (this._Bücher == null)
                {
                    this._Bücher = this.Controller.BücherHolen();
                }
                return this._Bücher;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Buch _AktuellesBuch = null;

        /// <summary>
        /// Ruft das aktuelle Buch der Bestellung ab.
        /// </summary>
        public Daten.Buch AktuellesBuch
        {
            get
            {
                if (this._AktuellesBuch == null && this.AktuelleBestellung != null && this.AktuelleBestellung.Buch != null)
                {
                    //TODO
                    this._AktuellesBuch = (from b in this.Bücher where b.Nr == this.AktuelleBestellung.Buch.Nr select b).FirstOrDefault();
                    //this._AktuellesBuch = this.AktuelleBestellung.Buch;
                }
                return this._AktuellesBuch;
            }
            set
            {
                this._AktuellesBuch = value;
                this.OnPropertyChanged();
                //TODO
                if (this.AktuellesBuch != null && value != null)
                {
                    this.AktuelleBestellung.Buch = (from b in this.Bücher where b.Nr == value.Nr select b).FirstOrDefault();
                    //this.AktuelleBestellung.Buch = this.AktuellesBuch;
                }
            }
        }


        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Kunde _AktuellerKunde = null;

        /// <summary>
        /// Ruft den aktuellen Kunden ab oder legt ihn fest.
        /// </summary>
        public Daten.Kunde AktuellerKunde
        {
            get
            {
                if (this._AktuellerKunde == null)
                {
                    this._AktuellerKunde = new Daten.Kunde();
                }
                return this._AktuellerKunde;
            }
            set
            {
                if (this._AktuellerKunde != value)
                {
                    this._AktuellerKunde = value;
                    this.OnPropertyChanged();
                    this._KundeBearbeitenLäuft = false;
                    this.OnPropertyChanged("KundeBearbeitenLäuft");
                    this._BestellungAnlegenLäuft = false;
                    this.OnPropertyChanged("BestellungAnlegenLäuft");
                    this._BestellungBearbeitenLäuft = false;
                    this.OnPropertyChanged("BestellungBearbeitenLäuft");

                    if (this._AktuellerKunde.Nr != null)
                    {
                        this._KundeAnlegenLäuft = false;
                        this.OnPropertyChanged("KundeAnlegenLäuft");
                        //this._KundeBestellungen = this.Controller.KundeBestellungenHolen(this.AktuellerKunde);
                        this._KundeBestellungen = null;
                        this.OnPropertyChanged("KundeBestellungen");
                    }
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob der Kunde 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool KundeSpeichernLäuft
        {
            get
            {
                return this._KundeSpeichernLäuft;
            }
            set
            {
                this._KundeSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeSpeichern
        {
            get
            {
                if (this._KundeSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeSpeichernLäuft = true;

                            if (this.KundeAnlegenLäuft)
                            {
                                this.Controller.KundeSpeichern(this.AktuellerKunde);
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                                //Aufgrund der fehlenden Eingabeprüfung nicht aktiv...
                                //this.AktuellerKunde = (from k in this.Kunden orderby k.Nr select k).LastOrDefault();
                                this._AktuellerKunde = null;
                                this.OnPropertyChanged("AktuellerKunde");
                                this._KundeAnlegenLäuft = false;
                                this.OnPropertyChanged("KundeAnlegenLäuft");
                            }

                            if (this.KundeBearbeitenLäuft)
                            {
                                this.Controller.KundeBearbeiten(this.AktuellerKunde);
                                this._KundeBearbeitenLäuft = false;
                                this.OnPropertyChanged("KundeBearbeitenLäuft");
                            }

                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.KundeAnlegenLäuft || this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeAnlegenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Kundenanlage läuft, oder legt ihn fest.
        /// </summary>
        public bool KundeAnlegenLäuft
        {
            get
            {
                return this._KundeAnlegenLäuft;
            }
            set
            {
                this._KundeAnlegenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeAnlegen = null;

        /// <summary>
        /// Ruft den Befehl zum Anlegen eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeAnlegen
        {
            get
            {
                if (this._KundeAnlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeAnlegen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeAnlegenLäuft = true;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._AktuellerKunde = null;
                            this.OnPropertyChanged("AktuellerKunde");
                            this._AktuelleBestellung = null;
                            this.OnPropertyChanged("AktuelleBestellung");
                            this._Kunden = null;
                            this.OnPropertyChanged("Kunden");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                        , data => !this.KundeAnlegenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeAnlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeBearbeitenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Kundenbearbeitung läuft, oder legt ihn fest.
        /// </summary>
        public bool KundeBearbeitenLäuft
        {
            get
            {
                return this._KundeBearbeitenLäuft;
            }
            set
            {
                this._KundeBearbeitenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeBearbeiten = null;

        /// <summary>
        /// Ruft den Befehl zum Bearbeiten eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeBearbeiten
        {
            get
            {
                if (this._KundeBearbeiten == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeBearbeiten = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeBearbeitenLäuft = true;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellerKunde != null && this.AktuellerKunde.Nr != null && !this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeBearbeiten;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeLöschen = null;

        /// <summary>
        /// Ruft den Befehl zum Löschen des Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeLöschen
        {
            get
            {
                if (this._KundeLöschen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeLöschen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var Frage = System.Windows.MessageBox.Show(
                                            "Soll der Kunde wirklich gelöscht werden?",
                                            "Kunden löschen",
                                            System.Windows.MessageBoxButton.YesNo,
                                            System.Windows.MessageBoxImage.Warning);
                            if (Frage == System.Windows.MessageBoxResult.Yes)
                            {
                                this.Controller.KundeLöschen(this.AktuellerKunde);

                                this.AktuellerKunde = null;
                                this.OnPropertyChanged("AktuellerKunde");
                                this._AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                            }

                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuellerKunde!= null && this.AktuellerKunde.Nr != null);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeLöschen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeAbbrechen = null;

        /// <summary>
        /// Ruft den Befehl zum Abbrechen der Kundenaktion ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeAbbrechen
        {
            get
            {
                if (this._KundeAbbrechen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeAbbrechen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.KundeSpeichernLäuft = false;
                            this.OnPropertyChanged("KundeSpeichernLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");

                            if (this.KundeAnlegenLäuft)
                            {
                                this._Kunden = null;
                                this.OnPropertyChanged("Kunden");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.KundeAnlegenLäuft || this.KundeBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeAbbrechen;
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellungen _KundeBestellungen = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen des Kunden ab.
        /// </summary>
        public Daten.Bestellungen KundeBestellungen
        {
            get
            {
                if (this._KundeBestellungen == null && this._AktuellerKunde.Nr != null)
                {
                    this._KundeBestellungen = new Daten.Bestellungen();

                    if (this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
                    {
                        this._KundeBestellungen = this.Controller.KundeBestellungenHolen(this.AktuellerKunde);
                    }

                    if (this.OffeneBestellungenAnzeigen && !this.ErledigteBestellungenAnzeigen)
                    {
                        foreach (Daten.Bestellung bestellung in this.Controller.KundeBestellungenHolen(this.AktuellerKunde))
                        {
                            if (!bestellung.Erledigt)
                            {
                                this._KundeBestellungen.Add(bestellung);
                            }
                        }
                    }

                    if (!this.OffeneBestellungenAnzeigen && this.ErledigteBestellungenAnzeigen)
                    {
                        foreach (Daten.Bestellung bestellung in this.Controller.KundeBestellungenHolen(this.AktuellerKunde))
                        {
                            if (bestellung.Erledigt)
                            {
                                this._KundeBestellungen.Add(bestellung);
                            }
                        }
                    }

                }
                return this._KundeBestellungen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _OffeneBestellungenAnzeigen = true;

        /// <summary>
        /// Gibt einen Wahrheitswert an, ob offene Kundenbestellungen 
        /// angezeigt werden sollen, oder legt ihn fest.
        /// </summary>
        public bool OffeneBestellungenAnzeigen
        {
            get
            {
                return this._OffeneBestellungenAnzeigen;
            }
            set
            {
                this._OffeneBestellungenAnzeigen = value;
                this.OnPropertyChanged();
                this._KundeBestellungen = null;
                this.OnPropertyChanged("KundeBestellungen");
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _ErledigteBestellungenAnzeigen = false;

        /// <summary>
        /// Gibt einen Wahrheitswert an, ob erledigte Kundenbestellungen 
        /// angezeigt werden sollen, oder legt ihn fest.
        /// </summary>
        public bool ErledigteBestellungenAnzeigen
        {
            get
            {
                return this._ErledigteBestellungenAnzeigen;
            }
            set
            {
                this._ErledigteBestellungenAnzeigen = value;
                this.OnPropertyChanged();
                this._KundeBestellungen = null;
                this.OnPropertyChanged("KundeBestellungen");
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellung _AktuelleBestellung = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen des Kunden ab.
        /// </summary>
        public Daten.Bestellung AktuelleBestellung
        {
            get
            {
                if (this._AktuelleBestellung == null)
                {
                    this._AktuelleBestellung = new Daten.Bestellung();
                }
                return this._AktuelleBestellung;
            }

            set
            {
                if (this._AktuelleBestellung != value)
                {
                    this._AktuelleBestellung = value;
                    this.OnPropertyChanged();
                    this._AktuellesBuch = null;
                    this.OnPropertyChanged("AktuellesBuch");
                    this._BestellungBearbeitenLäuft = false;
                    this.OnPropertyChanged("BestellungBearbeitenLäuft");

                    if (this._AktuelleBestellung.Nr != null)
                    {
                        this._BestellungAnlegenLäuft = false;
                        this.OnPropertyChanged("BestellungAnlegenLäuft");
                    }     
                }

                if (this.BestellungAnlegenLäuft && this._AktuelleBestellung.Kunde == null && this.AktuellerKunde != null)
                {
                    this._AktuelleBestellung.Kunde = this.AktuellerKunde;
                }
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeBestellungenHolenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Bestellungen 
        /// eines Kunden abgeholt werden, oder legt ihn fest.
        /// </summary>
        public bool KundeBestellungenHolenLäuft
        {
            get
            {
                return this._KundeBestellungenHolenLäuft;
            }
            set
            {
                this._KundeBestellungenHolenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeBestellungenHolen = null;

        /// <summary>
        /// Ruft den Befehl zum Holen der Bestellungen eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeBestellungenHolen
        {
            get
            {
                if (this._KundeBestellungenHolen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeBestellungenHolen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeBestellungenHolenLäuft = true;

                            this._KundeBestellungen = this.Controller.KundeBestellungenHolen(this.AktuellerKunde);
                            this.OnPropertyChanged("KundeBestellungen");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeBestellungenHolen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Bestellung 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool BestellungSpeichernLäuft
        {
            get
            {
                return this._BestellungSpeichernLäuft;
            }
            set
            {
                this._BestellungSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungSpeichern
        {
            get
            {
                if (this._BestellungSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungSpeichernLäuft = true;

                            if (this.BestellungAnlegenLäuft)
                            {

                                this.Controller.BestellungSpeichern(this.AktuelleBestellung);
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                //Aufgrund der fehlenden Eingabeprüfung nicht aktiv...
                                //this.AktuelleBestellung = (from b in this.KundeBestellungen orderby b.Nr select b).LastOrDefault();
                                this._AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._BestellungAnlegenLäuft = false;
                                this.OnPropertyChanged("BestellungAnlegenLäuft");
                            }

                            if (this.BestellungBearbeitenLäuft)
                            {
                                this.Controller.BestellungBearbeiten(this.AktuelleBestellung);
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                                this._BestellungBearbeitenLäuft = false;
                                this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            }

                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BestellungAnlegenLäuft || this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungAnlegenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Bestellungsanlage läuft, oder legt ihn fest.
        /// </summary>
        public bool BestellungAnlegenLäuft
        {
            get
            {
                return this._BestellungAnlegenLäuft;
            }
            set
            {
                this._BestellungAnlegenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungAnlegen = null;

        /// <summary>
        /// Ruft den Befehl zum Anlegen einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungAnlegen
        {
            get
            {
                if (this._BestellungAnlegen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungAnlegen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungAnlegenLäuft = true;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this.AktuelleBestellung = null;
                            this.OnPropertyChanged("AktuelleBestellung");
                            this._KundeBestellungen = null;
                            this.OnPropertyChanged("KundeBestellungen");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        }
                        , data => !this.BestellungAnlegenLäuft
                        );

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungAnlegen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _BestellungBearbeitenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob eine 
        /// Bestellungsbearbeitung läuft, oder legt ihn fest.
        /// </summary>
        public bool BestellungBearbeitenLäuft
        {
            get
            {
                return this._BestellungBearbeitenLäuft;
            }
            set
            {
                this._BestellungBearbeitenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungBearbeiten = null;

        /// <summary>
        /// Ruft den Befehl zum Bearbeiten einer Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungBearbeiten
        {
            get
            {
                if (this._BestellungBearbeiten == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungBearbeiten = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._BestellungBearbeitenLäuft = true;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuelleBestellung != null && this.AktuelleBestellung.Nr != null && !this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungBearbeiten;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungLöschen = null;

        /// <summary>
        /// Ruft den Befehl zum Löschen der Bestellung ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungLöschen
        {
            get
            {
                if (this._BestellungLöschen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungLöschen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var Frage = System.Windows.MessageBox.Show(
                                            "Soll die Bestellung wirklich gelöscht werden?",
                                            "Bestellung löschen",
                                            System.Windows.MessageBoxButton.YesNo,
                                            System.Windows.MessageBoxImage.Warning);
                            if (Frage == System.Windows.MessageBoxResult.Yes)
                            {

                                this.Controller.BestellungLöschen(this.AktuelleBestellung);

                                this.AktuelleBestellung = null;
                                this.OnPropertyChanged("AktuelleBestellung");
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");

                            }

                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.AktuelleBestellung != null && this.AktuelleBestellung.Nr != null);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungLöschen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _BestellungAbbrechen = null;

        /// <summary>
        /// Ruft den Befehl zum Abbrechen der Bestellaktion ab.
        /// </summary>
        public WIFI.Windows.Befehl BestellungAbbrechen
        {
            get
            {
                if (this._BestellungAbbrechen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._BestellungAbbrechen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.BestellungSpeichernLäuft = false;
                            this.OnPropertyChanged("BestellungSpeichernLäuft");
                            this._BestellungAnlegenLäuft = false;
                            this.OnPropertyChanged("BestellungAnlegenLäuft");
                            this._BestellungBearbeitenLäuft = false;
                            this.OnPropertyChanged("BestellungBearbeitenLäuft");
                            this._KundeAnlegenLäuft = false;
                            this.OnPropertyChanged("KundeAnlegenLäuft");
                            this._KundeBearbeitenLäuft = false;
                            this.OnPropertyChanged("KundeBearbeitenLäuft");

                            if (this.BestellungAnlegenLäuft)
                            {
                                this._KundeBestellungen = null;
                                this.OnPropertyChanged("KundeBestellungen");
                            }

                            this.Besitzer.DeaktiviereBeschäftigt();
                        },
                        data => this.BestellungAnlegenLäuft || this.BestellungBearbeitenLäuft);

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._BestellungAbbrechen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzZurück = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzZurück
        {
            get
            {
                if (this._DatensatzZurück == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzZurück = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var index = this.Kunden.IndexOf(this.AktuellerKunde);
                            if (index > 0)
                            {
                                this.AktuellerKunde = (from k in this.Kunden select this.Kunden[index - 1]).FirstOrDefault();
                            }
                            this.OnPropertyChanged("AktuellerKunde");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzZurück;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzVorwärts = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des nächsten Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzVorwärts
        {
            get
            {
                if (this._DatensatzVorwärts == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzVorwärts = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            var index = this.Kunden.IndexOf(this.AktuellerKunde);
                            if (index < this.Kunden.Count - 1)
                            {
                                this.AktuellerKunde = (from k in this.Kunden select this.Kunden[index + 1]).FirstOrDefault();
                            };
                            this.OnPropertyChanged("AktuellerKunde");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzVorwärts;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzErster = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzErster
        {
            get
            {
                if (this._DatensatzErster == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzErster = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.AktuellerKunde = this.Kunden.FirstOrDefault();
                            this.OnPropertyChanged("AktuellerKunde");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzErster;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _DatensatzLetzter = null;

        /// <summary>
        /// Ruft den Befehl zum Holen des vorherigen Datensatzes ab.
        /// </summary>
        public WIFI.Windows.Befehl DatensatzLetzter
        {
            get
            {
                if (this._DatensatzLetzter == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._DatensatzLetzter = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this.AktuellerKunde = this.Kunden.LastOrDefault();
                            this.OnPropertyChanged("AktuellerKunde");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._DatensatzLetzter;
            }
        }

    }
}
