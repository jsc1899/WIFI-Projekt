﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.ViewModels
{
    public class KundenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft
        /// </summary>
        private Daten.Manager.DatenManager _Controller = null;

        /// <summary>
        /// Verwaltet den Kundenmanager.
        /// </summary>
        private Daten.Manager.DatenManager Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Daten.Manager.DatenManager>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Ruft den Fenstermanager ab,
        /// der diesen Kundenmanager initialisiert hat,
        /// ab oder legt diesen fest.
        /// </summary>
        public FensterManager Besitzer { get; set; }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Kunden _Kunden = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Kunden ab.
        /// </summary>
        public Daten.Kunden Kunden
        {
            get
            {
                if (this._Kunden == null)
                {
                    this._Kunden = this.Controller.KundenHolen();
                }
                return this._Kunden;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Kunde _AktuellerKunde = null;

        /// <summary>
        /// Ruft den aktuellen Kunden ab oder legt ihn fest.
        /// </summary>
        public Daten.Kunde AktuellerKunde
        {
            get
            {
                return this._AktuellerKunde;
            }
            set
            {
                if (this._AktuellerKunde != value)
                {
                    this._AktuellerKunde = value;
                    this.OnPropertyChanged();
                }
            }
        }

        /// <summary>
        /// Interes Feld für die Eigenschaft
        /// </summary>
        private Daten.Bestellungen _KundeBestellungen = null;

        /// <summary>
        /// Ruft die Liste der gespeicherten Bestellungen des Kunden ab.
        /// </summary>
        public Daten.Bestellungen KundeBestellungen
        {
            get
            {
                if (this._KundeBestellungen == null)
                {
                    this._KundeBestellungen = this.Controller.KundeBestellungenHolen(this.AktuellerKunde);
                }
                return this._KundeBestellungen;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Daten.Kunde _NeuerKunde = null;

        /// <summary>
        /// Ruft den neuen Kunden ab oder legt ihn fest.
        /// </summary>
        public Daten.Kunde NeuerKunde
        {
            get
            {
                if (this._NeuerKunde == null)
                {
                    this._NeuerKunde = new Daten.Kunde();
                }
                return this._NeuerKunde;
            }
            set
            {
                this._NeuerKunde = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeSpeichernLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob der Kunde 
        /// gespeichert wird, oder legt ihn fest.
        /// </summary>
        public bool KundeSpeichernLäuft
        {
            get
            {
                return this._KundeSpeichernLäuft;
            }
            set
            {
                this._KundeSpeichernLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeSpeichern = null;

        /// <summary>
        /// Ruft den Befehl zum Speichern eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeSpeichern
        {
            get
            {
                if (this._KundeSpeichern == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeSpeichern = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeSpeichernLäuft = true;

                            this.Controller.KundeSpeichern(this.NeuerKunde);

                            this._Kunden = null;
                            this.OnPropertyChanged("Kunden");
                            this._NeuerKunde = null;
                            this.OnPropertyChanged("NeuerKunde");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeSpeichern;
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _KundeBestellungenHolenLäuft = false;

        /// <summary>
        /// Ruft einen Wahrheitswert ab, ob die Bestellungen 
        /// eines Kunden abgeholt werden, oder legt ihn fest.
        /// </summary>
        public bool KundeBestellungenHolenLäuft
        {
            get
            {
                return this._KundeBestellungenHolenLäuft;
            }
            set
            {
                this._KundeBestellungenHolenLäuft = value;
                this.OnPropertyChanged();
            }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private WIFI.Windows.Befehl _KundeBestellungenHolen = null;

        /// <summary>
        /// Ruft den Befehl zum Holen der Bestellungen eines Kunden ab.
        /// </summary>
        public WIFI.Windows.Befehl KundeBestellungenHolen
        {
            get
            {
                if (this._KundeBestellungenHolen == null)
                {
                    this.Besitzer.AktiviereBeschäftigt();

                    this._KundeBestellungenHolen = new WIFI.Windows.Befehl(
                        data =>
                        {
                            this.Besitzer.AktiviereBeschäftigt();

                            this._KundeBestellungenHolenLäuft = true;

                            this._KundeBestellungen = this.Controller.KundeBestellungenHolen(this.AktuellerKunde);
                            this.OnPropertyChanged("KundeBestellungen");

                            this.Besitzer.DeaktiviereBeschäftigt();
                        });

                    this.Besitzer.DeaktiviereBeschäftigt();
                }

                return this._KundeBestellungenHolen;
            }
        }

    }
}
