﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buchausstellung
{
    /// <summary>
    /// Interaktionslogik für BuchAuswahl.xaml
    /// </summary>
    public partial class BuchAuswahl : UserControl
    {
        public BuchAuswahl()
        {
            InitializeComponent();
        }

        private void Buchfilter_KeyUp(object sender, KeyEventArgs e)
        {
            CollectionView BuchOriginal = (CollectionView)CollectionViewSource.GetDefaultView(Bücher.ItemsSource);

            BuchOriginal.Filter = (buch) =>
            {
                if (String.IsNullOrEmpty(Buchfilter.Text))
                {
                    return true;
                }
                else
                {
                    if ( ((Daten.Buch)buch).Titel.ToLower().Contains(Buchfilter.Text.ToLower()) 
                            || ((Daten.Buch)buch).Autor.ToLower().Contains(Buchfilter.Text.ToLower())
                            || ((Daten.Buch)buch).Verlag.ToLower().Contains(Buchfilter.Text.ToLower())
                            || ((Daten.Buch)buch).BuchNr.ToLower().Contains(Buchfilter.Text.ToLower())
                        )
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            };

            BuchOriginal.Refresh();

        }

        private void Buchfilter_GotFocus(object sender, RoutedEventArgs e)
        {
            Buchfilter.Text = "Damit es keinen Treffer gibt und AktuellesBuch zurückgesetzt wird";
            Buchfilter_KeyUp(Buchfilter, null);
            Buchfilter.Text = string.Empty;
            Buchfilter_KeyUp(Buchfilter, null);
        }

    }
}
