﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using WIFI.Anwendung.Daten.Erweiterungen;

namespace Buchausstellung
{
    /// <summary>
    /// Steuert die Teil 2 Client / Server Anwendung.
    /// </summary>
    public partial class App : System.Windows.Application
    {
        /// <summary>
        /// Stellt den Haupteinstiegspunkt bereit.
        /// </summary>
        [System.STAThread] //<- Attribut (Metadaten), notwendig, falls Windows Ressourcen benötigt wird
        private static void Main()
        {

            //Unsere Infrastruktur hochfahren...
            var AppKontext = new WIFI.Anwendung.Daten.DatenAnwendungskontext();

            //Die Protokolleinträge sollen gespeichert werden...
            //AppKontext.Protokoll.Pfad = System.IO.Path.Combine(AppKontext.AnwendungsdatenPfadLokal, "Protokoll.log");
            //AppKontext.Protokoll.Zusammenräumen(maxGenerationen: 5);

            //Die Anwendungskonfiguration in die Infrastruktur übernehmen

            AppKontext.DatenbankPfad = Buchausstellung.Properties.Settings.Default.DatenbankPfad;
            if (!System.IO.Path.IsPathRooted(AppKontext.DatenbankPfad))
            {
                AppKontext.DatenbankPfad = AppKontext.DatenbankPfad.ErzeugePfad(AppKontext.Anwendungspfad);
            }

            AppKontext.SqlServer = Buchausstellung.Properties.Settings.Default.SqlServer;
            AppKontext.SqlServerDatenbank = Buchausstellung.Properties.Settings.Default.Datenbank;


            //Für WPF die Anwendung initialisieren
            //(Damit System.Windows.Application.Current einen Wert bekommt)
            var WpfApp = new App();
            //Damit die in App.xaml definierten
            //Ressourcen geladen werden...
            WpfApp.InitializeComponent();

            //Der Infrastruktur den Thread-Dienst mitteilen...
            AppKontext.Dispatcher = WpfApp.Dispatcher;

            //die Anwendungssprache einstellen
            //AppKontext.Sprachen.Festlegen(Buchausstellung.Properties.Settings.Default.AktuelleSprache);


            //Im Thread eine neue Kultur für die eingestellte Sprache einstellen...
            System.Threading.Thread.CurrentThread.CurrentUICulture
                = new System.Globalization.CultureInfo(AppKontext.Sprachen.AktuelleSprache.Code);

            if (System.Threading.Thread.CurrentThread.CurrentUICulture.Name
                != System.Threading.Thread.CurrentThread.CurrentCulture.Parent.Name)
            {
                AppKontext.Protokoll.Eintragen(
                    "Die Oberflächensprache unterscheidet sich von der Sprache für die Zahlenformatierung!",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Warnung);
            }

            //Damit der Sprachen-Manager seine Caches entleert
            //und die Namen der Sprachen sicher übersetzt werden...
            AppKontext.Sprachen.Aktualisieren();

            //Das ViewModel starten...
            var VM = AppKontext.Erzeuge<ViewModels.FensterManager>();

            VM.Starten<Hauptfenster>();

            //Die aktuelle Sprache in die Konfiguration übernehmen...
            //Buchausstellung.Properties.Settings.Default.AktuelleSprache = AppKontext.Sprachen.AktuelleSprache.Code;

            //Damit z. B. die Fensterpositionen gespeichert werden...
            AppKontext.Herunterfahren();

            //Damit die Konfiguration gespeichert wird...
            Buchausstellung.Properties.Settings.Default.Save();
        }

    }
}
