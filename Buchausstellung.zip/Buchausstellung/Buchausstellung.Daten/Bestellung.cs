﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{

    /// <summary>
    /// Stellt eine Liste der Bestellungen bereit.
    /// </summary>
    public class Bestellungen : System.Collections.ObjectModel.ObservableCollection<Bestellung>
    {

    }

    /// <summary>
    /// Stellt Informationen über eine Bestellung bereit.
    /// </summary>
    public class Bestellung
    {

        /// <summary>
        /// Ruft die BestellNr ab oder legt sie fest.
        /// </summary>
        public int Nr { get; set; }

        /// <summary>
        /// Ruft das Bestelldatum ab oder legt es fest.
        /// </summary>
        public DateTime Bestelldatum { get; set; }

        /// <summary>
        /// Ruft das Buch ab oder legt es fest.
        /// </summary>
        public Buch Buch { get; set; }

        /// <summary>
        /// Ruft den Kunden ab oder legt ihn fest.
        /// </summary>
        public Kunde Kunde { get; set; }

        /// <summary>
        /// Ruft die Anzahl ab oder legt sie fest.
        /// </summary>
        public int Anzahl { get; set; }

        /// <summary>
        /// Ruft einen Wahrheitswert über den Lieferzustand ab oder legt ihn fest.
        /// </summary>
        public bool Lieferbar { get; set; }

    }
}
