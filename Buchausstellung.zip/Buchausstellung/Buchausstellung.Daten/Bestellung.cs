﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{

    /// <summary>
    /// Stellt eine Liste der Bestellungen bereit.
    /// </summary>
    public class Bestellungen : System.Collections.ObjectModel.ObservableCollection<Bestellung>
    {

    }

    /// <summary>
    /// Stellt Informationen über eine Bestellung bereit.
    /// </summary>
    public class Bestellung : System.ComponentModel.IDataErrorInfo
    {

        /// <summary>
        /// Ruft die BestellNr ab oder legt sie fest.
        /// </summary>
        public int? Nr { get; set; }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private DateTime _Bestelldatum = DateTime.Now;

        /// <summary>
        /// Ruft das Bestelldatum ab oder legt es fest.
        /// </summary>
        public DateTime Bestelldatum
        {
            get { return this._Bestelldatum; }
            set { this._Bestelldatum = value; }
        }

        /// <summary>
        /// Ruft das Buch ab oder legt es fest.
        /// </summary>
        public Buch Buch { get; set; }

        /// <summary>
        /// Ruft den Kunden ab oder legt ihn fest.
        /// </summary>
        public Kunde Kunde { get; set; }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private int _Anzahl = 1;

        /// <summary>
        /// Ruft die Anzahl ab oder legt sie fest.
        /// </summary>
        public int Anzahl
        {
            get { return this._Anzahl; }
            set { this._Anzahl = value; }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _Lieferbar = true;

        /// <summary>
        /// Ruft einen Wahrheitswert über den Lieferzustand ab oder legt ihn fest.
        /// </summary>
        public bool Lieferbar
        {
            get { return this._Lieferbar; }
            set { this._Lieferbar = value; }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _RechnungErstellt = false;

        /// <summary>
        /// Ruft einen Wahrheitswert, ob eine Rechnung erstellt wurde, ab, oder legt ihn fest.
        /// </summary>
        public bool RechnungErstellt
        {
            get { return this._RechnungErstellt; }
            set { this._RechnungErstellt = value; }
        }

        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private bool _Erledigt = false;

        /// <summary>
        /// Ruft einen Wahrheitswert über den Bestellstatus ab oder legt ihn fest.
        /// </summary>
        public bool Erledigt
        {
            get { return this._Erledigt; }
            set { this._Erledigt = value; }
        }

        /// <summary>
        /// Ruft das Änderungsdatum ab oder legt es fest.
        /// </summary>
        public DateTime? Änderungsdatum { get; set; }

        /// <summary>
        /// Ruft die Nr. und den Titel des Buches ab.
        /// </summary>
        public string Suchstring
        {
            get
            {
                return this.Nr.ToString() + "   " + this.Buch.Titel + "   " + this.Kunde.KompletterName;
            }
        }

        /// <summary>
        /// Fehlermeldung bei Falscheingabe.
        /// </summary>
        public string Error
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Prüfroutine von Eingaben.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string this[string name]
        {
            get
            {
                string Ergebnis = null;

                switch (name)
                {

                    case "Bestelldatum":
                        if (this.Bestelldatum == null)
                        {
                            Ergebnis = "Bestelldatum muss ausgewählt werden!";
                        }
                        break;

                    case "Buch":
                        if (this.Buch == null || this.Buch.BuchNr == null)
                        {
                            Ergebnis = "Buch muss ausgewählt werden!";
                        }
                        break;

                    case "Kunde":
                        if (this.Kunde == null || this.Kunde.Nr == null)
                        {
                            Ergebnis = "Kunde muss ausgewählt werden!";
                        }
                        break;

                    case "Anzahl":
                        if (this.Anzahl < 1 || this.Anzahl > 999)
                        {
                            Ergebnis = "Nur Werte von 1 bis 999 möglich!";
                        }
                        break;

                    default:
                        return Ergebnis;
                }

                return Ergebnis;
            }
        }

    }
}
