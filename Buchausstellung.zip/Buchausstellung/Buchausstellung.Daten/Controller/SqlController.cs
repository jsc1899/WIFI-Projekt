﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten.Controller
{

    /// <summary>
    /// Stellt einen Dienst zum Lesen und Schreiben
    /// der Daten aus einer Sql Server Datenbank bereit.
    /// </summary>
    internal class SqlController : WIFI.Anwendung.Daten.DatenbankObjekt
    {

        /// <summary>
        /// Gibt die gespeicherten Bücher zurück.
        /// </summary>
        public Bücher BücherHolen()
        {
            var Ergebnis = new Bücher();

            //IMMER das erste Objekt bei Datenbankzugriffen
            //Alle Datenbankobjekte besitzen ein Dispose()
            //Nie vergessen!
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {

                //IMMER das zweite Objekt bei Datenbankzugriffen
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BücherHolen", Verbindung))
                {
                    //Wir arbeiten mit gespeicherten Prozeduren...
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    ////Die Parameter beschicken...
                    //Befehl.Parameters.AddWithValue("@parameter", parameter);

                    //Den Datenbank-Server bitten, die
                    //Prozedure zu cachen...
                    Befehl.Prepare();

                    //Zum Schluss noch...
                    Verbindung.Open();
                    
                    //Nur wenn Daten geholt werden: SELECT
                    //Ein drittes Objekt...
                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        var RabattgruppenListe = this.RabattgruppenHolen();
                        var BuchgruppenListe = this.BuchgruppenHolen();
                        while (Leser.Read())
                        {
                            //Folgende "Kurzform" arbeitet nur,
                            //weil die gespeicherte Prozedur sicherstellt,
                            //dass keine NULL (System.DBNull.Value) Werte 
                            //geliefert werden...
                            Ergebnis.Add(new Buch
                            {
                                Nr = Leser["Nr"].ToString(),
                                Titel = Leser["Titel"].ToString(),
                                Autor = Leser["Autor"].ToString(),
                                Verlag = Leser["Verlag"].ToString(),
                                Preis = (double)Leser["Preis"],
                                Rabattgruppe = (from r in RabattgruppenListe where r.Nr == (int)Leser["Rabattgruppe"] select r).FirstOrDefault(),
                                Buchgruppe = (from b in BuchgruppenListe where b.Nr == (int)Leser["Buchgruppe"] select b).FirstOrDefault()
                            });
                            
                        }
                    }
                }

            }
            this.AppKontext.Protokoll.Eintragen($"BücherHolen liefert {Ergebnis.Count} Bücher...");
            return Ergebnis;
        }

        /// <summary>
        /// Gibt die gespeicherten Rabattgruppen zurück.
        /// </summary>
        public Rabattgruppen RabattgruppenHolen()
        {

            var Ergebnis = new Rabattgruppen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("RabattgruppenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Rabattgruppe
                            {
                                Nr = (int)Leser["Nr"],
                                Bezeichnung = Leser["Bezeichnung"].ToString(),
                                Rabatt = (double)Leser["Rabatt"]
                            });

                        }
                    }
                }
            }
            this.AppKontext.Protokoll.Eintragen($"RabattgruppenHolen liefert {Ergebnis.Count} Rabattgruppen...");
            return Ergebnis;
        }

        /// <summary>
        /// Gibt die gespeicherten Buchgruppen zurück.
        /// </summary>
        public Buchgruppen BuchgruppenHolen()
        {

            var Ergebnis = new Buchgruppen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BuchgruppenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Buchgruppe
                            {
                                Nr = (int)Leser["Nr"],
                                Bezeichnung = Leser["Bezeichnung"].ToString(),
                            });

                        }
                    }
                }
            }
            this.AppKontext.Protokoll.Eintragen($"BuchgruppenHolen liefert {Ergebnis.Count} Buchgruppen...");
            return Ergebnis;
        }

        /// <summary>
        /// Fügt ein Buch zur Datenbank hinzu.
        /// </summary>
        /// <param name="neuesBuch">Buch, das hinzugefügt werden soll.</param>
        public virtual void BuchSpeichern(Buch neuesBuch)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BuchSpeichern", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@nr", neuesBuch.Nr);
                    Befehl.Parameters.AddWithValue("@titel", neuesBuch.Titel);
                    Befehl.Parameters.AddWithValue("@autor", neuesBuch.Autor);
                    Befehl.Parameters.AddWithValue("@verlag", neuesBuch.Verlag);
                    Befehl.Parameters.AddWithValue("@preis", neuesBuch.Preis);
                    Befehl.Parameters.AddWithValue("@rabattgruppe", neuesBuch.Rabattgruppe.Nr);
                    Befehl.Parameters.AddWithValue("@buchgruppe", neuesBuch.Buchgruppe.Nr);

                    Befehl.Prepare();

                    Verbindung.Open();

                    //Um sicherzustellen, dass nur dann alle Änderungen 
                    //gespeichert werden, wenn alle Statements (Anweisungen) 
                    //erfolgreich sind, "Database Transactions" benutzen.
                    Befehl.Transaction = Verbindung.BeginTransaction();

                    Befehl.ExecuteNonQuery();

                    //Wenn der Code diese Zeile erreicht,
                    //war jedes Statement erfolgreich und 
                    //kann in der Datenbank gespeichert werden.
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Kunden zurück.
        /// </summary>
        public Kunden KundenHolen()
        {
            var Ergebnis = new Kunden();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("KundenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Kunde
                            {
                                Nr = (int)Leser["Nr"],
                                Geschlecht = Leser["Geschlecht"].ToString(),
                                Vorname = Leser["Vorname"].ToString(),
                                Nachname = Leser["Nachname"].ToString(),
                                TitelVorne = Leser["TitelVorne"].ToString(),
                                TitelHinten = Leser["TitelHinten"].ToString(),
                                PLZ = (int)Leser["PLZ"],
                                Ort = Leser["Ort"].ToString(),
                                Straße = Leser["Straße"].ToString()
                            });
                        }
                    }
                }
            }
            this.AppKontext.Protokoll.Eintragen($"KundenHolen liefert {Ergebnis.Count} Kunden...");
            return Ergebnis;
        }

        /// <summary>
        /// Fügt einen Kunden zur Datenbank hinzu.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der hinzugefügt werden soll.</param>
        public virtual void KundeSpeichern(Kunde aktuellerKunde)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("KundeSpeichern", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@geschlecht", aktuellerKunde.Geschlecht);
                    Befehl.Parameters.AddWithValue("@vorname", aktuellerKunde.Vorname);
                    Befehl.Parameters.AddWithValue("@nachname", aktuellerKunde.Nachname);
                    Befehl.Parameters.AddWithValue("@titelVorne", aktuellerKunde.TitelVorne);
                    Befehl.Parameters.AddWithValue("@titelHinten", aktuellerKunde.TitelHinten);
                    Befehl.Parameters.AddWithValue("@plz", aktuellerKunde.PLZ);
                    Befehl.Parameters.AddWithValue("@ort", aktuellerKunde.Ort);
                    Befehl.Parameters.AddWithValue("@straße", aktuellerKunde.Straße);


                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Löscht einen Kunden aus der Datenbank.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der gelöscht werden soll.</param>
        public virtual void KundeLöschen(Kunde aktuellerKunde)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("KundeLöschen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@nr", aktuellerKunde.Nr);

                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Bearbeitet einen Kunden aus der Datenbank.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der bearbeitet werden soll.</param>
        public virtual void KundeBearbeiten(Kunde aktuellerKunde)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("KundeBearbeiten", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@nr", aktuellerKunde.Nr);
                    Befehl.Parameters.AddWithValue("@geschlecht", aktuellerKunde.Geschlecht);
                    Befehl.Parameters.AddWithValue("@vorname", aktuellerKunde.Vorname);
                    Befehl.Parameters.AddWithValue("@nachname", aktuellerKunde.Nachname);
                    Befehl.Parameters.AddWithValue("@titelVorne", aktuellerKunde.TitelVorne);
                    Befehl.Parameters.AddWithValue("@titelHinten", aktuellerKunde.TitelHinten);
                    Befehl.Parameters.AddWithValue("@plz", aktuellerKunde.PLZ);
                    Befehl.Parameters.AddWithValue("@ort", aktuellerKunde.Ort);
                    Befehl.Parameters.AddWithValue("@straße", aktuellerKunde.Straße);


                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Bestellungen zurück.
        /// </summary>
        public Bestellungen BestellungenHolen()
        {
            var Ergebnis = new Bestellungen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BestellungenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        var Bücher = this.BücherHolen();
                        var Kunden = this.KundenHolen();
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Bestellung
                            {
                                Nr = (int)Leser["Nr"],
                                Bestelldatum = (DateTime)Leser["Bestelldatum"],
                                Buch = (from b in Bücher where b.Nr == Leser["Buch"].ToString() select b).FirstOrDefault(),
                                Kunde = (from k in Kunden where k.Nr == (int)Leser["Kunde"] select k).FirstOrDefault(),
                                Anzahl = (int)Leser["Anzahl"],
                                Lieferbar = (bool)Leser["Lieferbar"],
                                RechnungErstellt = (bool)Leser["RechnungErstellt"],
                                Erledigt = (bool)Leser["Erledigt"],
                                Änderungsdatum = (DateTime)Leser["Änderungsdatum"]

                            });
                        }
                    }
                }
            }
            this.AppKontext.Protokoll.Eintragen($"BestellungenHolen liefert {Ergebnis.Count} Bestellungen...");
            return Ergebnis;
        }

        /// <summary>
        /// Gibt die gespeicherten Bestellungen eines Kunden zurück.
        /// </summary>
        /// /// <param name="kunde">Kunde, von dem die Bestellungen geholt werden sollen.</param>
        public Bestellungen KundeBestellungenHolen(Kunde kunde)
        {
            var Ergebnis = new Bestellungen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("KundeBestellungenHolen", Verbindung))
                {

                    Befehl.Parameters.AddWithValue("nr", kunde.Nr);

                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        var Bücher = this.BücherHolen();
                        var Kunden = this.KundenHolen();
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Bestellung
                            {
                                Nr = (int)Leser["Nr"],
                                Bestelldatum = (DateTime)Leser["Bestelldatum"],
                                Buch = (from b in Bücher where b.Nr == Leser["Buch"].ToString() select b).FirstOrDefault(),
                                Kunde = (from k in Kunden where k.Nr == (int)Leser["Kunde"] select k).FirstOrDefault(),
                                Anzahl = (int)Leser["Anzahl"],
                                Lieferbar = (bool)Leser["Lieferbar"],
                                RechnungErstellt = (bool)Leser["RechnungErstellt"],
                                Erledigt = (bool)Leser["Erledigt"],
                                Änderungsdatum = (DateTime)Leser["Änderungsdatum"]

                            });
                        }
                    }
                }
            }
            this.AppKontext.Protokoll.Eintragen($"KundeBestellungenHolen liefert {Ergebnis.Count} Bestellungen...");
            return Ergebnis;
        }

        /// <summary>
        /// Fügt eine Bestellungen zur Datenbank hinzu.
        /// </summary>
        /// <param name="neueBestellung">Bestellung, die hinzugefügt werden soll.</param>
        public virtual void BestellungSpeichern(Bestellung neueBestellung)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BestellungSpeichern", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("bestelldatum", neueBestellung.Bestelldatum);
                    Befehl.Parameters.AddWithValue("buch", neueBestellung.Buch.Nr);
                    Befehl.Parameters.AddWithValue("kunde", neueBestellung.Kunde.Nr);
                    Befehl.Parameters.AddWithValue("anzahl", neueBestellung.Anzahl);
                    Befehl.Parameters.AddWithValue("lieferbar", neueBestellung.Lieferbar);
                    Befehl.Parameters.AddWithValue("rechnungErstellt", neueBestellung.RechnungErstellt);
                    Befehl.Parameters.AddWithValue("erledigt", neueBestellung.Erledigt);

                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Löscht eine Bestellung aus der Datenbank.
        /// </summary>
        /// <param name="aktuelleBestellung">Bestellung, die gelöscht werden soll.</param>
        public virtual void BestellungLöschen(Bestellung aktuelleBestellung)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BestellungLöschen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@nr", aktuelleBestellung.Nr);

                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }

        /// <summary>
        /// Bearbeitet eine gespeicherte Bestellung.
        /// </summary>
        /// <param name="aktuelleBestellung">Bestellung, die geändert werden soll.</param>
        public virtual void BestellungBearbeiten(Bestellung aktuelleBestellung)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BestellungBearbeiten", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("nr", aktuelleBestellung.Nr);
                    Befehl.Parameters.AddWithValue("bestelldatum", aktuelleBestellung.Bestelldatum);
                    Befehl.Parameters.AddWithValue("buch", aktuelleBestellung.Buch.Nr);
                    Befehl.Parameters.AddWithValue("kunde", aktuelleBestellung.Kunde.Nr);
                    Befehl.Parameters.AddWithValue("anzahl", aktuelleBestellung.Anzahl);
                    Befehl.Parameters.AddWithValue("lieferbar", aktuelleBestellung.Lieferbar);
                    Befehl.Parameters.AddWithValue("rechnungErstellt", aktuelleBestellung.RechnungErstellt);
                    Befehl.Parameters.AddWithValue("erledigt", aktuelleBestellung.Erledigt);
                    Befehl.Parameters.AddWithValue("änderungsdatum", DateTime.Now);

                    Befehl.Prepare();
                    Verbindung.Open();

                    Befehl.Transaction = Verbindung.BeginTransaction();
                    Befehl.ExecuteNonQuery();
                    Befehl.Transaction.Commit();
                }
            }
        }
    }
}

