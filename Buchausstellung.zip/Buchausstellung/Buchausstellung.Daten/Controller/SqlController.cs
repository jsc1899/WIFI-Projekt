﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten.Controller
{

    /// <summary>
    /// Stellt einen Dienst zum Lesen und Schreiben
    /// der Daten aus einer Sql Server Datenbank bereit.
    /// </summary>
    internal class SqlController : WIFI.Anwendung.Daten.DatenbankObjekt
    {

        /// <summary>
        /// Gibt die gespeicherten Bücher zurück.
        /// </summary>
        public Bücher BücherHolen()
        {

            var Ergebnis = new Bücher();

            //IMMER das erste Objekt bei Datenbankzugriffen
            //Alle Datenbankobjekte besitzen ein Dispose()
            //Nie vergessen!
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {

                //IMMER das zweite Objekt bei Datenbankzugriffen
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BücherHolen", Verbindung))
                {
                    //Wir arbeiten mit gespeicherten Prozeduren...
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    ////Die Parameter beschicken...
                    //Befehl.Parameters.AddWithValue("@parameter", parameter);

                    //Den Datenbank-Server bitten, die
                    //Prozedure zu cachen...
                    Befehl.Prepare();

                    //Zum Schluss noch...
                    Verbindung.Open();
                    
                    //Nur wenn Daten geholt werden: SELECT
                    //Ein drittes Objekt...
                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        var RabattgruppenListe = this.RabattgruppenHolen();
                        var BuchgruppenListe = this.BuchgruppenHolen();
                        while (Leser.Read())
                        {
                            //Folgende "Kurzform" arbeitet nur,
                            //weil die gespeicherte Prozedur sicherstellt,
                            //dass keine NULL (System.DBNull.Value) Werte 
                            //geliefert werden...
                            Ergebnis.Add(new Buch
                            {
                                Nr = Leser["Nr"].ToString(),
                                Titel = Leser["Titel"].ToString(),
                                Autor = Leser["Autor"].ToString(),
                                Verlag = Leser["Verlag"].ToString(),
                                Preis = (double)Leser["Preis"],
                                Rabattgruppe = (from r in RabattgruppenListe where r.Nr == (int)Leser["Rabattgruppe"] select r).FirstOrDefault(),
                                Buchgruppe = (from b in BuchgruppenListe where b.Nr == (int)Leser["Buchgruppe"] select b).FirstOrDefault()
                            });
                            
                        }
                    }
                }

            }

            this.AppKontext.Protokoll.Eintragen(
                    $"BücherHolen liefert {Ergebnis.Count} Bücher..."
                );

            return Ergebnis;
        }

        /// <summary>
        /// Gibt die gespeicherten Rabattgruppen zurück.
        /// </summary>
        public Rabattgruppen RabattgruppenHolen()
        {

            var Ergebnis = new Rabattgruppen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("RabattgruppenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Rabattgruppe
                            {
                                Nr = (int)Leser["Nr"],
                                Bezeichnung = Leser["Bezeichnung"].ToString(),
                                Rabatt = (double)Leser["Rabatt"]
                            });

                        }
                    }
                }
            }

            this.AppKontext.Protokoll.Eintragen(
                    $"RabattgruppenHolen liefert {Ergebnis.Count} Rabattgruppen..."
                );

            return Ergebnis;
        }

        /// <summary>
        /// Gibt die gespeicherten Buchgruppen zurück.
        /// </summary>
        public Buchgruppen BuchgruppenHolen()
        {

            var Ergebnis = new Buchgruppen();

            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BuchgruppenHolen", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;
                    Befehl.Prepare();
                    Verbindung.Open();

                    using (var Leser = Befehl.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        while (Leser.Read())
                        {
                            Ergebnis.Add(new Buchgruppe
                            {
                                Nr = (int)Leser["Nr"],
                                Bezeichnung = Leser["Bezeichnung"].ToString(),
                            });

                        }
                    }
                }
            }

            this.AppKontext.Protokoll.Eintragen(
                    $"BuchgruppenHolen liefert {Ergebnis.Count} Buchgruppen..."
                );

            return Ergebnis;
        }

        /// <summary>
        /// Fügt ein Buch zur Datenbank hinzu.
        /// </summary>
        /// <param name="neuesBuch">Buch, das hinzugefügt werden soll.</param>
        public virtual void BuchSpeichern(Buch neuesBuch)
        {
            using (var Verbindung = new System.Data.SqlClient.SqlConnection(this.ConnectionString))
            {
                using (var Befehl = new System.Data.SqlClient.SqlCommand("BuchSpeichern", Verbindung))
                {
                    Befehl.CommandType = System.Data.CommandType.StoredProcedure;

                    Befehl.Parameters.AddWithValue("@nr", neuesBuch.Nr);
                    Befehl.Parameters.AddWithValue("@titel", neuesBuch.Titel);
                    Befehl.Parameters.AddWithValue("@autor", neuesBuch.Autor);
                    Befehl.Parameters.AddWithValue("@verlag", neuesBuch.Verlag);
                    Befehl.Parameters.AddWithValue("@preis", neuesBuch.Preis);
                    Befehl.Parameters.AddWithValue("@rabattgruppe", neuesBuch.Rabattgruppe.Nr);
                    Befehl.Parameters.AddWithValue("@buchgruppe", neuesBuch.Buchgruppe.Nr);

                    Befehl.Prepare();

                    Verbindung.Open();

                    //Um sicherzustellen, dass nur dann alle Änderungen 
                    //gespeichert werden, wenn alle Statements (Anweisungen) 
                    //erfolgreich sind, "Database Transactions" benutzen.
                    Befehl.Transaction = Verbindung.BeginTransaction();

                    Befehl.ExecuteNonQuery();

                    //Wenn der Code diese Zeile erreicht,
                    //war jedes Statement erfolgreich und 
                    //kann in der Datenbank gespeichert werden.
                    Befehl.Transaction.Commit();
                }
            }
        }

    }
}

