﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten.Manager
{
    /// <summary>
    /// Stellt einen Dienst zum Arbeiten
    /// mit Datenbankdaten bereit.
    /// </summary>
    public class DatenManager : WIFI.Anwendung.Daten.DatenAnwendungsobjekt
    {
        /// <summary>
        /// Internes Feld für die Eigenschaft.
        /// </summary>
        private Controller.SqlController _Controller = null;

        /// <summary>
        /// Ruft den Dienst zum Lesen und Schreiben
        /// der Datenbankdaten ab.
        /// </summary>
        private Controller.SqlController Controller
        {
            get
            {
                if (this._Controller == null)
                {
                    this._Controller = this.AppKontext.Erzeuge<Controller.SqlController>();
                }

                return this._Controller;
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Bücher zurück.
        /// </summary>
        public Bücher BücherHolen()
        {
            try
            {
                return this.Controller.BücherHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Bücher();
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Rabattgruppen zurück.
        /// </summary>
        public Rabattgruppen RabattgruppenHolen()
        {
            try
            {
                return this.Controller.RabattgruppenHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Rabattgruppen();
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Buchgruppen zurück.
        /// </summary>
        public Buchgruppen BuchgruppenHolen()
        {
            try
            {
                return this.Controller.BuchgruppenHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Buchgruppen();
            }
        }

        /// <summary>
        /// Fügt ein Buch zur Datenbank hinzu.
        /// </summary>
        /// <param name="neuesBuch">Buch, das hinzugefügt werden soll.</param>
        public void BuchSpeichern(Buch neuesBuch)
        {
            try
            {
                this.Controller.BuchSpeichern(neuesBuch);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Bearbeitet ein Buch aus der Datenbank.
        /// </summary>
        /// <param name="aktuellesBuch">Buch, das bearbeitet werden soll.</param>
        public void BuchBearbeiten(Buch aktuellesBuch)
        {
            try
            {
                this.Controller.BuchBearbeiten(aktuellesBuch);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Löscht ein Buch aus der Datenbank.
        /// </summary>
        /// <param name="aktuellesBuch">Buch, das gelöscht werden soll.</param>
        public void BuchLöschen(Buch aktuellesBuch)
        {
            try
            {
                this.Controller.BuchLöschen(aktuellesBuch);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Kunden zurück.
        /// </summary>
        public Kunden KundenHolen()
        {
            try
            {
                return this.Controller.KundenHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Kunden();
            }
        }

        /// <summary>
        /// Fügt einen Kunden zur Datenbank hinzu.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der hinzugefügt werden soll.</param>
        public void KundeSpeichern(Kunde aktuellerKunde)
        {
            try
            {
                this.Controller.KundeSpeichern(aktuellerKunde);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Bearbeitet einen Kunden aus der Datenbank.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der bearbeitet werden soll.</param>
        public void KundeBearbeiten(Kunde aktuellerKunde)
        {
            try
            {
                this.Controller.KundeBearbeiten(aktuellerKunde);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Löscht einen Kunden aus der Datenbank.
        /// </summary>
        /// <param name="aktuellerKunde">Kunde, der gelöscht werden soll.</param>
        public void KundeLöschen(Kunde aktuellerKunde)
        {
            try
            {
                this.Controller.KundeLöschen(aktuellerKunde);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Bestellungen zurück.
        /// </summary>
        public Bestellungen BestellungenHolen()
        {
            try
            {
                return this.Controller.BestellungenHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Bestellungen();
            }
        }

        /// <summary>
        /// Gibt die gespeicherten Bestellungen eines Kunden zurück.
        /// </summary>
        public Bestellungen KundeBestellungenHolen(Kunde kunde)
        {
            try
            {
                return this.Controller.KundeBestellungenHolen(kunde);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new Bestellungen();
            }
        }

        /// <summary>
        /// Fügt eine Bestellung zur Datenbank hinzu.
        /// </summary>
        /// <param name="neueBestellung">Bestellung, die hinzugefügt werden soll.</param>
        public void BestellungSpeichern(Bestellung neueBestellung)
        {
            try
            {
                this.Controller.BestellungSpeichern(neueBestellung);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Löscht eine Bestellung aus der Datenbank.
        /// </summary>
        /// <param name="aktuelleBestellung">Bestellung, die gelöscht werden soll.</param>
        public void BestellungLöschen(Bestellung aktuelleBestellung)
        {
            try
            {
                this.Controller.BestellungLöschen(aktuelleBestellung);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Bearbeitet eine gespeicherte Bestellung.
        /// </summary>
        /// <param name="aktuelleBestellung">Bestellung, die geändert werden soll.</param>
        public void BestellungBearbeiten(Bestellung aktuelleBestellung)
        {
            try
            {
                this.Controller.BestellungBearbeiten(aktuelleBestellung);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

        /// <summary>
        /// Gibt die Anzahl der Buchbestellungen zurück.
        /// </summary>
        public BuchBestellungen BuchBestellungenHolen()
        {
            try
            {
                return this.Controller.BuchBestellungenHolen();
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
                return new BuchBestellungen();
            }
        }

        /// <summary>
        /// Setzt alle offenen Bestellungen eines Kunden auf erledigt.
        /// </summary>
        /// <param name="kunde">Kunde, bei dem alle offenen Bestellungen auf erledigt gesetzt werden sollen.</param>
        public void KundeBestellungenErledigen(Kunde kunde)
        {
            try
            {
                this.Controller.KundeBestellungenErledigen(kunde);
            }
            catch (System.Exception ex)
            {
                this.AppKontext.Protokoll.Eintragen(
                    $"{this} hat eine Ausnahme verursacht:\r\n{ex.Message}",
                    WIFI.Anwendung.Daten.ProtokollEintragTyp.Fehler);
            }
        }

    }
}
