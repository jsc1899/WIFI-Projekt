﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{



    /// <summary>
    /// Stellt eine Auflistung der gespeicherten Bücher bereit.
    /// </summary>
    public class Bücher : System.Collections.ObjectModel.ObservableCollection<Buch>
    {

    }

    /// <summary>
    /// Stellt Informationen über ein Buch bereit.
    /// </summary>
    public class Buch : System.ComponentModel.IDataErrorInfo
    {

        /// <summary>
        /// Ruft die Nr ab oder legt sie fest.
        /// </summary>
        public int? Nr { get; set; }

        /// <summary>
        /// Ruft die Buchnummer ab oder legt sie fest.
        /// </summary>
        public string BuchNr { get; set; }

        /// <summary>
        /// Ruft den Titel des Buchs ab oder legt ihn fest.
        /// </summary>
        public string Titel { get; set; }

        /// <summary>
        /// Ruft den Autor des Buchs ab oder legt ihn fest.
        /// </summary>
        public string Autor { get; set; }

        /// <summary>
        /// Ruft den Verlag des Buchs ab oder legt ihn fest.
        /// </summary>
        public string Verlag { get; set; }

        /// <summary>
        /// Ruft den Preis des Buchs ab oder legt ihn fest.
        /// </summary>
        public double? Preis { get; set; }

        /// <summary>
        /// Ruft die Rabattgruppe ab oder legt sie fest.
        /// </summary>
        public Rabattgruppe Rabattgruppe { get; set; }

        /// <summary>
        /// Ruft die Buchgrupe ab oder legt sie fest.
        /// </summary>
        public Buchgruppe Buchgruppe { get; set; }

        /// <summary>
        /// Ruft die Nr. und den Titel des Buches ab.
        /// </summary>
        public string NrUndTitel
        {
            get
            {
                return this.BuchNr.PadLeft(4) + "  " + this.Titel.PadRight(25);
            }
            set
            {
                this.NrUndTitel = value;
            }
        }

        /// <summary>
        /// Ruft den Suchstring des Buches ab.
        /// </summary>
        public string Suchstring
        {
            get
            {
                return this.BuchNr.PadLeft(4) + "  " + this.Titel.PadRight(25) + "  " + this.Autor.PadRight(20) + "  " + this.Verlag.PadRight(20);
            }
        }

        /// <summary>
        /// Fehlermeldung bei Falscheingabe.
        /// </summary>
        public string Error
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Prüfroutine von Eingaben.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string this[string name]
        {
            get
            {
                string Ergebnis = null;

                switch (name)
                {

                    case "BuchNr":
                        if (string.IsNullOrEmpty(this.BuchNr))
                        {
                            Ergebnis = "Nr muss eingegeben werden!";
                        }
                        else if (this.BuchNr.Length > 4)
                        {
                            Ergebnis = "Nr darf maximal 4 Zeichen haben!";
                        }
                        break;

                    case "Titel":
                        if (string.IsNullOrEmpty(this.Titel))
                        {
                            Ergebnis = "Titel muss eingegeben werden!";
                        }
                        else if (this.Titel.Length > 25)
                        {
                            Ergebnis = "Titel darf maximal 25 Zeichen haben!";
                        }
                        break;

                    case "Autor":
                        if (string.IsNullOrEmpty(this.Autor))
                        {
                            Ergebnis = "Autor muss eingegeben werden!";
                        }
                        else if (this.Autor.Length > 20)
                        {
                            Ergebnis = "Autor darf maximal 20 Zeichen haben!";
                        }
                        break;

                    case "Verlag":
                        if (string.IsNullOrEmpty(this.Verlag))
                        {
                            Ergebnis = "Verlag muss eingegeben werden!";
                        }
                        else if (this.Verlag.Length > 20)
                        {
                            Ergebnis = "Verlag darf maximal 20 Zeichen haben!";
                        }
                        break;

                    case "Preis":
                        if (this.Preis < 0.0 || this.Preis > 999.99)
                        {
                            Ergebnis = "Preis ist falsch!";
                        }
                        else if (this.Preis == null)
                        {
                            Ergebnis = "Preis muss eingegeben werden!";
                        }
                        break;

                    case "Rabattgruppe":
                        if (this.Rabattgruppe == null)
                        {
                            Ergebnis = "Rabattgruppe muss ausgewählt werden!";
                        }
                        break;

                    case "Buchgruppe":
                        if (this.Buchgruppe == null)
                        {
                            Ergebnis = "Buchgruppe muss ausgewählt werden!";
                        }
                        break;

                    default:
                        return Ergebnis;
                }

                return Ergebnis;
            }
        }

    }

    /// <summary>
    /// Stellt eine Auflistung der Buchgruppen bereit.
    /// </summary>
    public class Buchgruppen : System.Collections.ObjectModel.ObservableCollection<Buchgruppe>
    {

    }

    /// <summary>
    /// Beschreibt eine Buchgruppe
    /// </summary>
    public class Buchgruppe
    {
        /// <summary>
        /// Ruft die Buchgruppennummer ab oder legt sie fest.
        /// </summary>
        public int Nr { get; set; }

        /// <summary>
        /// Ruft die Bezeichnung ab oder legt sie fest.
        /// </summary>
        public string Bezeichnung { get; set; }

    }

    /// <summary>
    /// Stellt eine Auflistung der Rabattgruppen bereit.
    /// </summary>
    public class Rabattgruppen : System.Collections.ObjectModel.ObservableCollection<Rabattgruppe>
    {

    }

    /// <summary>
    /// Beschreibt eine Buchgruppe
    /// </summary>
    public class Rabattgruppe
    {
        /// <summary>
        /// Ruft die Rabattgruppennummer ab oder legt sie fest.
        /// </summary>
        public int Nr { get; set; }

        /// <summary>
        /// Ruft die Bezeichnung ab oder legt sie fest.
        /// </summary>
        public string Bezeichnung { get; set; }

        /// <summary>
        /// Ruft die Rabatthöhe in Prozent ab oder legt sie fest.
        /// </summary>
        public double Rabatt { get; set; }

    }
}
