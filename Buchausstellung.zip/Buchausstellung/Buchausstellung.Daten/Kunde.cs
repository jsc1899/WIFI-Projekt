﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{
    // Listet mögliche Kundenanreden auf.
    public enum Anrede
    {
        Herr,
        Frau,
        Firma,
        Verein
    }

    /// <summary>
    /// Stellt eine Auflistung der gespeicherten Kunden bereit.
    /// </summary>
    public class Kunden : System.Collections.ObjectModel.ObservableCollection<Kunde>
    {

    }

    /// <summary>
    /// Stellt Informationen über einen Kunden bereit.
    /// </summary>
    public class Kunde
    {
        /// <summary>
        /// Ruft die Kundennummer ab oder legt sie fest.
        /// </summary>
        public int Nr { get; set; }

        /// <summary>
        /// Ruft die Anrede ab oder legt sie fest.
        /// </summary>
        public Anrede Anrede { get; set; }

        /// <summary>
        /// Ruft den Vornamen ab oder legt ihn fest.
        /// </summary>
        public string Vorname { get; set; }

        /// <summary>
        /// Ruft den Nachnamen ab oder legt ihn fest.
        /// </summary>
        public string Nachname { get; set; }

        /// <summary>
        ///  Ruft den vorangestellten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelVorne { get; set; }

        /// <summary>
        ///  Ruft den hinten angehängten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelHinten { get; set; }

        /// <summary>
        ///  Ruft die Postleitzahl ab oder legt sie fest.
        /// </summary>
        public int PLZ { get; set; }

        /// <summary>
        ///  Ruft den Ort ab oder legt ihn fest.
        /// </summary>
        public string Ort { get; set; }

        /// <summary>
        ///  Ruft die Straße ab oder legt sie fest.
        /// </summary>
        public string Straße { get; set; }
    }
}
