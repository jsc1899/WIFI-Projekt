﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{

    /// <summary>
    /// Stellt eine Auflistung der gespeicherten Kunden bereit.
    /// </summary>
    public class Kunden : System.Collections.ObjectModel.ObservableCollection<Kunde>
    {

    }

    /// <summary>
    /// Stellt Informationen über einen Kunden bereit.
    /// </summary>
    public class Kunde : System.ComponentModel.IDataErrorInfo
    {
        /// <summary>
        /// Ruft die Kundennummer ab oder legt sie fest.
        /// </summary>
        public int Nr { get; set; }

        /// <summary>
        /// Ruft das Geschlecht ab oder legt es fest.
        /// </summary>
        public string Geschlecht { get; set; }

        /// <summary>
        /// Ruft den Vornamen ab oder legt ihn fest.
        /// </summary>
        public string Vorname { get; set; }

        /// <summary>
        /// Ruft den Nachnamen ab oder legt ihn fest.
        /// </summary>
        public string Nachname { get; set; }

        /// <summary>
        ///  Ruft den vorangestellten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelVorne { get; set; }

        /// <summary>
        ///  Ruft den hinten angehängten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelHinten { get; set; }

        /// <summary>
        ///  Ruft die Postleitzahl ab oder legt sie fest.
        /// </summary>
        public int? PLZ { get; set; }

        /// <summary>
        ///  Ruft den Ort ab oder legt ihn fest.
        /// </summary>
        public string Ort { get; set; }

        /// <summary>
        ///  Ruft die Straße ab oder legt sie fest.
        /// </summary>
        public string Straße { get; set; }

        /// <summary>
        /// Ruft den gesamten Namen ab.
        /// </summary>
        public string GesamterName
        {
            get
            {
                return this.Nachname + " " + this.Vorname;
            }
        }

        /// <summary>
        /// Fehlermeldung bei Falscheingabe.
        /// </summary>
        public string Error
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Prüfroutine von Eingaben.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string this[string name]
        {
            get
            {
                string Ergebnis = null;

                if (name == "PLZ")
                {
                    if (this.PLZ <= 0 || this.PLZ > 99999)
                    {
                        Ergebnis = "PLZ falsch!";
                    }
                }
                return Ergebnis;
            }
        }

    }
}
