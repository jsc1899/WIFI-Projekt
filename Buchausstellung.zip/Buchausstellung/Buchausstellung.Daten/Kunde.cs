﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buchausstellung.Daten
{

    /// <summary>
    /// Stellt eine Auflistung der gespeicherten Kunden bereit.
    /// </summary>
    public class Kunden : System.Collections.ObjectModel.ObservableCollection<Kunde>
    {

    }

    /// <summary>
    /// Stellt Informationen über einen Kunden bereit.
    /// </summary>
    public class Kunde : System.ComponentModel.IDataErrorInfo
    {
        /// <summary>
        /// Ruft die Kundennummer ab oder legt sie fest.
        /// </summary>
        public int? Nr { get; set; }

        /// <summary>
        /// Ruft das Geschlecht ab oder legt es fest.
        /// </summary>
        public string Geschlecht { get; set; }

        /// <summary>
        /// Ruft den Vornamen ab oder legt ihn fest.
        /// </summary>
        public string Vorname { get; set; }

        /// <summary>
        /// Ruft den Nachnamen ab oder legt ihn fest.
        /// </summary>
        public string Nachname { get; set; }

        /// <summary>
        ///  Ruft den vorangestellten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelVorne { get; set; }

        /// <summary>
        ///  Ruft den hinten angehängten Titel ab oder legt ihn fest.
        /// </summary>
        public string TitelHinten { get; set; }

        /// <summary>
        ///  Ruft die Postleitzahl ab oder legt sie fest.
        /// </summary>
        public int? PLZ { get; set; }

        /// <summary>
        ///  Ruft den Ort ab oder legt ihn fest.
        /// </summary>
        public string Ort { get; set; }

        /// <summary>
        ///  Ruft die Straße ab oder legt sie fest.
        /// </summary>
        public string Straße { get; set; }

        /// <summary>
        /// Ruft den kompletten Namen ab.
        /// </summary>
        public string KompletterName
        {
            get
            {
                return this.Nachname + " " + this.Vorname;
            }
        }

        /// <summary>
        /// Fehlermeldung bei Falscheingabe.
        /// </summary>
        public string Error
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Prüfroutine von Eingaben.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public string this[string name]
        {
            get
            {
                string Ergebnis = null;

                switch (name)
                {

                    case "Geschlecht":
                        if (string.IsNullOrEmpty(this.Geschlecht))
                        {
                            Ergebnis = "Geschlecht muss ausgewählt werden!";
                        }
                        break;

                    case "Vorname":
                        if (string.IsNullOrEmpty(this.Vorname))
                        {
                            Ergebnis = "Vorname muss eingegeben werden!";
                        }
                        else if (this.Vorname.Length > 50)
                        {
                            Ergebnis = "Vorname darf maximal 50 Zeichen haben!";
                        }
                        break;

                    case "Nachname":
                        if (string.IsNullOrEmpty(this.Nachname))
                        {
                            Ergebnis = "Nachname muss eingegeben werden!";
                        }
                        else if (this.Nachname.Length > 50)
                        {
                            Ergebnis = "Nachname darf maximal 50 Zeichen haben!";
                        }
                        break;


                    case "TitelVorne":
                        if (string.IsNullOrEmpty(this.TitelVorne))
                        {
                            this.TitelVorne = string.Empty;
                        }
                        else if (this.TitelVorne.Length > 20)
                        {
                            Ergebnis = "Titel darf maximal 20 Zeichen haben!";
                        }
                        break;

                    case "TitelHinten":
                        if (string.IsNullOrEmpty(this.TitelHinten))
                        {
                            this.TitelHinten = string.Empty;
                        }
                        else if (this.TitelHinten.Length > 20)
                        {
                            Ergebnis = "Titel darf maximal 20 Zeichen haben!";
                        }
                        break;

                    case "Straße":
                        if (string.IsNullOrEmpty(this.Straße))
                        {
                            Ergebnis = "Straße muss eingegeben werden!";
                        }
                        else if (this.Straße.Length > 50)
                        {
                            Ergebnis = "Straße darf maximal 50 Zeichen haben!";
                        }
                        break;

                    case "PLZ":
                        if ((this.PLZ < 0 || this.PLZ > 99999))
                        {
                            Ergebnis = "PLZ falsch!";
                        }
                        else if (this.PLZ == null)
                        {
                            Ergebnis = "PLZ muss eingegeben werden!";
                        }
                        break;

                    case "Ort":
                        if (string.IsNullOrEmpty(this.Ort))
                        {
                            Ergebnis = "Ort muss eingegeben werden!";
                        }
                        else if (this.Ort.Length > 50)
                        {
                            Ergebnis = "Ort darf maximal 50 Zeichen haben!";
                        }
                        break;

                    default:
                        return Ergebnis;
                }

                return Ergebnis;
            }
        }

    }
}
